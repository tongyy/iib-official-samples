--<ScriptOptions statementTerminator=";"/>
DELETE FROM ADAPTER_CUSTOMER WHERE PKEY='cust01';