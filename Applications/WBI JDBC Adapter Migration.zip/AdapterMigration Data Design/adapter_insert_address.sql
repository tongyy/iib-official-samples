INSERT INTO ADAPTER_ADDRESS
  VALUES ('add1', 'MP211', 'IBM Hursley Park', 'SO21 2JN', 'Winchester', 'GB')