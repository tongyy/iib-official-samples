--<ScriptOptions statementTerminator=";"/>
DELETE FROM ADAPTER_ADDRESS WHERE PKEY='add01';