--<ScriptOptions statementTerminator=";"/>
INSERT INTO ADAPTER_ADDRESS
  VALUES ('add0', '301', 'Cobblestone Way', '1', 'Bedrock', 'Rock');

INSERT INTO ADAPTER_CUSTOMER
  VALUES ('cust0', 'Fred', 'Flintstone', 'add0', 'Dev');
  
INSERT INTO ADAPTER_INVOICE 
  VALUES ('inv0', 'Paper', 300, 'cust0');