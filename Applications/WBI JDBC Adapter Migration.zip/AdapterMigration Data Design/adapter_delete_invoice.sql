--<ScriptOptions statementTerminator=";"/>
DELETE FROM ADAPTER_INVOICE WHERE PKEY='inv1';