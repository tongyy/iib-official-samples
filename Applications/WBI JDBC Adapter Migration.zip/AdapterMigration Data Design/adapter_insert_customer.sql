INSERT INTO ADAPTER_CUSTOMER
  VALUES ('cust1', 'Beloved', 'Customer', 'add1', 'GB')