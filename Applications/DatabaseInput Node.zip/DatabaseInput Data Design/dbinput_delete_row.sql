--<ScriptOptions statementTerminator=";"/>
DELETE FROM DBINPUT_CUSTOMER WHERE PKEY='cust1';