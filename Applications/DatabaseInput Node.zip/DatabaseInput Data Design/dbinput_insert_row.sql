--<ScriptOptions statementTerminator=";"/>
INSERT INTO DBINPUT_CUSTOMER
  VALUES ('cust1', 'Fred', 'Flintstone', 'Dev');