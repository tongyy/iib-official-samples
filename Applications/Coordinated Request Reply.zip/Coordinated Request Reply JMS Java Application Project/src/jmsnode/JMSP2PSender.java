/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/


package jmsnode;

import javax.jms.*;                 // JMS interfaces
import javax.naming.*;              // Used for JNDI lookup of
import javax.naming.directory.*;    //    administered objects
import java.util.*;                 // Java Util classes

class JMSP2PSender {

    // using LDAP or file

    static String icf = "com.sun.jndi.fscontext.RefFSContextFactory";  // initial context factory
    static String url = "file:/C:/JNDI-Directory";

    private static String qcfLookup = "qcf1";  // QueueConnectionFactory (QCF) lookup
    private static String qLookup   = "GET_JMS_REQREP_IN";    // queue lookup

    // Pub/Sub objects used by this program

    private static ConnectionFactory fact = null;
    private static Destination queue = null;

    @SuppressWarnings("unchecked")
	public static void main(String args[])
    {
       Message myMessage = null;
        // Initialize JNDI properties
       @SuppressWarnings("rawtypes")
	Hashtable env = new Hashtable();
       env.put( Context.INITIAL_CONTEXT_FACTORY, icf );
       env.put( Context.PROVIDER_URL, url );
       env.put( Context.REFERRAL, "throw" );

       Context ctx = null;
       try {
           System.out.println( "Initialising JNDI... " );
           ctx = new InitialDirContext( env );
           System.out.println( "Done!" );
       } catch ( NamingException nx ) {
           System.out.println( "ERROR: " + nx );
           System.exit(-1);
       }

        // Lookup QCF
       try {
           System.out.println( "Obtaining QCF from JNDI... " );
           ConnectionFactory connFact = (ConnectionFactory) ctx.lookup( qcfLookup );
           fact = connFact;
           System.out.println( "Done!" );
       } catch ( NamingException nx ) {
           System.out.println( "ERROR: " + nx );
           System.exit(-1);
       }
        // Lookup queue
       try {
           System.out.println( "Obtaining Q from JNDI... " );
           queue = (Destination)ctx.lookup( qLookup );
           System.out.println( "Done!" );
       } catch ( NamingException nx ) {
           System.out.println( "ERROR: " + nx );
           System.exit(-1);
       }

       try {
           ctx.close();
       } catch ( NamingException nx ) {
            // Just ignore an exception on closing the context
       }
       try {
           // Create connection
           Connection conn = fact.createConnection();
           if (conn != null) System.out.println( "Created JMS Connection... " );

           // Start connection
           conn.start();
           // Session
           Session sess = conn.createSession(false,Session.AUTO_ACKNOWLEDGE);
           if (sess != null) System.out.println( "Created JMS Session... " );

           // Sender
           MessageProducer sender = sess.createProducer(queue);
           if (sender != null) System.out.println( "Created JMS Producer.. " );
           myMessage =  sess.createTextMessage();
           myMessage.setJMSMessageID("sss");
           myMessage.setJMSExpiration(1000);
           long timeValue = 1168239349617L;
           myMessage.setJMSTimestamp(timeValue);
	    
           System.out.println( "Now sending Message" );
           
           String jmsmsg = "<?xml version=\"1.0\" encoding=\"utf-8\"?> " + "<SaleEnvelope><Header><SaleListCount>1</SaleListCount></Header><SaleList><Invoice><Initial>K</Initial><Initial>A</Initial><Surname>Braithwaite</Surname><Item><Code>00</Code><Code>01</Code><Code>02</Code><Description>Twister</Description><Category>Games</Category><Price>30</Price><Quantity>01</Quantity></Item><Item><Code>02</Code><Code>03</Code><Code>01</Code><Description>The Times Newspaper</Description><Category>Books and Media</Category><Price>20</Price><Quantity>01</Quantity></Item><Balance>50</Balance><Currency>Sterling</Currency></Invoice><Invoice><Initial>T</Initial><Initial>J</Initial><Surname>Dunnwin</Surname><Item><Code>04</Code><Code>05</Code><Code>01</Code><Description>The Origin of Species</Description><Category>Books and Media</Category><Price>22</Price><Quantity>02</Quantity></Item><Item><Code>06</Code><Code>07</Code><Code>01</Code><Description>Microscope</Description><Category>Miscellaneous</Category><Price>36</Price><Quantity>01</Quantity></Item><Balance>80</Balance><Currency>Euros</Currency></Invoice></SaleList><Trailer><CompletionTime>12.00.00</CompletionTime></Trailer></SaleEnvelope>";
           ((TextMessage)myMessage).setText(jmsmsg);
           sender.setDeliveryMode(DeliveryMode.PERSISTENT);
           sender.setPriority(7);
           // sender.
           System.out.println( "Sending - Message ReplyQueue");

              sender.send(myMessage);
              System.out.println( "After Send Message ID = " + myMessage.getJMSMessageID());

            System.out.println( "Finished Sending - Closing JMS Resources" );

            // Close publishers and subscribers
            sender.close();
	    
            sess.close();
            conn.close();

            System.exit(0);

        }
        catch ( JMSException je ) {
            System.out.println("ERROR: " + je);
            System.out.println("LinkedException: " +
                                       je.getLinkedException());
            System.exit(-1);
        }
    }
}


