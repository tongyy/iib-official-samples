#!/bin/sh

# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2011. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.

mqsichangeproperties IB9NODE -c JMSProviders -o WebSphere_MQ -n connectionFactoryName -v qcf1
mqsichangeproperties IB9NODE -c JMSProviders -o WebSphere_MQ -n jndiBindingsLocation -v file:////home/root/JNDI-Directory 