/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2012
Licensed Materials - Property of IBM
*/

import com.ibm.broker.javacompute.MbJavaComputeNode;

import com.ibm.broker.plugin.*;
import java.util.ListResourceBundle;



public class RestoreOriginalMQMD_JavaCompute extends MbJavaComputeNode  {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbMessage message = new MbMessage(assembly.getMessage());
		


		// use the CorrelId, which is the original request message MsgId as the key to retrieve the MQMD 
		String correlId = message.getRootElement().getFirstElementByPath("/MQMD/CorrelId").getValueAsString();	
		
		// Retrieve the MQMD from the global cache.
	     byte[] retrieveMQMD = (byte[]) MbGlobalMap.getGlobalMap().get(correlId);
	     if (retrieveMQMD == null)
	     {
	    	throw new MbUserException(this,
                      "evaluate",
                      GlobalCacheMessages.MESSAGE_SOURCE,
	                  GlobalCacheMessages.DATA_NOT_FOUND, 
	     	          "Tried to get MQMD header from global cache, but could not retrieve the data",
	    	          new String[] {correlId});
	     	        
	   	 }
	 
	     		 
		// Attach the MQMD to the end of the message tree 
		MbElement mqmd = message.getRootElement().createElementAsLastChildFromBitstream(
			(retrieveMQMD),
			MbMQMD.PARSER_NAME,
			null, null, null,
			0, 0, 0
		);
		
		//detach the MQMD
		mqmd.detach();

		// The message root has three children. (1) Properties, (2) MQMD, (3) Body
		// delete existing MQMD
		message.getRootElement().getFirstElementByPath("/MQMD").delete();

		// Root now has two children: (1) Properties, (2) Body
		// insert the new MQMD.
		message.getRootElement().getFirstElementByPath("/Properties").addAfter(mqmd);

		// Now root again has (1) Properties, (2) MQMD, (3) Body
		// Note that the message's MsgId is now the original request message MsgId.
	
		getOutputTerminal("out").propagate(new MbMessageAssembly(assembly, message));

	}
	  
	  /**
	   * The class is the ResourceBundle containing all the messages for this example.
	   */
	  public static class GlobalCacheMessages extends ListResourceBundle
	  {
	    public static final String MESSAGE_SOURCE = GlobalCacheMessages.class.getName();                                                
	    public static final String DATA_NOT_FOUND = "DATA NOT FOUND";

	
	    
	    private Object[][] messages  = {{DATA_NOT_FOUND, "Data not found in global cache for key {0}" },	                                    
	                                   };

	    /* (non-Javadoc)
	     * @see java.util.ListResourceBundle#getContents()
	     */
	    public Object[][] getContents()
	    {
	      return messages;
	    }
	  }
}
