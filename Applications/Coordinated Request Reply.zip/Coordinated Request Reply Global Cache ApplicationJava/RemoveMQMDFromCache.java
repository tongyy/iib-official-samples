/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2012
Licensed Materials - Property of IBM
*/

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


public class RemoveMQMDFromCache extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbMessage message = new MbMessage(assembly.getMessage());

		// MsgID is used as a key to remove the MQMD from the global cache
		String msgId = message.getRootElement().getFirstElementByPath("/MQMD/MsgId").getValueAsString();	

		// cleanup and remove the MQMD data from the cache 
		MbGlobalMap.getGlobalMap().remove(msgId);
	}

}
