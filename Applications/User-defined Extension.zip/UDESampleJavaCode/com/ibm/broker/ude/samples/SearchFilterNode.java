/* 
 * Sample program for use with Product          
 *  ProgIds: 5724-J06 5724-J05 5724-J04 5697-J09 5655-M74 5655-M75 5648-C63 
 *  (C) Copyright IBM Corporation 2005.                      
 * All Rights Reserved * Licensed Materials - Property of IBM 
 * 
 * This sample program is provided AS IS and may be used, executed, 
 * copied and modified without royalty payment by customer 
 * 
 * (a) for its own instruction and study, 
 * (b) in order to develop applications designed to run with an IBM 
 *     WebSphere product, either for customer's own internal use or for 
 *     redistribution by customer, as part of such an application, in 
 *     customer's own products. 
 */ 
/*Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation xxxx, yyyy 
Licensed Materials - Property of IBM */

package com.ibm.broker.ude.samples;

import com.ibm.broker.plugin.*;

import java.io.*;

public class SearchFilterNode extends MbNode implements MbNodeInterface {

	public SearchFilterNode() throws MbException {
		createInputTerminal("In");
		createOutputTerminal("True");
		createOutputTerminal("False");
		createOutputTerminal("Unknown");
		createOutputTerminal("Failure");
	}
	
	public void evaluate(MbMessageAssembly assembly, MbInputTerminal in)
			throws MbException {

		// The incoming message assembly and its embedded messages are read-only.
		// New objects must be created using the copy constructors
		MbMessage newMsg = new MbMessage(assembly.getMessage());

		// Get the LocalEnvironment from the input message (used if searchName is not found)
		MbMessage env = assembly.getLocalEnvironment();

		// Create a LocalEnvironment for the output message
		MbMessage newEnv = new MbMessage(env);
		
		// indicate that the search name has not yet been found
		boolean result = false;
		MbOutputTerminal terminal = getOutputTerminal("False");
		
		//Find the top of the message body: <Message1>
		MbElement topOfBody = newMsg.getRootElement().getLastChild().getFirstChild();
		
		//Find the search name: <SearchName>
		String searchName = topOfBody.getFirstChild().getValue().toString();

		//Find the total customers: <TotalCustomers>
		Long totalCustomers = new Long(topOfBody.getFirstChild().getNextSibling().getValue().toString());
		
		int counter = 1, total = (int) totalCustomers.longValue();
	
		try {			
			// navigate to the first customer in the message: <Customer1>
			MbElement customerElement = topOfBody.getFirstChild().getNextSibling().getNextSibling();
									
			// navigate through the message looking for the search name
			while (!(customerElement.getFirstChild().getValue().equals(searchName)) && (counter < total)) {
				customerElement = customerElement.getNextSibling();
				counter++;
			}
			
			// if the search name was found then add <Result> tag to output message
			if (customerElement.getFirstChild().getValue().equals(searchName)) {
				// indicate that the search name has been found
				result = true;
				
				// construct a concatenation of 5 full names using String Buffer
				// as this has improved performance over ordinary String concatenation
				StringBuffer fiveNames = new StringBuffer();
				fiveNames.append(customerElement.getLastChild().getValue());
				fiveNames.append(" ");
				fiveNames.append(searchName);
				fiveNames.append(" ");
				
				searchName = fiveNames.toString();
				
				for (counter = 0; counter < 4; counter++) {
					fiveNames.append(searchName);
				}
				
				// Add a new <Result> tag to output message as the last child of <Message1>
				topOfBody.createElementAsLastChild(MbElement.TYPE_NAME, "Result", fiveNames.toString());				

				terminal = getOutputTerminal("True");
			}
		}
		catch (MbException mbe) {
            // To aid debugging, text can be printed to stdout/stderr.
            // On Windows this can be viewed by selecting 'Allow sevice to interact with
            // desktop' on the Windows Services properties dialog for the broker.
            // On Unix set the environment variable MQSI_RUN_ATTACHED=1 before
            // starting the broker.

			StringWriter stringWriter = new StringWriter();
			PrintWriter printWriter = new PrintWriter(stringWriter);
			mbe.printStackTrace(printWriter);
			StringBuffer error = stringWriter.getBuffer();

            System.out.println("MbException thrown in evaluate() method of SearchFilterNode UDE sample.");
            System.out.println("Stack trace follows...");
            System.out.println(error.toString());		
        }
		
		MbMessageAssembly newAssembly = new MbMessageAssembly(assembly, newEnv, assembly.getExceptionList(), newMsg);

		if (!result) {
			// invoke ESQL to set variable in LocalEnvironment scratchpad to be "Not found"
			String statement = "SET OutputLocalEnvironment.Result = 'Not found';";
			MbSQLStatement sql = createSQLStatement("", statement);
			sql.select(assembly, newAssembly);
		}
		
		terminal.propagate(newAssembly);
	}

	public static String getNodeName() {
		return "SearchFilterNode";
	}
}
