/* 
 * Sample program for use with Product          
 *  ProgIds: 5724-J06 5724-J05 5724-J04 5697-J09 5655-M74 5655-M75 5648-C63 
 *  (C) Copyright IBM Corporation 2005.                      
 * All Rights Reserved * Licensed Materials - Property of IBM 
 * 
 * This sample program is provided AS IS and may be used, executed, 
 * copied and modified without royalty payment by customer 
 * 
 * (a) for its own instruction and study, 
 * (b) in order to develop applications designed to run with an IBM 
 *     WebSphere product, either for customer's own internal use or for 
 *     redistribution by customer, as part of such an application, in 
 *     customer's own products. 
 */ 

#ifndef NODE_FACTORY_H
#define NODE_FACTORY_H

#ifdef __cplusplus
extern "C" {
#endif

#include <BipCni.h>

#define CONST_PLUGIN_NODE_FACTORY            "ComIbmSamplePluginNodeFactory"
const CciChar * constPluginNodeFactory      = 0;


#ifdef __cplusplus
}
#endif

#endif
