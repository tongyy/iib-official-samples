/* 
 * Sample program for use with Product          
 *  ProgIds: 5724-J06 5724-J05 5724-J04 5697-J09 5655-M74 5655-M75 5648-C63 
 *  (C) Copyright IBM Corporation 2005.                      
 * All Rights Reserved * Licensed Materials - Property of IBM 
 * 
 * This sample program is provided AS IS and may be used, executed, 
 * copied and modified without royalty payment by customer 
 * 
 * (a) for its own instruction and study, 
 * (b) in order to develop applications designed to run with an IBM 
 *     WebSphere product, either for customer's own internal use or for 
 *     redistribution by customer, as part of such an application, in 
 *     customer's own products. 
 */ 

/* Includes */
/* <malloc.h> is not available on /390 */
#ifndef __MVS__
  #include <malloc.h>
#endif
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <NodeFactory.h>
#include <Common.h>
#include <NumComputeNode.h>

/******************************************************************************/
/*                                                                            */
/* Plugin Node Implementation Function:                              cniRun() */
/*                                                                            */
/* This is an example framework for a plugin input node. We simulate reading  */
/* data from an external source and attach the buffer containing that data to */
/* the CciMessage object, passing that into the message flow by invoking the  */
/* cniPropagate() function to send the message to the terminal named "out".   */
/******************************************************************************/
int _Input_run(
  CciContext* context,
  CciMessage* destinationList,
  CciMessage* exceptionList,
  CciMessage* message
){
  static char* functionName = (char *)"_Input_run()";
  void*        buffer;
  CciTerminal* terminalObject;
  int          buflen = 4096;
  int          rc = CCI_SUCCESS;
  int          rcDispatch = CCI_SUCCESS;
  char         xmlData[] = "<A>data</A>"; 

  /* Obtain data from external source. For the purpose of this example, which */
  /* does not actually interface to an external data source, we allocate a    */
  /* buffer on the heap and setting it's contents to simulate XML being read  */
  /* from the external source.                                                */
  buffer = malloc(buflen);
  memcpy(buffer, &xmlData, sizeof(xmlData)); 

  /* Attach the data buffer to the input message object */
  cniSetInputBuffer(&rc, message, buffer, buflen);

  /* This input node is capable of running on multiple threads, so we request */
  /* for a thread to be allocated from the thread pool associated with the    */
  /* message flow.                                                            */ 
  cniDispatchThread(&rcDispatch, ((NODE_CONTEXT_ST *)context)->nodeObject);

  /* Get handle of our output terminal */
  terminalObject = getOutputTerminalHandle( (NODE_CONTEXT_ST *)context,
                                            (CciChar*)constOut);

  /* If the terminal exists and is attached, propagate to it */
  if (terminalObject) {
    if (cniIsTerminalAttached(&rc, terminalObject)) {
      if (rc == CCI_SUCCESS) {
        cniPropagate(&rc, terminalObject, destinationList, exceptionList, message);
      }
    }

    /* If an exception occurred, then free the buffer and rethrow. The broker */
    /* then catches the exception, backs out any transaction and calls this   */
    /* implementation function again.                                         */
    if (rc == CCI_EXCEPTION) {
      free(buffer);
      cciRethrowLastException(&rc);
    }   
  }

  /* Free the buffer we acquired */
  free(buffer);

  /* Return to the broker indicating that any transaction is be committed. If */
  /* we were able to dispatch another thread, then the current thread gets    */
  /* returned to the pool by returning CCI_SUCCESS_RETURN. If another thread  */
  /* could not be dispatched, then we return CCI_SUCCESS_CONTINUE to indicate */  
  /* that we require this implementation function to be called immediately    */
  /* afterwards on the same thread.                                           */
  if (rcDispatch == CCI_NO_THREADS_AVAILABLE) return CCI_SUCCESS_CONTINUE;
  else return CCI_SUCCESS_RETURN;
}

/******************************************************************************/
/*                                                                            */
/* Plugin Node Utility function:                                              */
/*                                                                            */
/*  initNodeConstants                                                         */
/*                                                                            */
/*  Creates Cci constant strings from defined char * constant strings.        */
/*                                                                            */
/******************************************************************************/
void initNodeConstants(
  void
){
  constZero                   = CciString(CONST_ZERO, BIP_DEF_COMP_CCSID);
  constNumComputeTraceLocation = CciString(CONST_NumCompute_TRACE_LOCATION, BIP_DEF_COMP_CCSID);
  constNumComputeNode          = CciString(CONST_NumCompute_NODE, BIP_DEF_COMP_CCSID);
  constPluginNodeFactory      = CciString(CONST_PLUGIN_NODE_FACTORY, BIP_DEF_COMP_CCSID);
  constNodeTraceOutfile       = CciString(CONST_NODE_TRACE_OUT_FILE, BIP_DEF_COMP_CCSID);
  constOut                    = CciString(CONST_OUT, BIP_DEF_COMP_CCSID);
  constFailure                = CciString(CONST_FAILURE, BIP_DEF_COMP_CCSID);
}

/******************************************************************************/
/*                                                                            */
/* Plugin Node Implementation Function:                                       */
/*                                                                            */
/* This function is called when the message broker loads the "lil" during the */
/* initialization of the broker engine.                                       */
/*                                                                            */
/* The responsibilities of the plug-in are to:                                */
/*  - create the node factory (or factories) which the "lil" supports, using  */
/*    the createNodeFactory() function, saving the returned pointer to the    */
/*    node factory for use at runtime.                                        */
/*  - define each node supported by the (or each) factory) and pass a pointer */
/*    to a function table which contains pointers to the node implementation  */
/*    functions.                                                              */
/*  - define the name of each attribute supported by each node, including a   */
/*    pointer to a validation function.                                       */
/*  - define input and output terminals supported by each node.               */
/*  - return the pointer to the factory, unless an error occurred, in which   */
/*    case zero should be returned.                                           */
/*                                                                            */
/******************************************************************************/
CciFactory LilFactoryExportPrefix * LilFactoryExportSuffix bipGetMessageflowNodeFactory()
{
  static char* functionName = (char *)"bipGetMessageflowNodeFactory()";
  CciFactory*      factoryObject;
  int              rc = 0;
  CCI_EXCEPTION_ST exception_st = {CCI_EXCEPTION_ST_DEFAULT};

  /* Before we proceed we need to initialise all the static constants */
  /* that may be used by the plug-in.                                 */
  initNodeConstants();

  /* Create the Node Factory for this plug-in */
  factoryObject = cniCreateNodeFactory(0, (unsigned short *)constPluginNodeFactory);
  if (factoryObject == CCI_NULL_ADDR) {
    if (rc == CCI_EXCEPTION) {
      /* Get details of the exception */
      memset(&exception_st, 0, sizeof(exception_st));
      cciGetLastExceptionData(&rc, &exception_st);

      /* Any local error handling may go here */

      /* Rethrow the exception */
      cciRethrowLastException(&rc);
    }
    /* Any further local error handling can go here */
  }
  else {
    /* Define the nodes supported by this factory */
    defineNumComputeNode(factoryObject);
  }

  /* Return address of this factory object to the broker */
  return(factoryObject);
}

