/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package com.ibm.broker.sample;

/*
 * This class contains method(s) to do some custom processing of elements of the 
 * message in the Graphical Data Mapping Retail Sample.
 */
public class GDMRetail {

	/**
	 * This method shows calling into Java to do some custom processing 
	 * @param in store code number to process  
	 */
	public static int convertStoreCode(int inputStoreCode) {
		return(inputStoreCode + 1000);
	}
	
	/**
	 * This method shows calling into Java to do some custom processing 
	 * @param in String to trim and uppercase  
	 */
	public static String convertStoreName(String inputStoreName) {
		return(inputStoreName.trim().toUpperCase());
	}
	
	/**
	 * This method shows calling into Java to do some custom processing 
	 * @param in store code number to process  
	 */
	public static int convertDeptId(int inputDeptId) {
		return(inputDeptId + 100);
	}
	
}

