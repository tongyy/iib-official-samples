<?php
/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2009, 2010 
Licensed Materials - Property of IBM
*/
class PHPTransform {

    /**
     * Transformation of invoice messages.
     * 
     * @MessageBrokerSimpleTransform
     */
    function evaluate($output_assembly, $input_assembly) {
    	// For each SaleList element in SaleEnvelope
		foreach ($input_assembly->XMLNSC->SaleEnvelope->SaleList as $sale_list) {
			// In PHP the [] notation appends a new entry to an array. If the array does not exist the array is created.
			$output_assembly->XMLNSC->SaleEnvelope->SaleList[] = $this->transformSaleList($sale_list);
		}
    }
	
	function transformSaleList($input) {
		$sale_list = new MbsElement;  
		
		// For each invoice element in this SaleList
		foreach ($input->Invoice as $invoice) {
			$sale_list->Statement[] = $this->transformInvoice($invoice);
		}
		return $sale_list;
	}
	
	function transformInvoice($input) {
		$statement = new MbsElement;

		// Add 'Type' and 'Style' attributes to the statement element.
		$statement['Type'] = 'Monthly';
		$statement['Style'] = 'Full';
		
		// getValue() returns the contents of an element
		$statement->Customer->Initials = $input->Initial[0]->getValue() .  $input->Initial[1]->getValue();
		$ref = $statement->Customer;
		$ref->Name = $input->Surname;
		$ref->Balance = $input->Balance;

		$total = 0;

		// For eacb item in the invoice
		foreach ($input->Item as $item) {
			$statement->Purchases->Article[] = $this->transformItem($item);
			$total += $item->Price->getValue() * $item->Quantity->getValue() * 1.6;
		}

		$statement->Amount['Currency'] = $input->Currency;
		$statement->Amount = number_format($total, 2);
		return $statement;
	}
	
	function transformItem($input) {
		$item = new MbsElement;
		$item->Desc = $input->Description;
		$item->Cost = number_format($input->Price->getValue() * 1.6, 2);
		$item->Qty = $input->Quantity;

		return $item;
	}
}

?>
