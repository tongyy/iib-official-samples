/*********************************************************************/
/*  Module Name           : legacyservice.c                          */
/*                                                                   */
/*                                                                   */
/*  Parameters            : Takes 2 arguments                        */
/*                           QueueManagerName                        */
/*                           QueueName                               */
/*                                                                   */
/*  Description : Sample program to get a messages from a queue and  */
/*                reply as follows                                   */
/*                - if input MessageType is IA81BUY or               */
/*                     with IA81CONF.Confirm set based on content of */
/*                     IA81BUY.ItemReference                         */ 
/*                - if input MessageType is IA81ORD send no response */
/*                - if input MessageType is IA81ASKP send IA81PRI    */
/*                     with IA81PRI.ItemUnitPrice set to a           */
/*                     randomly generated value                      */ 
/*                - if input MessageType is BIMBQRYP send BIMBQRYR   */
/*                     with BIMBQRYR.DeliverDate set and             */
/*                     BIMBQRYR.TotalPrice calculated based on input */ 
/*                     prices and numbers - a discount (15%)         */
/*                - else put an error message to stdout and continue */
/*                                                                   */
/*                                                                   */
/*  History        30/12/2002   : Written                            */
/*                 10/07/2003   : Added support for IA81ASKP and     */
/*                                BIMBQRPY                           */
/*                 16/01/2004  :  Added JMS / MQRFH2 tolerance       */
/*                                (if RFH2 received, it is returned) */
/*                 11/03/2004  :  Modified tolerance to include      */
/*                                any header with MQMD.Format        */
/*                                starting 'MQH'                     */
/*                 10/02/2005  :  Added support for IA81CONF as      */
/*                                an input format returning IA81CONF */
/*                                                                   */
/*********************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "legacyservice.h"
#include "legacyservice2.h"
#include "cmqc.h"

#define WAIT_INTERVAL   1000 * 60 * 30      /* 30 minutes               */
#define MESSAGE_ID_LENGTH  8                /* for all message types    */
#define MESSAGE_BUFFER_LENGTH 1024          /* for variable length msgs */
#define MESSAGE_BUFFER_LENGTH2 2048         /* for variable length msgs */

   MQHCONN  HConn = MQHC_DEF_HCONN;         /* Connection handle        */
   MQHOBJ   HObj_CheckQ;                    /* Object handle            */
   MQLONG   CompCode;                       /* Completion code          */
   MQLONG   Reason;                         /* Qualifying reason        */
   MQOD     ObjDesc    = {MQOD_DEFAULT};    /* Object descriptor        */
   MQMD     MsgDesc    = {MQMD_DEFAULT};    /* Message descriptor       */
   MQLONG   OpenOptions;                    /* Control the MQOPEN call  */

   MQGMO    GetMsgOpts = {MQGMO_DEFAULT};   /* Get-Message Options      */
   MQLONG   MsgBuffLen;                     /* Length of message buffer */
   char     APIMessageBuffer??(MESSAGE_BUFFER_LENGTH2??);
										/* where the message starts */ 
   char     InputMsgBuffer??(MESSAGE_BUFFER_LENGTH??);
										/* where the message data starts */ 
   IA81BUY  MsgBuffer;                      /* Message structure        */
   IA81ASKP MsgBuffer2;                     /* Message structure        */
   char     MsgBuffer3??(MESSAGE_BUFFER_LENGTH??);   
											/* Input buffer for parts   */
   char     TempBuffer3??(MESSAGE_BUFFER_LENGTH??);   
											/* Buffer for parts         */
   MQLONG   DataLen;                        /* Length of message        */
   MQLONG   Msg3Len;                        /* Length of message        */

   MQPMO    PutMsgOpts = {MQPMO_DEFAULT};   /* Put-Message Options      */
   IA81CONF PutBuffer;                      /* Message structure        */
   MQLONG   PutBuffLen = sizeof(PutBuffer);
                                        /* Length of message buffer */
   IA81PRI  PutBuffer2;                     /* Message structure        */
   MQLONG   PutBuff2Len = sizeof(PutBuffer2);
                                        /* Length of message buffer */
   BIMBQRYR PutBuffer3;						/* Message structure        */
   MQLONG   PutBuff3Len = sizeof(PutBuffer3);
                                        /* Length of message buffer */
   int      RFHflag = 0;                /* Is there an RFH header on the 
										   received message 0=NO, 1=YES */ 

/*   function prototypes                                             */
void usageError( char* programName );
void errorMessage( char* msgStr, MQLONG CC, MQLONG RC );
void ProcessOrder(void);
void ProcessQuote(void);
void ProcessPartQuery(void);
void FindUnitPrice(void);
void FindDeliveryDate(void);
void CalculateTotalPrice(void);
void PutReplyMsg(char *ReplyMsg, MQLONG ReplyLength);


MQLONG main( int argc, char** argv )
{

   int flag = 0;		
   /* parameter variables                                            */
   MQCHAR48 qMgr;
   MQCHAR48 qName;
   
   memset( qMgr,  '\0', MQ_Q_MGR_NAME_LENGTH );
   memset( qName, '\0', MQ_Q_NAME_LENGTH );

   
   /*                                                                */
   /*  Move parameters into corresponding variables                  */
   /*                                                                */
   switch( argc )
      {
      case  3 : strncpy( qName, argv??( 2 ??), MQ_Q_NAME_LENGTH );
		        strncpy( qMgr,  argv??( 1 ??), MQ_Q_MGR_NAME_LENGTH );
	           
                break;
      default : usageError( argv??( 0 ??) );
                return 8;
      }

   /*                                                                */
   /*  Display the parameters to be used in the program              */
   /*                                                                */
   printf( "===========================================\n" );
   printf( "PARAMETERS PASSED :\n" );
   printf( "   QNAME       - %s\n", qName );
   printf( "   QMGR        - %s\n", qMgr );
   printf( "===========================================\n" );

   /*                                                                */
   /*   Connect to Queue Manager (MQCONN)                            */
   /*                                                                */
   MQCONN( qMgr,
           &HConn,
           &CompCode,
           &Reason     );
   /*                                                                */
   /*  If connect failed then display error message and exit         */
   /*                                                                */
   if( MQCC_OK != CompCode )
      {
      errorMessage( "MQCONN", CompCode, Reason );
      return Reason;
      }

   printf( "MQCONN SUCCESSFUL\n" );

   /*                                                                */
   /* Initialize options and open the queue for input                */
   /*                                                                */

   OpenOptions = MQOO_INPUT_SHARED +
                 MQOO_SAVE_ALL_CONTEXT;

   strncpy(ObjDesc.ObjectName, qName, MQ_Q_NAME_LENGTH);

   MQOPEN(HConn,
          &ObjDesc,
          OpenOptions,
          &HObj_CheckQ,
          &CompCode,
          &Reason);

   /*                                                                */
   /* Test the output from the open, if not OK then build an error   */
   /* message                                                        */
   /*                                                                */

   if (CompCode != MQCC_OK)
      errorMessage( "MQOPEN", CompCode, Reason );
   else
      {
      /*                                                             */
      /* Get and process messages                                    */
      /*                                                             */
      printf( "MQOPEN SUCCESSFUL\n" );

      GetMsgOpts.Options = MQGMO_WAIT +
                           MQGMO_FAIL_IF_QUIESCING +
						   MQGMO_ACCEPT_TRUNCATED_MSG +
                           MQGMO_SYNCPOINT;
      GetMsgOpts.WaitInterval = WAIT_INTERVAL;
      MsgBuffLen = sizeof(APIMessageBuffer);

      memcpy(MsgDesc.MsgId, MQMI_NONE, sizeof(MsgDesc.MsgId));
      memcpy(MsgDesc.CorrelId, MQCI_NONE, sizeof(MsgDesc.CorrelId));

      /*                                                             */
      /* Make the first get call outside the loop                    */
      /*                                                             */

      MQGET(HConn,
            HObj_CheckQ,
            &MsgDesc,
            &GetMsgOpts,
            MsgBuffLen,
            &APIMessageBuffer,
            &DataLen,
            &CompCode,
            &Reason);

      /*                                                             */
      /* Test the output of the get call inside the do-while loop.   */
      /* Loop until the get call fails.                              */
      /*                                                             */

      while (CompCode != MQCC_FAILED)
         {
         /*                                                          */
         /* Handle the message                                       */
         /*                                                          */
         printf( "MQGET SUCCESSFUL\n" );
		 /*                                                          */
         /* Does the message have an MQRFH2 ?                        */
         /*                                                          */
		 RFHflag = 0;
           if ( (strncmp(MsgDesc.Format, "MQH", 3 ) == 0) || (strncmp(MsgDesc.Format, "JJH", 3 ) == 0) )

/*		 if (strncmp( (const char *)&APIMessageBuffer, MQRFH_STRUC_ID, 4 ) == 0) */
		 {
			printf("MQMD.Format starts MQH\n");
			/* move the message content to InputMsgBuffer            */
			memcpy(&InputMsgBuffer, 
				   (APIMessageBuffer + ((MQRFH2 *)APIMessageBuffer)->StrucLength) , 
				    ( (sizeof(APIMessageBuffer) - 
				        ((MQRFH2 *)APIMessageBuffer)->StrucLength ) ) );
			RFHflag = 1;
		 }
		 else
		 {	 
			printf("No header found\n  MsgDesc.Format = '%8.8s'\n", MsgDesc.Format);
			memcpy(&InputMsgBuffer, &APIMessageBuffer, DataLen ) ; 
		 }
		 
         /*                                                          */
         /* Handle messages for IA81 legacy applications             */
         /*                                                          */
         if (strncmp(InputMsgBuffer,
                     BUY_MESSAGE, MESSAGE_ID_LENGTH) == 0)
		 {
			memcpy(&MsgBuffer, &InputMsgBuffer, sizeof(MsgBuffer));
			printf("  going to ProcessOrder\n");
            ProcessOrder();
			flag = 1;
		 }
		 if (strncmp(InputMsgBuffer,
                     CONFIRMATION_MESSAGE, MESSAGE_ID_LENGTH) == 0)
		 {
			memcpy(&MsgBuffer, &InputMsgBuffer, sizeof(MsgBuffer));
			printf("  going to ProcessOrder\n");
            ProcessOrder();
			flag = 1;
		 }
         if (strncmp(InputMsgBuffer,
                     ORDER_MESSAGE, MESSAGE_ID_LENGTH) == 0)
         {
			printf("  going to do nothing\n");
            flag = 1;  /* do nothing */ 
         } 
		 if (strncmp(InputMsgBuffer,
                     REQUEST_PRICE, MESSAGE_ID_LENGTH) == 0)
		 {
            memcpy(&MsgBuffer2, &InputMsgBuffer, sizeof(MsgBuffer2));
			printf("  going to ProcessQuote\n");
            ProcessQuote();
			flag = 1;
		 }
         /*                                                          */
         /* Handle messages for WBIMB Update class                   */
         /*                                                          */
		 if (strncmp(InputMsgBuffer,
                     WBIMB_QUERY_PART, MESSAGE_ID_LENGTH) == 0)
		 {
            memset(&TempBuffer3, ' ', sizeof(TempBuffer3));
            memcpy(&TempBuffer3, &InputMsgBuffer, sizeof(TempBuffer3));
            printf("  going to ProcessPartQuery\n");
			ProcessPartQuery();
			flag = 1;
		 }
		 /* else report an error as message is not ours */
         if ( flag != 1 ) 
		 {
           errorMessage( "Unknown message type", CompCode, Reason );
		 }


		 MQCMIT( HConn, &CompCode, &Reason );
         /*                                                             */
         /*   If commit failed then display error message               */
         /*                                                             */
         if( MQCC_OK != CompCode )
		 {
           errorMessage( "MQCMIT", CompCode, Reason );
         } /* else */    ;

         /*                                                          */
         /* Reset parameters for the next get call                   */
         /*                                                          */
		 flag = 0;  
		 RFHflag = 0;
         memset(&APIMessageBuffer, ' ', sizeof(APIMessageBuffer));
		 memset(&InputMsgBuffer, ' ', sizeof(InputMsgBuffer));
         memcpy(MsgDesc.MsgId, MQMI_NONE, sizeof(MsgDesc.MsgId));
         memcpy(MsgDesc.CorrelId, MQCI_NONE, sizeof(MsgDesc.CorrelId));

         MQGET(HConn,
               HObj_CheckQ,
               &MsgDesc,
               &GetMsgOpts,
               MsgBuffLen,
               &APIMessageBuffer,
               &DataLen,
               &CompCode,
               &Reason);

         } /* end loop */

      /*                                                             */
      /* Test the output of the get call.  If the call failed,       */
      /* send an error message showing the completion code and       */
      /* reason code, unless the reason code is NO_MSG_AVAILABLE.    */
      /*                                                             */

      if (Reason != MQRC_NO_MSG_AVAILABLE)
         {
           errorMessage( "MQGET ", CompCode, Reason );
         }
         

      MQCLOSE(HConn,
              &HObj_CheckQ,
              MQCO_NONE,
              &CompCode,
              &Reason);

      if (CompCode != MQCC_OK)
      {
           errorMessage( "MQCLOSE", CompCode, Reason );
	  } 
   }
	return 0;
}

	  
	  
/*********************************************************************/
/*  This function develops a reply message and puts it on the        */
/*  reply queue, as specified in the input message.  If this         */
/*  operation fails, report the error and terminate                  */
/*********************************************************************/

void ProcessOrder(void)
   {
   /*                                                                */
   /* Build the reply message                                        */
   /*                                                                */

   memset(&PutBuffer, ' ', sizeof(PutBuffer));
   memcpy(&PutBuffer, &MsgBuffer, sizeof(MsgBuffer));
   /* decide to set the delivery reference and set it                */
   if (strncmp(InputMsgBuffer,
                     CONFIRMATION_MESSAGE, MESSAGE_ID_LENGTH) == 0)
   {
	   strncpy (PutBuffer.DeliveryRef , "JOHNCORP", sizeof(PutBuffer.DeliveryRef) ); 
   }
   
   strncpy(PutBuffer.MessageId, CONFIRMATION_MESSAGE, sizeof(PutBuffer.MessageId));

   /* decide whether to accept the order                             */

   if ( strchr( (char *)&PutBuffer.ItemReference, 'Y' ) != NULL )
   {
	   memset ( &PutBuffer.Confirm , 'Y', sizeof(PutBuffer.Confirm) ); 
   }
   else
	   memset ( &PutBuffer.Confirm , 'N', sizeof(PutBuffer.Confirm) );

   /*                                                                */
   /* Put the reply message                                          */
   /*                                                                */
   PutReplyMsg((char *)&PutBuffer, sizeof(PutBuffer));
 
   }


/*********************************************************************/
/*  This function develops a reply message and puts it on the        */
/*  reply queue, as specified in the input message.  If this         */
/*  operation fails, report the error and terminate                  */
/*********************************************************************/

void ProcessQuote(void)
   {
   /*                                                                */
   /* Build the reply message                                        */
   /*                                                                */

   memset(&PutBuffer2, ' ', sizeof(PutBuffer2));
   memcpy(&PutBuffer2, &MsgBuffer2, sizeof(MsgBuffer2));
   strncpy(PutBuffer2.MessageId, PROVIDE_PRICE, sizeof(PutBuffer2.MessageId));

   /* Generate a price quotation                                     */ 
   FindUnitPrice() ;

   /*                                                                */
   /* Put the reply message                                          */
   /*                                                                */
   PutReplyMsg((char *)&PutBuffer2, sizeof(PutBuffer2));

   }

/*********************************************************************/
/*  This function develops a reply message and puts it on the        */
/*  reply queue, as specified in the input message.  If this         */
/*  operation fails, report the error and terminate                  */
/*********************************************************************/

void ProcessPartQuery(void)
   {
   /*                                                                */
   /* Build the reply message                                        */
   /*                                                                */

   memset(&PutBuffer3, ' ', sizeof(PutBuffer3));
   strncpy(PutBuffer3.MessageId, WBIMB_QUERY_PART_RESP, 
	   sizeof(PutBuffer3.MessageId));
   memcpy(PutBuffer3.OrderNumber, 
	   ((BIMBQRYP *)TempBuffer3)->OrderNumber, 
	   sizeof(PutBuffer3.OrderNumber));

   /* Find Delivery Date                                             */ 
   FindDeliveryDate() ;
   
   /* Generate a price quotation                                     */ 
   CalculateTotalPrice() ;
   
   /*                                                                */
   /* Put the reply message                                          */
   /*                                                                */
   PutReplyMsg((char *)&PutBuffer3, sizeof(PutBuffer3));


   }


/*********************************************************************/
/*  This function computes a random credit index based on a number   */
/*  obtained by calling the rand() function supplied by the stdlib.h */
/*  library.  The resulting message line is added to the reply       */
/*  message.                                                         */
/*********************************************************************/

 void FindUnitPrice(void)
   {

   int    RandNum;
   time_t t1;
   struct tm *t2;

   /*                                                                */
   /* Generate the unitprice                                         */
   /*                                                                */
   /* The srand() function sets the point for producing a series of  */
   /* pseudo-random integers.  The time (in seconds) is used to seed */
   /* the generator.                                                 */
   /*                                                                */

   t1 = time(NULL);
   t2 = localtime(&t1);

   srand(t2 -> tm_sec);

   RandNum = (rand()) * 5;

   sprintf(PutBuffer2.ItemUnitPrice, "%8d", RandNum);
   
   return;
   }           

/*********************************************************************/
/*  This function computes the total cost of the items in a          */
/*  WBIMB_QUERY_PART request message                                 */
/*********************************************************************/

 void CalculateTotalPrice(void)
   {

   int i;  
   int offset;
   BIMBPART  Parts??(10??);
   int TotalPrice = 0;
   int Discount = 15;

    offset = sizeof(BIMBQRYP);

	for (i = 0; i < ((BIMBQRYP *)TempBuffer3)->RepeatCount ; i++)  
	{
		strncpy( Parts??(i??).PartNumber, &TempBuffer3??(offset??),
			sizeof(Parts??(i??).PartNumber) );
		offset += sizeof(Parts??(i??).PartNumber);
/*		printf("end PartNumber %d \n", i);
		printf("offset - %d  \n", offset );
*/
	}
	for (i = 0; i < ((BIMBQRYP *)TempBuffer3)->RepeatCount ; i++)  
	{
		Parts??(i??).Quantity = (int)TempBuffer3??(offset??);
		offset += sizeof(int);
/*		printf("Quantity-%d = %d\n", i, Parts??(i??).Quantity );
		printf("offset - %d  \n", offset );
*/
    }
	for (i = 0; i < ((BIMBQRYP *)TempBuffer3)->RepeatCount ; i++)  
	{
		strncpy( Parts??(i??).UnitPrice, &TempBuffer3??(offset??),
			sizeof(Parts??(i??).UnitPrice) );
		offset += sizeof(Parts??(i??).UnitPrice);
/*		printf("UnitPrice-%d %12.12s \n", i, Parts??(i??).UnitPrice);
		printf("offset - %d  \n", offset );
*/
	}

	for (i = 0; i < ((BIMBQRYP *)TempBuffer3)->RepeatCount ; i++)  
	{
		TotalPrice += 
			Parts??(i??).Quantity * atol((char *)Parts??(i??).UnitPrice);
/*		printf("TotalPrice-%d = %d \n", i, TotalPrice);  
*/
	}


    sprintf(PutBuffer3.TotalPrice, "%9.9d.%2.2d", 
	   ((TotalPrice * (100 - Discount)) / 100 ),
	   ((TotalPrice * (100 - Discount)) % 100 ) );
   
   return;
   }           

 
 
/*********************************************************************/
/*  This function estimates the delivery date for the order          */
/*********************************************************************/

 void FindDeliveryDate(void)
   {

   int    RandNum = 0;
   time_t t1;
   struct tm *t2;
   int    flag = 0;

   /*                                                                */
   /* Generate the delivery date                                     */
   /*                                                                */

   t1 = time(NULL);
   t2 = localtime(&t1);
   srand(t2 -> tm_sec);
 
   RandNum = (rand()) % 28;      /* max delivery 4 weeks - usually   */

   printf("***  RandNum = %d\n", RandNum);

   /* increment the delivery date         */
   t2->tm_mday += ( (t2->tm_mday + RandNum) % 28 );

   /* sort out end of month / end of year */
   if ( (t2->tm_mon == 1) && (t2->tm_mday + RandNum) > 28 ) 
   {
	   t2->tm_mday %= 28;  
	   flag = 1;
   }
   if ( ( (t2->tm_mon == 3) || (t2->tm_mon == 5) || 
	   (t2->tm_mon == 8) || (t2->tm_mon == 10) ) 
	   && ( (t2->tm_mday + RandNum) > 30 ) ) 
   {
	   t2->tm_mday %= 30;
	   flag = 1 ; 
   }
   if ( t2->tm_mday + RandNum > 31 ) 
   {
	   t2->tm_mday %= 31;
	   flag = 1;
   }

   if (flag == 1)
   {
	   t2->tm_mon += 1;
       if ( (t2->tm_mon == 11 ) )
	   {
		   t2->tm_mon = 0;
		   t2->tm_year += 1;
	   }
   }

   sprintf(PutBuffer3.DeliveryDate, "%d-%2.2d-%2.2d", 
	   (t2->tm_year + 1900), (t2->tm_mon + 1), t2->tm_mday );
   
   return;
   }           

/*********************************************************************/
/*  This function puts the reply message - restoring the MQRFH2      */
/*   if necessary                                                    */ 
/*********************************************************************/

 void PutReplyMsg(char *ReplyMsg, MQLONG ReplyLength)
 {
   /*                                                                */
   /* Set the object descriptor, message descriptor, and put-        */
   /* message options to the values required to create the           */
   /* reply message.                                                 */
   /*                                                                */

   strncpy(ObjDesc.ObjectName, MsgDesc.ReplyToQ, MQ_Q_NAME_LENGTH);
   strncpy(ObjDesc.ObjectQMgrName, MsgDesc.ReplyToQMgr,
           MQ_Q_MGR_NAME_LENGTH);

   MsgDesc.MsgType = MQMT_REPLY;
   MsgDesc.Report  = MQRO_NONE;
   memset(MsgDesc.ReplyToQ, ' ', MQ_Q_NAME_LENGTH);
   memset(MsgDesc.ReplyToQMgr, ' ', MQ_Q_MGR_NAME_LENGTH);

   memcpy( MsgDesc.CorrelId, MsgDesc.MsgId, sizeof(MsgDesc.MsgId));
   memcpy( MsgDesc.MsgId, MQMI_NONE, sizeof(MsgDesc.MsgId));


   PutMsgOpts.Options = MQPMO_SYNCPOINT +
                        MQPMO_PASS_IDENTITY_CONTEXT;
   PutMsgOpts.Context = HObj_CheckQ;

   /*                                                                */
   /* Build the output message                                       */
   /*                                                                */

   /* Does the message have an MQRFH2 ? */
    if (RFHflag == 1)
	 {
	 /* move the reply message to the end of the MQH header */
     printf("building reply message with MQH header\n");
	 /* strncpy(MsgDesc.Format, MQFMT_RF_HEADER_2, MQ_FORMAT_LENGTH); */
     strncpy( ((MQRFH2 *)APIMessageBuffer)->Format, MQFMT_STRING, MQ_FORMAT_LENGTH);
	 memcpy( (APIMessageBuffer + (((MQRFH2 *)APIMessageBuffer)->StrucLength)), 
		     ReplyMsg, ReplyLength );
	 PutBuffLen = ( ((MQRFH2 *)APIMessageBuffer)->StrucLength) + ReplyLength ;	
	 }
	else /* no MQRFH2 */
	{
    /* strncpy(MsgDesc.Format, MQFMT_STRING, MQ_FORMAT_LENGTH); */
	memcpy( &APIMessageBuffer, ReplyMsg, ReplyLength );
	PutBuffLen = ReplyLength ;			
	}

   MQPUT1(HConn,
          &ObjDesc,
          &MsgDesc,
          &PutMsgOpts,
          PutBuffLen,
          &APIMessageBuffer,
          &CompCode,
          &Reason);


   if (CompCode != MQCC_OK)
      {
        errorMessage( "MQPUT1", CompCode, Reason );
      }

   printf( "MQPUT1 SUCCESSFUL\n" );
  
 }
/*********************************************************************/
 void errorMessage( char* msgStr, MQLONG CC, MQLONG RC )
{
   printf( "************************************************\n" );
   printf( "* %s\n", msgStr );
   printf( "* COMPLETION CODE : %09ld\n", CC );
   printf( "* REASON CODE     : %09ld\n", RC );
   printf( "************************************************\n" );
}


/*********************************************************************/
void usageError( char* programName )
{
   printf( "==================================================\n" );
   printf( "PARAMETERS FOR %s\n", programName );
   printf( "     QMGR        - QUEUE MANGER (optional)\n" );
   printf( "     QNAME       - QUEUE NAME\n" );
   printf( "==================================================\n" );
}

