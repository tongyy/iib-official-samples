/******************************************************************/
/* File Name:     legacyservice2.h                                */
/*                                                                */
/* Header for use with header for use with legacyservice.cpp      */
/*                                                                */
/******************************************************************/


/*   Message Types   */
#define WBIMB_QUERY_PART         "BIMBQRYP"
#define WBIMB_QUERY_PART_RESP    "BIMBQRYR"

/*   Message Structures   */
/* ***************************************************************** */
/* Structure of buy message                                          */
/* ***************************************************************** */
typedef struct tagBIMBQRYP {
   char MessageId[8];
   char CustomerNumber[5];
   char OrderNumber[50];
   char DealerNumber[5];
   int  RepeatCount;

} BIMBQRYP;

typedef struct tagBIMBPART {
	char PartNumber[5];
	int  Quantity;
	char UnitPrice[12];

} BIMBPART;

typedef struct tagBIMBQRYR {
   char MessageId[8];
   char OrderNumber[50];
   char DeliveryDate[10];
   char TotalPrice[12];

} BIMBQRYR;
