/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/
package com.ibm.mqsi.tcpip;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TCPIPAsyncServerNodes_UpdateMessage extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		// Define the output terminals to be used.
		MbOutputTerminal out = getOutputTerminal("out");
		
		// Get the input message (a namespaced SOAP message is expected for this message flow). 
		MbMessage inMessage = inAssembly.getMessage();

		// Get the input LocalEnvironment 
		MbMessage inLocalEnv = inAssembly.getLocalEnvironment();
		
		// Create the output message, output LocalEnvironment and output message assembly.
		MbMessage outMessage = new MbMessage(inMessage);
		MbMessage outLocalEnv = new MbMessage(inLocalEnv); 
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
															outLocalEnv,
															inAssembly.getExceptionList(),
															outMessage);

		try {		
			// Update the input message by adding a new field to it, which can be validated later in the
			// TCPIPAsync workload flow.
			outMessage.evaluateXPath("/SaleEnvelope/Header/?ServerUpdate[set-value('OK')]");				
			// Propagate the message to the output terminal - continue as normal, no exception to be thrown this time.
			out.propagate(outAssembly);
					
		} finally {
			// Clear the output message after it has been propagated.
			outMessage.clearMessage();
		}
	}
}
