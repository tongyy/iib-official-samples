/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/
package com.ibm.mqsi.sample.tcpip;

import java.util.List;
import java.util.Arrays;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


public class TCPIPHandshake_CheckRequestConf extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		// Define the output terminals to be used.
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		// Get the input message. 
		MbMessage inMessage = inAssembly.getMessage();

		// Get the input LocalEnvironment 
		MbMessage inLocalEnv = inAssembly.getLocalEnvironment();
		
		// Create the output message, output LocalEnvironment and output message assembly.
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
															inLocalEnv,
															inAssembly.getExceptionList(),
															inMessage);

		try {		
			// Use an XPath query to find if an acknowledgement reply was received from the previous TCPIPServerReceive node.
			// If it was then it will have been stored in the LocalEnvironment at location:Variables/RequestConfirmation/BLOB/BLOB.
			// This XPath query returns a list of the elements found at that location.
			List ack1ReplyElements = (List) inLocalEnv.getRootElement().evaluateXPath("Variables/RequestConfirmation/BLOB/BLOB"); 
			
			if (ack1ReplyElements.isEmpty())
				// The Ack1Reply element was not found in the LocalEnvironment, so propagate to the alternate terminal to throw an
				// exception in the Throw node that follows this node.
				alt.propagate(outAssembly);
			else {
				// The Ack1Reply element was found in the LocalEnvironment, so now we can check to see if the data is correct.
						
				// Store the value of the Ack1Reply element in a byte array
				MbElement ack1ReplyElement = (MbElement) ack1ReplyElements.get(0);
				byte[] ack1ReplyElementBytes = (byte[]) ack1ReplyElement.getValue();  
				
				// Compare the byte array with the expected data
				if (Arrays.equals(ack1ReplyElementBytes, "2020202020".getBytes()))							
					// The Ack1Reply contained the correct data so propagate the message to the output terminal.
					out.propagate(outAssembly);
				else
					// The Ack1Reply did not contain the correct data so propagate the message to alternate terminal to throw an
					// exception in the Throw node that follows this node.
					alt.propagate(outAssembly);					
			}
		} finally {
		}
	}
}
