/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/
package com.ibm.mqsi.sample.tcpip;

import java.util.List;
import java.util.Arrays;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


public class TCPIPHandshake_CheckReplyAckAndMakeReplyConf extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		// Define the output terminals to be used.
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		// Get the input message. 
		MbMessage inMessage = inAssembly.getMessage();

		// Get the input LocalEnvironment. 
		MbMessage inLocalEnv = inAssembly.getLocalEnvironment();
		
		// Create the output message assembly.
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
															inLocalEnv,
															inAssembly.getExceptionList(),
															inMessage);

		try {		
			// Use an XPath query to find if an acknowledgement reply was received from the previous TCPIPServerReceive node.
			// If it was then it will have been stored in the LocalEnvironment at location: Variables/Ack2/BLOB/BLOB.
			// This XPath query returns a list of the elements found at that location.		
			List ack2Elements = (List) inLocalEnv.getRootElement().evaluateXPath("Variables/Ack2/BLOB/BLOB"); 
			
			if (ack2Elements.isEmpty())
				// The Ack2 element was not found in the LocalEnvironment, so propagate to the alternate terminal to throw an
				// exception in the Throw node that follows this node.
				alt.propagate(outAssembly);
			else {
				// The Ack2 element was found in the LocalEnvironment, so now we can check to see if the data is correct.
				
				// Store the value of the Ack2 element in a byte array
				MbElement ack2Element = (MbElement) ack2Elements.get(0);
				byte[] ack2ElementBytes = (byte[]) ack2Element.getValue();  
				
				// Compare the byte array with the expected data
				if (Arrays.equals(ack2ElementBytes, "3030303030".getBytes())) {							
					// The Ack2 acknowledgement contained the correct data so construct an acknowledgement reply and propagate the
					// message to the output terminal.
															
					// Get the Variables folder in the LocalEnvironment from the XPath query we executed above.
					MbElement variablesElement = ((MbElement) ack2Elements.get(0)).getParent().getParent().getParent();	

					// Create an Ack2Reply folder under the Variables folder in the LocalEnvironment.
					MbElement ack2ReplyElement = variablesElement.createElementAsLastChild(MbElement.TYPE_NAME, "Ack2Reply", null);
					
					// Create a BLOB parser under the Ack2Reply folder to ensure that the acknowledgement reply will be parsed as a BLOB.
					MbElement parserElement = ack2ReplyElement.createElementAsLastChild(MbBLOB.PARSER_NAME);
					parserElement.setName("BLOB");
					
					// Create a BLOB element with the 10 byte data to be sent as the acknowledgement reply message.
					parserElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", "4040404040".getBytes());
					
					// Propagate the message to the output terminal.
					out.propagate(outAssembly);
				}
				else
					// The Ack2Reply did not contain the correct data so propagate the message to alternate terminal to throw an
					// exception in the Throw node that follows this node.
					alt.propagate(outAssembly);				
			}
		} finally {
		}
	}
}
