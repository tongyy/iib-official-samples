/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/

package com.ibm.mqsi.sample.tcpip;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TCPIPHandshake_MakeRequestAck extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		// Define the output terminal to be used.
		MbOutputTerminal out = getOutputTerminal("out");

		// Get the input message. 
		MbMessage inMessage = inAssembly.getMessage();

		// Get the input LocalEnvironment 
		MbMessage inLocalEnv = inAssembly.getLocalEnvironment();
		
		// Create the output message assembly.
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
															inLocalEnv,
															inAssembly.getExceptionList(),
															inMessage);

		try {		
			// Construct an acknowledgement BLOB message containing 10 bytes of data.
			
			// Create a Variables folder in the LocalEnvironment.
			MbElement rootElement = inLocalEnv.getRootElement();
			MbElement variablesElement = rootElement.createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);	
			
			// Create an Ack1 folder under the Variables folder in the LocalEnvironment.
			MbElement ack1Element = variablesElement.createElementAsLastChild(MbElement.TYPE_NAME, "Ack1", null);
			
			// Create a BLOB parser under the Ack1 folder to ensure that the acknowledgement will be parsed as a BLOB.
			MbElement parserElement = ack1Element.createElementAsLastChild(MbBLOB.PARSER_NAME);
			parserElement.setName("BLOB");
			
			// Create a BLOB element with the 10 bytes of data to be sent as the acknowledgement message.
			parserElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", "1010101010".getBytes());
			
			// Propagate the message to the output terminal.
			out.propagate(outAssembly);
		} finally {
		}
	}
}
