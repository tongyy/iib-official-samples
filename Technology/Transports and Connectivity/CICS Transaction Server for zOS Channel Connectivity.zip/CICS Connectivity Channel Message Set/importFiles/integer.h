struct intStruct {
    int value;
};
