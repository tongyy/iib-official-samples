//jobname    JOB  accounting info,name,MSGLEVEL=1
//           EXEC PROC=DFHYITDL
//TRN.SYSIN  DD      *

#pragma XOPTS(Translator options . . .)

#include <stdio.h>
#include <string.h>

void main(int argc, char *argv[])
{

    int numberTotal      = 0;
    int currentInteger   = 0;

    char *currentString = NULL;
    char *longestString = NULL;
    int longestStringLen = 0;

    char currentChannel[17];
    char containerName[17];

    int numSize = 0;
    int fLength = 0;
    int count   = 0;
    int charsWritten = 0;

    EXEC CICS ADDRESS EIB(dfheiptr);

    EXEC CICS ASSIGN CHANNEL(currentChannel);

    if (currentChannel[0] == ' ') {
        /* No channel provided as input - abend */
        EXEC CICS ABEND ABCODE("NCHN");
    }

    memset(containerName, ' ', 17);
    numSize = sizeof(int);

    count=0;
    while (count < 20) {
        count++;

        /* Work out the container name and try and get the data */
        charsWritten = sprintf(containerName, "number%d", count);
        containerName[charsWritten] = ' ';
        EXEC CICS GET CONTAINER(containerName)
                  INTO(&currentInteger)
                  FLENGTH(numSize);

        if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
            /* No more number containers - leave the loop */
            break;
        }

        /* Add to our total */
        numberTotal += currentInteger;
    }

    memset(containerName, ' ', 17);
    count=0;
    while (count < 20) {
        count++;

        /* Work out the container name and try and get the data */
        charsWritten =sprintf(containerName, "string%d", count);
        containerName[charsWritten] = ' ';
        EXEC CICS GET CONTAINER(containerName)
                  SET(currentString)
                  FLENGTH(&fLength);

        if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
            /* No more string containers - leave the loop */
            break;
        }

        /* See if its the longest string so far */
        if (fLength > longestStringLen) {
            longestStringLen = fLength;
            longestString = currentString;
        }
    }

    EXEC CICS PUT CONTAINER("sum")
                  FROM(&numberTotal)
                  FLENGTH(numSize);

    if (longestStringLen > 0) {
        EXEC CICS PUT CONTAINER("longestString") CHAR
                  FROM(longestString)
                  FLENGTH(longestStringLen);
    }
    EXEC CICS PUT CONTAINER("eibtrnid") CHAR
                  FROM(dfheiptr->eibtrnid)
                  FLENGTH(4);

    EXEC CICS PUT CONTAINER("channelName") CHAR
                  FROM(currentChannel)
                  FLENGTH(16);

    EXEC CICS RETURN;
}
/*
//LKED.SYSIN DD      *
               NAME    anyname(R)
/*
//
