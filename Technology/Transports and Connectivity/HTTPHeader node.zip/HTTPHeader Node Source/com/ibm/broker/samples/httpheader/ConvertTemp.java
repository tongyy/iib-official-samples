/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.httpheader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


public class ConvertTemp extends MbJavaComputeNode {
	private static final String TAG_CELSIUS =  "Celsius";
	private static final String TAG_FAHRENHEIT =  "Fahrenheit";
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal outTerminal = getOutputTerminal("out");
		
		MbMessage inMessage = inAssembly.getMessage();
		MbElement inBodyElement = inMessage.getRootElement().getLastChild();
		
		MbMessage outMessage = new MbMessage(inAssembly.getMessage());
		//Clear the body element in the outmessage
		MbElement outBodyElement = outMessage.getRootElement().getLastChild();
		removeChildren(outBodyElement);
		//Extract the HTTPInput header
		MbElement httpInputHeader = outMessage.getRootElement().getFirstElementByPath("HTTPInputHeader");
		//Get SOAPAction
		MbElement soapActionElement = httpInputHeader.getFirstElementByPath("SOAPAction");
		//Check for specific SOAPAction value
		String soapActionString = (String)soapActionElement.getValue();
		if(!"\"http://localhost:7080/ConvertTemp\"".equals(soapActionString)){
			createResponse("Method not implemented", outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		//Check for the proper body element
		MbElement bodyElement = outMessage.getRootElement().getLastChild();
		if( ! "XML".equals(bodyElement.getName())){
			//If proper body is not present then create the body and error response
			String result = "Please provide the input in the format : <ConvertTemp><Temp>number</Temp><FromUnit>fromUnit<FromUnit><ToUnit>ToUnit<ToUnit></ConvertTemp>";
			bodyElement = outMessage.getRootElement().createElementAsLastChild("xml");
			createResponse(result, bodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}

		//Get the value to convert
		MbElement element = null;
		element = inBodyElement.getFirstElementByPath("ConvertTemp/Temp");
		if( null == element){
			String result = "Please provide the input in the format : <ConvertTemp><Temp>number</Temp><FromUnit>fromUnit<FromUnit><ToUnit>ToUnit<ToUnit></ConvertTemp>";
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		String tempValue = (String)element.getValue();
		//Get the unit of the value
		element = inBodyElement.getFirstElementByPath("ConvertTemp/FromUnit");
		if( null == element){
			String result = "Please provide the input in the format : <ConvertTemp><Temp>number</Temp><FromUnit>fromUnit<FromUnit><ToUnit>ToUnit<ToUnit></ConvertTemp>";
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}

		String fromUnit = (String)element.getValue();;
		//Get the unit to which conversion to be done
		element = inBodyElement.getFirstElementByPath("ConvertTemp/ToUnit");
		if( null == element){
			String result = "Please provide the input in the format : <ConvertTemp><Temp>number</Temp><FromUnit>fromUnit<FromUnit><ToUnit>ToUnit<ToUnit></ConvertTemp>";
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		
		String toUnit = (String)element.getValue();;
		
		double doubleTempValue = 0.0;
		
		try{
			doubleTempValue = Double.valueOf(tempValue).doubleValue();
		}catch(Exception e){
			String result = e.toString();
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		
		if(!TAG_CELSIUS.equals(fromUnit) && !TAG_FAHRENHEIT.equals(fromUnit)){
			String result = "FromUnit should be either "+TAG_CELSIUS+" or "+TAG_FAHRENHEIT;
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		if(!TAG_CELSIUS.equals(toUnit) && !TAG_FAHRENHEIT.equals(toUnit)){
			String result = "ToUnit should be either "+TAG_CELSIUS+" or "+TAG_FAHRENHEIT;
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}

		double dopubleResult = convertTemp(doubleTempValue, fromUnit, toUnit);

		createResponse(String.valueOf(dopubleResult), outBodyElement);
		outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
		
	}
	
	
	/**
	 * @param parent The element whose child elements has to be removed
	 * @throws MbException
	 * 
	 * The method will remove the child elements of an element
	 */
	private void removeChildren(MbElement parent) throws MbException{
		MbElement  child = parent.getFirstChild();
		while( null != child){
			MbElement nextChild = child.getNextSibling();
			child.detach();
			child = nextChild;
		}
	}
	
	/**
	 * @param message The response message to be sent
	 * @param element The element under which response needs to be created
	 * @throws MbException
	 * 
	 * The method creates the response to the request
	 */
	private void createResponse(String message, MbElement element) throws MbException{
		element.createElementAsFirstChild(MbXML.ELEMENT, "ConvertTempResult", message);
	}
	
	/**
	 * @param value The value to convert
	 * @param fromUnit The unit of the value
	 * @param toUnit The unit to which needs to bo convert
	 * @return The converted value
	 */
	private double convertTemp(double value, String fromUnit, String toUnit){
			double doubleResult = 0.0;
			if(TAG_CELSIUS.equals(fromUnit) && TAG_FAHRENHEIT.equals(toUnit)){
				doubleResult = (9.0/5.0)*(value)+32;
			}else if(TAG_FAHRENHEIT.equals(fromUnit) && TAG_CELSIUS.equals(toUnit)){
				doubleResult = (5.0/9.0)*(value-32);
			}else if(fromUnit.equals(toUnit)){
				return (value);
			}
			return doubleResult;
	}
		
}
