/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.httpheader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;
public class ConvertToMiles extends MbJavaComputeNode {
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal outTerminal = getOutputTerminal("out");
		
		MbMessage inMessage = inAssembly.getMessage();
		MbElement inBodyElement = inMessage.getRootElement().getLastChild();
		
		MbMessage outMessage = new MbMessage(inAssembly.getMessage());
		//Clear the body element in the outmessage
		MbElement outBodyElement = outMessage.getRootElement().getLastChild();
		removeChildren(outBodyElement);
		//Extract the HTTPInput header
		MbElement httpInputHeader = outMessage.getRootElement().getFirstElementByPath("HTTPInputHeader");
		//Get SOAPAction
		MbElement soapActionElement = httpInputHeader.getFirstElementByPath("SOAPAction");
		//Check for specific SOAPAction value
		String soapActionString = (String)soapActionElement.getValue();
		if(!"\"http://localhost:7080/ConvertToMiles\"".equals(soapActionString)){
			createResponse("Method not implemented", outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		//Check for the proper body element
		MbElement bodyElement = outMessage.getRootElement().getLastChild();
		if( ! "XML".equals(bodyElement.getName())){
			//If proper body is not present then create the body and error response
			String result = "Please provide the input <Meters>number</Meters>";
			bodyElement = outMessage.getRootElement().createElementAsLastChild("xml");
			createResponse(result, bodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		
		//Get the value to convert
		MbElement element = null;
		element = inBodyElement.getFirstElementByPath("Meters");
		if( null == element){
			String result = "Please provide the input <Meters>number</Meters>";
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		String metersValue = (String)element.getValue();

		double doubleMetersValue = 0.0;
		
		try{
			doubleMetersValue = Double.valueOf(metersValue).doubleValue();
		}catch(Exception e){
			String result = e.getMessage();
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		if( 0 > doubleMetersValue){
			String result = "Meters value must be greater than or equal to zero";
			createResponse(result, outBodyElement);
			outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
			return;
		}
		
		
		double dopubleResult = convertToMiles(doubleMetersValue);

		createResponse(String.valueOf(dopubleResult), outBodyElement);
		outTerminal.propagate(new MbMessageAssembly(inAssembly, outMessage));
		
	}

	/**
	 * @param parent The element whose child elements has to be removed
	 * @throws MbException
	 * 
	 * The method will remove the child elements of an element
	 */
	private void removeChildren(MbElement parent) throws MbException{
		MbElement  child = parent.getFirstChild();
		while( null != child){
			MbElement nextChild = child.getNextSibling();
			child.detach();
			child = nextChild;
		}
	}
	
	/**
	 * @param message The response message to be sent
	 * @param element The element under which response needs to be created
	 * @throws MbException
	 * 
	 * The method creates the response to the request
	 */
	private void createResponse(String message, MbElement element) throws MbException{
		element.createElementAsFirstChild(MbXML.ELEMENT, "Miles", message);
	}
	
	/**
	 * @param value The value to convert
	 * @param fromUnit The unit of the value
	 * @param toUnit The unit to which needs to bo convert
	 * @return The converted value
	 */
	private double convertToMiles(double value){
			double doubleResult = 0.000621371192 * value;
			return doubleResult;
	}
}
