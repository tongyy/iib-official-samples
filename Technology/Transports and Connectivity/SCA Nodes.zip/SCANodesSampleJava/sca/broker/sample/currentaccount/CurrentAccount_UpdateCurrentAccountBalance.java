/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.currentaccount;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class CurrentAccount_UpdateCurrentAccountBalance extends
		MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage locEnv = assembly.getLocalEnvironment();
		
		//Read the new balance from the LE
		MbElement variables = locEnv.getRootElement().getFirstElementByPath("Variables");
		String newBalance = new BigDecimal(variables.getFirstElementByPath("newBalance").getValue().toString()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();

		// ----------------------------------------------------------
		// Add user code below

        BufferedWriter bufferedWriter = null;
        
        try {
        	//Update current account balance on local file system
            File file = null;;
            String OS = System.getProperty("os.name").toLowerCase();
            if (OS.indexOf("windows") > -1) {
                file = new File("C:\\tmp\\CurrentAccount.txt");        	
            } else {
                file = new File("/tmp/CurrentAccount.txt");        	
            }

            //Construct the BufferedWriter object
            bufferedWriter = new BufferedWriter(new FileWriter(file));
            
            //Start writing new balance to the output stream
            bufferedWriter.write(newBalance);
            
        } catch (Exception e) {
			throw new MbUserException(
					CurrentAccount_UpdateCurrentAccountBalance.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
        } finally {
            //Close the BufferedWriter
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.flush();
                    bufferedWriter.close();
                }
            } catch (IOException e) {
    			throw new MbUserException(
    					CurrentAccount_UpdateCurrentAccountBalance.class.getName(),
    					"evaluate()",
    					"",
    					"",
    					e.getMessage(),
    					null);
            }
        }
		
		// End of user code
		// ----------------------------------------------------------

		// The following should only be changed
		// if not propagating message to the 'out' terminal

		out.propagate(assembly);
	}

}
