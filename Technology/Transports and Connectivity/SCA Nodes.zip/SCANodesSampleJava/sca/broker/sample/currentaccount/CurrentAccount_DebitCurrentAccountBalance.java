/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.currentaccount;

import java.math.BigDecimal;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class CurrentAccount_DebitCurrentAccountBalance extends
		MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();

		try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);

			// ----------------------------------------------------------
			// Add user code below
			//Go to tree roots
			MbElement inRoot = inMessage.getRootElement();			
			MbElement outRoot = outMessage.getRootElement();	
			MbMessage locEnv = inAssembly.getLocalEnvironment();
			MbMessage newLocEnv = new MbMessage();
			//Get the operation name
			MbElement sca = locEnv.getRootElement().getFirstElementByPath("SCA");
			MbElement input = sca.getFirstElementByPath("Input");
			MbElement operation = input.getFirstElementByPath("Operation");
			String operationName = operation.getValue().toString();			
			//Get the old balance
			MbElement variables = locEnv.getRootElement().getFirstElementByPath("Variables");
			float oldBalance = Float.parseFloat(variables.getFirstElementByPath("oldBalance").getValue().toString());			
			//Get the amount to transfer
			MbElement soap = inRoot.getFirstElementByPath("SOAP");
			MbElement body = soap.getFirstElementByPath("Body");
			MbElement action = body.getLastChild();
			MbElement request = action.getLastChild();
			MbElement amount = request.getFirstElementByPath("amount");
			float transferValue = Float.parseFloat(amount.getValue().toString());			
			//Calculate the difference
			float newBalance = oldBalance - transferValue;
			MbElement newVariables = newLocEnv.getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);
			//Setup the message reply
            MbElement newXMLNSC = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement newOperation = newXMLNSC.createElementAsLastChild(MbElement.TYPE_NAME, operationName + "Response", null);
			newOperation.setNamespace("http://CurrentAccount/");
			MbElement newResponse = newOperation.createElementAsLastChild(MbElement.TYPE_NAME, "CurrentAccountResponse", null);
			//If the difference is negative then do not accept the transfer and retain old balance
			if (newBalance < 0) {
	            newVariables.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "newBalance", new BigDecimal(oldBalance).setScale(2, java.math.BigDecimal.ROUND_HALF_UP).toString());
	            newResponse.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "accept", "no");
			//Otherwise accept the transfer and set new balance in LE
			} else {
	            newVariables.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "newBalance", new BigDecimal(newBalance).setScale(2, java.math.BigDecimal.ROUND_HALF_UP).toString());
	            newResponse.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "accept", "yes");				
			}

			// End of user code
			// ----------------------------------------------------------

			// Create the new assembly with the new property overrides
			MbMessageAssembly outAssembly = new MbMessageAssembly(
					inAssembly,
					newLocEnv,
					inAssembly.getExceptionList(),
					outMessage);

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} finally {

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
