/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.currentaccount;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class CurrentAccount_RetrieveCurrentAccountBalance extends
		MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage locEnv = inAssembly.getLocalEnvironment();

		// create new message
		MbMessage newLocEnv = new MbMessage(locEnv);

        BufferedReader bufferedReader = null;
        
        try {
        	//Read the current account balance from the local file system
            File file = null;
            String OS = System.getProperty("os.name").toLowerCase();
            if (OS.indexOf("windows") > -1) {
                file = new File("C:\\tmp\\CurrentAccount.txt");        	
            } else {
                file = new File("/tmp/CurrentAccount.txt");        	
            }
        	
            //Construct the BufferedReader object
            bufferedReader = new BufferedReader(new FileReader(file));
            
            //Put the current account balance in the LE
            MbElement variables = newLocEnv.getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);
            variables.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "oldBalance", bufferedReader.readLine());
            
        } catch (Exception e) {
			throw new MbUserException(
					CurrentAccount_RetrieveCurrentAccountBalance.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
        } finally {
            //Close the BufferedReader
            try {
                if (bufferedReader != null)
                    bufferedReader.close();
            } catch (IOException e) {
    			throw new MbUserException(
    					CurrentAccount_RetrieveCurrentAccountBalance.class.getName(),
    					"evaluate()",
    					"",
    					"",
    					e.getMessage(),
    					null);
            }
        }

		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				newLocEnv, inAssembly.getExceptionList(), inAssembly.getMessage());

		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}

}
