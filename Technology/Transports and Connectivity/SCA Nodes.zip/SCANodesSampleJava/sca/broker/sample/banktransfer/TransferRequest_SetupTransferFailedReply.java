/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.banktransfer;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TransferRequest_SetupTransferFailedReply extends
		MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage(inMessage);
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				outMessage);

		try {
			// ----------------------------------------------------------
			// Add user code below

			// Set the content type to be html so that it may be viewed by a browser
			MbElement outRoot = outMessage.getRootElement();
			MbElement outProperties = outRoot.getFirstElementByPath("Properties");	
			MbElement contentType = outProperties.getFirstElementByPath("ContentType");			
			contentType.setValue("text/html");	
			
			// Delete the MQMD header since we don't need this in our HTTP reply
			MbElement mqmd = outRoot.getFirstElementByPath("MQMD");
			mqmd.detach();			

			// Clear out any messages 
			outRoot.getLastChild().detach();

			// Get the exception reported
			MbElement exception = inAssembly.getExceptionList().getRootElement().getFirstElementByPath("RecoverableException").getFirstElementByPath("UserException").getFirstElementByPath("UserException");
			
			// Create a HTML response
			StringBuffer buffer = new StringBuffer();			
			String head = "<HTML><BODY TEXT=\"#ff0000\"><form action=\"/TransferRequestForm\" method=post>";			
			buffer.append(head);
			
			// Iterate through the exception stacktrace and add the reason text to the message response
			MbElement insert = exception.getFirstElementByPath("Insert");
			for (int i=0;i<5;i++) {
				insert = insert.getNextSibling();
			}
			String text = (String)insert.getFirstElementByPath("Text").getValue();
			if (text.length() > 0) {
				buffer.append("<h1>");					
				buffer.append(text);
				buffer.append("</h1>");					
			}
			
			// Complete the HTML body
			String tail = "<br><input type=\"submit\" name=\"OK\" value=\"OK\"></form></BODY></HTML>";
			
			buffer.append(tail);
			// Create the Broker Blob Parser element
			MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
			// Create the BLOB element in the Blob parser domain with the required text
			outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", buffer.toString().getBytes());

			// End of user code
			// ----------------------------------------------------------

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (Exception e) {
			throw new MbUserException(
					TransferRequest_SetupTransferRequest.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
		} finally {
			// clear the outMessage
			outMessage.clearMessage();
		}
	}

}
