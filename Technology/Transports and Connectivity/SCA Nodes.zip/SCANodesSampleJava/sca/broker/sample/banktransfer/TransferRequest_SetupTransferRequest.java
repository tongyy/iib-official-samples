/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.banktransfer;

import java.math.BigDecimal;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TransferRequest_SetupTransferRequest extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();

		try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);

			// ----------------------------------------------------------
			// Add user code below

			// Get the incoming MIME parts
			MbElement inRoot = inMessage.getRootElement();
			MbElement inMime = inRoot.getFirstElementByPath("MIME");
			MbElement inParts = inMime.getFirstElementByPath("Parts");

			// Traverse the local environment for property overrides
			MbElement outRoot = outMessage.getRootElement();			
			MbMessage locEnv = inAssembly.getLocalEnvironment();
			MbMessage newLocEnv = new MbMessage(locEnv);
			MbElement destination = newLocEnv.getRootElement().getFirstElementByPath("Destination");
			MbElement http = destination.getFirstElementByPath("HTTP");
			MbElement requestIdentifier = http.getFirstElementByPath("RequestIdentifier");
			MbElement sca = destination.createElementAsLastChild(MbElement.TYPE_NAME, "SCA", null);
			MbElement request = sca.createElementAsLastChild(MbElement.TYPE_NAME, "Request", null);
			
			request.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "UserContext", requestIdentifier.getValue());
			
			// Operation
			String operation = null;
			
			// Transfer amount
			String amount = null;

			// Get the first part
			MbElement part = inParts.getFirstChild();
			// Iterate through all of the parts dynamically setting sca overrides
			while (part != null) {
				// Strip out the property 
				String content = (String)part.getFirstChild().getValue();
				int start = content.indexOf("\"") + 1;
				int end = content.indexOf("\"", start);
				String property = content.substring(start, end);
				// Get the corresponding property data
				MbElement data = part.getLastChild().getFirstElementByPath("BLOB");
				// If there is a data part then setup the relevant property overrides
				if (data != null) {
					// Obtain the byte data
					byte[] blobData = (byte[])data.getFirstElementByPath("BLOB").getValue(); 
					// Convert to a string
					String dataString = new String(blobData);
					// Set LE properties
					if (property.equals("Operation")) { 
						request.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, property, dataString);
						operation = dataString;
					}
					else if (property.equals("Amount")) {
						amount = dataString;						
						try {
							BigDecimal bigDecimal = new BigDecimal(amount);
							if (bigDecimal.scale() > 2 || bigDecimal.scale() < 0) {
								throw new Exception ("Invalid currency format specified!");
							}
						} catch (NumberFormatException nfe) {
							throw new Exception ("Invalid amount specified!");
						}
					}
				} else {
					throw new Exception("No amount specified!");							
				}
				// Get the next part
				part = part.getNextSibling();
			}
			
			// Delete the HTTPInputHeader since we don't need this in our MQ message request
			MbElement httpInputHeader = outRoot.getFirstElementByPath("HTTPInputHeader");
			httpInputHeader.detach();			
			
			// Create the Broker XMLNSC Parser element
			MbElement outParser = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement service = outParser.createElementAsLastChild(MbElement.TYPE_NAME, operation, null);
			service.setNamespace("http://SavingsAccount/SavingsAccountInterface");
			MbElement transferin = service.createElementAsLastChild(MbElement.TYPE_NAME, "transferin", null);
			transferin.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "amount", amount);			

			// End of user code
			// ----------------------------------------------------------
			
			// Create the new assembly with the new property overrides
			MbMessageAssembly outAssembly = new MbMessageAssembly(
					inAssembly,
					newLocEnv,
					inAssembly.getExceptionList(),
					outMessage);

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (Exception e) {
			throw new MbUserException(
					TransferRequest_SetupTransferRequest.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
		} finally {

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
