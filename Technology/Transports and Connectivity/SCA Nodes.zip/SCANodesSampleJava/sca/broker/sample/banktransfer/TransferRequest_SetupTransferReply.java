/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.banktransfer;

import java.math.BigDecimal;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TransferRequest_SetupTransferReply extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();

		try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);

			// ----------------------------------------------------------
			// Add user code below

			// Traverse the local environment for property overrides
			MbMessage locEnv = inAssembly.getLocalEnvironment();
			MbMessage newLocEnv = new MbMessage(locEnv);
			MbElement locEnvRoot = newLocEnv.getRootElement();
			
			MbElement soap = locEnvRoot.getFirstElementByPath("SCA");
			MbElement response = soap.getFirstElementByPath("Response");
			MbElement userContext = response.getFirstElementByPath("UserContext");

			MbElement destination = locEnvRoot.createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
			MbElement http = destination.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RequestIdentifier", userContext.getValue());

			MbElement inRoot = inMessage.getRootElement();			
			MbElement XMLNSC = inRoot.getFirstElementByPath("XMLNSC");
			MbElement transferResponse = XMLNSC.getLastChild();
			MbElement transferOut = transferResponse.getFirstElementByPath("transferout");
			
			String amount = new BigDecimal(transferOut.getFirstElementByPath("amount").getValue().toString()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
			String oldBalance = new BigDecimal(transferOut.getFirstElementByPath("oldbalance").getValue().toString()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
			String newBalance = new BigDecimal(transferOut.getFirstElementByPath("newbalance").getValue().toString()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
			String accept = transferOut.getFirstElementByPath("accept").getValue().toString();

			// Confirmation message
			StringBuffer html = new StringBuffer();
			html.append("<HTML><HEAD>");
			html.append("<META http-equiv='Content-Type' content='text/html; charset=ISO-8859-1'></HEAD>");				  
			html.append("<BODY><form action='/TransferRequestForm' method=post>");
			if (accept.equals("yes")) {
				html.append("<h1>Your transfer of " + amount +" has been successful!</h1>");
				html.append("<h3>Your old savings balance was " + oldBalance + "</h3>");				
				html.append("<h3>Your new savings balance is " + newBalance + "</h3>");				
			} else {
				html.append("<h1><font color=\"#ff0000\">Your transfer of " + amount + " has been unsuccessful due to insufficient funds!</font></h1>");				
				html.append("<h3>Your savings balance remains unchanged at " + newBalance + "</h3>");				
			}
			html.append("<tr><td><input type='submit' name='OK' value='OK'></td></tr>");
			html.append("</form></BODY></HTML>");

			// Set the content type to be html so that it may be viewed by a browser
			MbElement outRoot = outMessage.getRootElement();			
			MbElement outProperties = outRoot.getFirstElementByPath("Properties");	
			MbElement contentType = outProperties.getFirstElementByPath("ContentType");			
			contentType.setValue("text/html");	

			// Delete the MQMD header since we don't need this in our HTTP reply
			MbElement mqmd = outRoot.getFirstElementByPath("MQMD");
			mqmd.detach();			

			// Create the Broker Blob Parser element
			MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
			// Create the BLOB element in the Blob parser domain with the required text
			outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", html.toString().getBytes());

			// End of user code
			// ----------------------------------------------------------

			// Create the new assembly with the new property overrides
			MbMessageAssembly outAssembly = new MbMessageAssembly(
					inAssembly,
					newLocEnv,
					inAssembly.getExceptionList(),
					outMessage);

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (Exception e) {
			throw new MbUserException(
					TransferRequest_SetupTransferReply.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
		} finally {

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
