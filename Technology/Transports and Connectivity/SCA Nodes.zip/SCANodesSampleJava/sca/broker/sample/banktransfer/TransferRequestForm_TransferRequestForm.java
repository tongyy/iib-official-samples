/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
package sca.broker.sample.banktransfer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class TransferRequestForm_TransferRequestForm extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				outMessage);

        BufferedReader bufferedReader = null;

        try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);

			// ----------------------------------------------------------
			// Add user code below
			//Get operating system
            String OS = System.getProperty("os.name").toLowerCase();
            File file = null;
            //Savings balance
            String savingsBalance = null;
            //Current balance if this file also exists i.e. the extended sample
            String currentBalance = null;
            //Get the exception
			String exception = null;
            try {
    			//Read balance from appropriate local file system appropriately
	            if (OS.indexOf("windows") > -1) {
	                file = new File("C:\\tmp\\SavingsAccount.txt");        	
	            } else {
	                file = new File("/tmp/SavingsAccount.txt");        	
	            }
	            //Construct the BufferedReader object
	            bufferedReader = new BufferedReader(new FileReader(file));            
	            //Process the data
	            savingsBalance = new BigDecimal(bufferedReader.readLine()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();

	            try {
	    			//Read balance from appropriate local file system 
	                if (OS.indexOf("windows") > -1) {
	                    file = new File("C:\\tmp\\CurrentAccount.txt");        	
	                } else {
	                    file = new File("/tmp/CurrentAccount.txt");        	
	                }
	                //Construct the BufferedReader object
	                bufferedReader = new BufferedReader(new FileReader(file));            
	                //Process the data
	                currentBalance = new BigDecimal(bufferedReader.readLine()).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
	            } catch (Exception e) {  
	            	//Get exception message
	            	exception = e.getMessage();
	            }
            } catch (Exception e) {  
            	//Get exception message
            	exception = e.getMessage();
            }
            
            //Create web page layout for user input
            StringBuffer html = new StringBuffer();
			html.append("<HTML><HEAD>");
			html.append("<META http-equiv='Content-Type' content='text/html; charset=ISO-8859-1'></HEAD>");				  
			html.append("<BODY><form action='/TransferRequestSample' enctype='multipart/form-data' method=post>");
			html.append("<table cellpadding=4 cellspacing=2 border=0>");
			html.append("<tr><td><td/><h1>Bank Transfer Form</h1></td>");
			html.append("<tr><td><b>Request</b></td>");
			html.append("<td><select name='Operation'>");
			html.append("<option value='TransferToSavingsAccount'>Transfer To Savings Account</option>");
			html.append("<option value='TransferToCurrentAccount'>Transfer To Current Account</option>");
			html.append("</select></td></tr>");
			html.append("<tr><td><b>Amount</b></td>");
			html.append("<td><input type='text' name='Amount' size=10 maxlength=10></td></tr>");
			html.append("<tr><td><td/><input type='submit' name='submit' value='Submit'></td></tr>");
			html.append("<tr><td/><tr><td/>");
			//If a savings balance was processed then display it
			if (savingsBalance != null) {
				html.append("<tr><td><td/><h3>You have " + savingsBalance + " in your Savings Account</h3></td>");			
				//If a current balance was processed then display it
				if (currentBalance != null) {
					html.append("<tr><td><td/><h3>You have " + currentBalance + " in your Current Account</h3></td>");
				//Otherwise warn the user
				} else {
					//Either file does not exist
					if (exception!=null) {
						html.append("<tr><td><td/><h3>Cannot find " + exception + " This file is required for running the SCA nodes sample extension</h3></td>");											
					//Or file contains corrupt data
					} else {
						html.append("<tr><td><td/><h3><font color=\"#ff0000\">" + file.getName() + " contains corrupt data!</font></h3></td>");												
					}
				}
			//Otherwise seriously warn the user
			} else {
				//Either file does not exist
				if (exception!=null) {
					html.append("<tr><td><td/><h3><font color=\"#ff0000\">Cannot find " + exception + "</font></h3></td>");																	
				//Or file contains corrupt data
				} else {
					html.append("<tr><td><td/><h3><font color=\"#ff0000\">" + file.getName() + " contains corrupt data!</font></h3></td>");												
				}
			}
			html.append("</table></form></BODY></HTML>");
						
			//Set the content type to be html so that it may be viewed by a browser
            MbElement root = outMessage.getRootElement();			
			MbElement properties = root.getFirstElementByPath("Properties");	
			MbElement contentType = properties.getFirstElementByPath("ContentType");			
			contentType.setValue("text/html");		
			
			//Add the email request form as the message content and publish
			MbElement BLOB = root.createElementAsLastChild(MbBLOB.PARSER_NAME);			
			BLOB.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "BLOB", html.toString().getBytes());

			// End of user code
			// ----------------------------------------------------------

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (Exception e) {
			throw new MbUserException(
					TransferRequestForm_TransferRequestForm.class.getName(),
					"evaluate()",
					"",
					"",
					e.getMessage(),
					null);
		} finally {

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();

			//Close the BufferedReader
            try {
                if (bufferedReader != null)
                    bufferedReader.close();
            } catch (IOException e) {
    			throw new MbUserException(
    					TransferRequestForm_TransferRequestForm.class.getName(),
    					"evaluate()",
    					"",
    					"",
    					e.getMessage(),
    					null);
            }
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
