/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010 
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.mqheader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


/*******************************************************************************
*
* File : ReStoreHTTPState.java</br>
*
* Description :</br>
*
* <pre>
*  This class restores the request identifier of the HTTP Request from the body of the message to the local environment
*
* </pre>
*
* Copyright 2006-2007 by International Business Machines Corp. IBM Confidential
*
* OCO Source Materials
*
* 5724-E11 5724-E26 (C) Copyright IBM Corp. 2005
*
* The source code for this program is not published or otherwise divested of
* its trade secrets, irrespective of what has been deposited with the U.S.
* Copyright office
*
*/


public class RestoreHTTPState extends MbJavaComputeNode {
    public void evaluate(MbMessageAssembly inAssembly)
        throws MbException {
        MbOutputTerminal out = getOutputTerminal("out");
        MbMessage inMessage = inAssembly.getMessage();

        // create copy of the input message
        MbMessage outMessage = new MbMessage(inMessage);

        try {
            MbElement rootElement = outMessage.getRootElement();
         
    		MbElement inputElement = outMessage.getRootElement().getFirstElementByPath("/XML/isPrime/input");
    		if( null == inputElement){
    			out.propagate(inAssembly);
    			return;
    		}

            MbMessage newLocalEnv = createReqIdInLocalEnv(rootElement, inAssembly);

            MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, newLocalEnv,
                    inAssembly.getExceptionList(), outMessage);
            out.propagate(outAssembly);
        } finally {
            // clear the outMessage
            outMessage.clearMessage();
        }
    }
    /**
     * @param rootElement The element with the body
     * @param assembly Input message assembly
     * @return
     * @throws MbException
     * 
     * Creates request identifier in the local environment
     */
    private MbMessage createReqIdInLocalEnv(MbElement rootElement, MbMessageAssembly assembly) throws MbException{
        //Fetch Request Id from the body
        String reqId = (String) rootElement.getFirstElementByPath(
                "/XML/isPrime/RequestIdentifier").getValue();
        MbElement resultElement = rootElement.getFirstElementByPath("/XML/isPrime/result").copy();
        //Remove the input message
        rootElement.getFirstElementByPath("/XML/isPrime").detach();
        rootElement.getFirstElementByPath("/XML").addAsFirstChild(resultElement);
        //create Request identifier in the local environment
        MbMessage newLocalEnv = new MbMessage(assembly.getLocalEnvironment());
        MbElement localEnvRoot = newLocalEnv.getRootElement();
        MbElement destElement = localEnvRoot.createElementAsFirstChild(MbElement.TYPE_NAME);
        destElement.setName("Destination");

        MbElement httpElement = destElement.createElementAsFirstChild(MbElement.TYPE_NAME);
        httpElement.setName("HTTP");
        //Convert the Request Identifier value to the hexadecimal value
        //Since the OS expects the value in hexadecimal value
        byte[] valueToSet = getHexRequestIdentifier(reqId);
        
        httpElement.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "RequestIdentifier",
            valueToSet);
        return newLocalEnv;

    }
    
    /**
     * @param reqId Request id in string format
     * @return Returns the hex converted Request Identifier
     */
    private byte[] getHexRequestIdentifier(String reqId){
        byte[] valueToSet = new byte[reqId.length() / 2];
        int outLength = reqId.length();
        int index = 0;

        for (int i = 0; i < outLength; i += 2) {
            valueToSet[index++] = (byte) Integer.parseInt(reqId.substring(i, i + 2), 16);
        }
        
        return valueToSet;
    	
    }
}
