/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010 
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.mqheader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;
/*******************************************************************************
*
*
* File : SaveHTTPState.java</br>
*
* Description :</br>
*
* <pre>
*  This class stores the request identifier of the HTTP Request from the local environment
*  to in the body of the message.
* </pre>
*
* Copyright 2006-2007 by International Business Machines Corp. IBM Confidential
*
* OCO Source Materials
*
* 5724-E11 5724-E26 (C) Copyright IBM Corp. 2005
*
* The source code for this program is not published or otherwise divested of
* its trade secrets, irrespective of what has been deposited with the U.S.
* Copyright office
*
*/

public class SaveHTTPState extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alternate = getOutputTerminal("alternate");

		// Create copy of the input message
		MbMessage outMessage = new MbMessage(inAssembly.getMessage());
		MbElement messageRoot = outMessage.getRootElement();
		MbElement httpInputElement = messageRoot.getFirstElementByPath("HTTPInputHeader");

		//Get the RequestIdentifier from the Incoming message assembly Local Environment
		MbElement requestIdElement = inAssembly.getLocalEnvironment().getRootElement().getFirstElementByPath("/Destination/HTTP/RequestIdentifier");
		//Check for the proper body element
		MbElement bodyElement = outMessage.getRootElement().getLastChild();
		if( ! "XML".equals(bodyElement.getName())){
			//If proper body is not present then create the body and error response
			String result = "Please provide the input as <isPrime><input>number</input></isPrime>";
			bodyElement = outMessage.getRootElement().createElementAsLastChild("xml");
			createResponse(result, bodyElement);
			propagateResult(alternate, new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		//Check for input if proper input is not present then create error response
		MbElement inputElement = bodyElement.getFirstElementByPath("isPrime/input");
		if( null == inputElement){
			String result = "Please provide the input as <isPrime><input>number</input></isPrime>";
			createResponse(result, bodyElement);
			propagateResult(alternate, new MbMessageAssembly(inAssembly, outMessage));
			return;
			
		}
		//Save the Request ID Element in the body
		messageRoot.getFirstElementByPath("/XML/isPrime").createElementAsLastChild(
						MbXML.ELEMENT,
						"RequestIdentifier",
						requestIdElement.getValue());

		// Detaching HTTPInputHeader
		httpInputElement.detach();

		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);
		out.propagate(outAssembly);

	}
	/**
	 * @param terminal The terminal on which the message should be sent
	 * @param assembly The assembly that needs to be sent
	 * @throws MbException
	 * 
	 * The method send the message and message assembly on the specified terminal
	 */
	private void propagateResult(MbOutputTerminal terminal, MbMessageAssembly assembly) throws MbException{
		terminal.propagate(assembly);
		
	}
	/**
	 * @param message The response message to be sent
	 * @param element The element under which response needs to be created
	 * @throws MbException
	 * 
	 * The method creates the response to the request
	 */
	private void createResponse(String message, MbElement element) throws MbException{
		element.createElementAsFirstChild(MbXML.ELEMENT, "result", message);
	}
	

}
