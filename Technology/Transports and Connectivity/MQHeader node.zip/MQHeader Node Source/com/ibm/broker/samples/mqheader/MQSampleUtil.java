/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010 
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.mqheader;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;

/*
 * Created on May 25, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author uday
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MQSampleUtil {
    public static  MbMessage createReqIdInLocalEnv(String reqId, MbMessageAssembly assembly) throws MbException{
    	
        MbMessage newLocalEnv = new MbMessage(assembly.getLocalEnvironment());
        MbElement localEnvRoot = newLocalEnv.getRootElement();
        MbElement destElement = localEnvRoot.createElementAsFirstChild(MbElement.TYPE_NAME);
        destElement.setName("Destination");

        MbElement httpElement = destElement.createElementAsFirstChild(MbElement.TYPE_NAME);
        httpElement.setName("HTTP");

        //Convert the Request Identifier value to the hexadecimal value
        //Since the OS expects the value in hexadecimal value
        byte[] valueToSet = getHexRequestIdentifier(reqId);
        
        httpElement.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "RequestIdentifier",
            valueToSet);
        return newLocalEnv;

    }
    private static byte[] getHexRequestIdentifier(String reqId){
        byte[] valueToSet = new byte[reqId.length() / 2];
        int outLength = reqId.length();
        int index = 0;

        for (int i = 0; i < outLength; i += 2) {
            valueToSet[index++] = (byte) Integer.parseInt(reqId.substring(i, i + 2), 16);
        }
        
        return valueToSet;
    	
    }
    
    

}
