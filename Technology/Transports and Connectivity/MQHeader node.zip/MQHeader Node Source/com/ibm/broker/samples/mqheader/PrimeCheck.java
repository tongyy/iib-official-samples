/*
Sample program for use with IBM WebSphere Message Broker
� Copyright International Business Machines Corporation 2009, 2010 
Licensed Materials - Property of IBM
*/
package com.ibm.broker.samples.mqheader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

/*******************************************************************************
 *
 * File : PrimeCheck.java</br>
 *
 * Description :</br>
 * <pre>
 *  This class provides functionality to check if the given number is a
 *  prime number or not.
 *  The class reads the value from the input message and stores the result in 
 *  the output message. 
 * </pre>
 *
 * Copyright 2006-2007 by International Business Machines Corp. IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11 5724-E26 (C) Copyright IBM Corp. 2005
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office
 *
 */

public class PrimeCheck extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alternate = getOutputTerminal("alternate");
		
		//Create copy of incoming message
		MbMessage outMessage = new MbMessage(inAssembly.getMessage());
		MbElement bodyElement = outMessage.getRootElement().getLastChild();
		
		String result = null;
		
		//Check for proper integer value
		String value =  (String)outMessage.getRootElement().getFirstElementByPath("/XML/isPrime/input").getValue();
		int intValue = 0;
		try{
			intValue = Integer.parseInt(value);
		}catch(Exception e){
			result = e.toString();
			//Create error response
			createResponse(result, bodyElement);
			//Restore the HTTP Identifier to the LocalEnvironment
			MbMessageAssembly outAssembly = createNewLocalEnvAndAssembly(outMessage, inAssembly);
			alternate.propagate(outAssembly);
			return;
			
		}
		
		if( 1 >= intValue){
			result = "Input should be greater than 1";
			//Create error response			
			createResponse(result, bodyElement);
			//Restore the HTTP Identifier to the LocalEnvironment
			MbMessageAssembly outAssembly = createNewLocalEnvAndAssembly(outMessage, inAssembly);
			alternate.propagate(outAssembly);
			return;
			
		}

		//Check for prime
		//Test if the given number can be divided by any number with in range 2..sqrt(n)
		//If the number is divisible then it is not a prime number
		//Otherwise the number is a prime number
		result = null;
		int upperBound = (int)Math.sqrt(intValue);
		for(int index = 2; index <= upperBound; index++){
			if( 0 == intValue%index){
				result = intValue + " is not a prime number.";
				break;
			}
		}

		if( null == result){
			result = intValue + " is a prime number.";
		}

		//Create the result element in the body of the message
		createResponse(result, bodyElement);
		propagateResult(out, new MbMessageAssembly(inAssembly, outMessage));

	}
	
	/**
	 * @param terminal The terminal on which the message should be sent
	 * @param assembly The assembly that needs to be sent
	 * @throws MbException
	 * 
	 * The method send the message and message assembly on the specified terminal
	 */
	private void propagateResult(MbOutputTerminal terminal, MbMessageAssembly assembly) throws MbException{
		terminal.propagate(assembly);
		
	}
	/**
	 * @param message The response message to be sent
	 * @param element The element under which response needs to be created
	 * @throws MbException
	 * 
	 * The method creates the response to the request
	 */
	private void createResponse(String message, MbElement element) throws MbException{
		element = element.getFirstElementByPath("isPrime");
		element.createElementAsFirstChild(MbXML.ELEMENT, "result", message);
	}
	
    /**
     * @param rootElement The element with the body
     * @param assembly Input message assembly
     * @return
     * @throws MbException
     * 
     * Creates request identifier in the local environment
     */
    private MbMessage createReqIdInLocalEnv(MbElement rootElement, MbMessageAssembly assembly) throws MbException{
        //Fetch Request Id from the body
        String reqId = (String) rootElement.getFirstElementByPath(
                "/XML/isPrime/RequestIdentifier").getValue();
        MbElement resultElement = rootElement.getFirstElementByPath("/XML/isPrime/result").copy();
        //Remove the input message
        rootElement.getFirstElementByPath("/XML/isPrime").detach();
        rootElement.getFirstElementByPath("/XML").addAsFirstChild(resultElement);
        //create Request identifier in the local environment
        MbMessage newLocalEnv = new MbMessage(assembly.getLocalEnvironment());
        MbElement localEnvRoot = newLocalEnv.getRootElement();
        MbElement destElement = localEnvRoot.createElementAsFirstChild(MbElement.TYPE_NAME);
        destElement.setName("Destination");

        MbElement httpElement = destElement.createElementAsFirstChild(MbElement.TYPE_NAME);
        httpElement.setName("HTTP");
        //Convert the Request Identifier value to the hexadecimal value
        //Since the OS expects the value in hexadecimal value
        byte[] valueToSet = getHexRequestIdentifier(reqId);
        
        httpElement.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "RequestIdentifier",
            valueToSet);
        return newLocalEnv;

    }
    
    /**
     * @param reqId Request id in string format
     * @return Returns the hex converted Request Identifier
     */
    private byte[] getHexRequestIdentifier(String reqId){
        byte[] valueToSet = new byte[reqId.length() / 2];
        int outLength = reqId.length();
        int index = 0;

        for (int i = 0; i < outLength; i += 2) {
            valueToSet[index++] = (byte) Integer.parseInt(reqId.substring(i, i + 2), 16);
        }
        
        return valueToSet;
    	
    }
    
    /**
     * @param message Output message
     * @param assembly Input message assembly
     * @return Returns new Message Assembly with new local environment
     * @throws MbException
     */
    private MbMessageAssembly createNewLocalEnvAndAssembly(MbMessage message, MbMessageAssembly assembly) throws MbException{
		MbMessage newLocalEnv = createReqIdInLocalEnv(message.getRootElement(), assembly);
        MbMessageAssembly newAssembly = new MbMessageAssembly(assembly, newLocalEnv,
        		assembly.getExceptionList(), message);
        return newAssembly;

    }


}
