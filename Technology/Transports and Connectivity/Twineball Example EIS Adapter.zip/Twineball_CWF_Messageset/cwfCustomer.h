struct Address{
    char zipcode[10];
    char city[20];
};

struct Customer{
	char    key[8];
    char    firstName[20];
    char    lastName[20];
    Address address;
};

struct Response{
	char  key[8];
    unsigned char result;
};


