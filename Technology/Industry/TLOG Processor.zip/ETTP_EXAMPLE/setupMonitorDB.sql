-- Database Name: TLOGMON         

-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
-- US Government Users Restricted Rights- Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.


--------------------------------------------------------
-- CREATE DATABASE TLOGMON
--------------------------------------------------------

-- DROP DATABASE TLOGMON;

-- CREATE DATABASE TLOGMON;

-- CONNECT TO TLOGMON;

GRANT  DBADM,CREATETAB,BINDADD,CONNECT,CREATE_NOT_FENCED_ROUTINE,IMPLICIT_SCHEMA,LOAD,CREATE_EXTERNAL_ROUTINE,QUIESCE_CONNECT ON DATABASE TO USER "TLOG";

ALTER BUFFERPOOL IBMDEFAULTBP SIZE 5000;

-- CONNECT RESET;
-- TERMINATE;




-----------------------------------------------------------
-- Database and Database Manager configuration parameters
-----------------------------------------------------------
-- CONNECT TO TLOGMON;

-- UPDATE DB CFG FOR TLOGMON USING logfilsiz 2048;
-- UPDATE DB CFG FOR TLOGMON USING logprimary 10;
-- UPDATE DB CFG FOR TLOGMON USING logsecond 10;

-- CONNECT RESET;

--------------------------------------------------------
-- CREATE TABLES
--------------------------------------------------------
-- CONNECT TO TLOGMON;
SET SCHEMA "TLOG";

--------------------------------------------------------
-- TABLE "TLOG".MESSAGE
--------------------------------------------------------
DROP TABLE "TLOG".MESSAGE;

CREATE TABLE "TLOG".MESSAGE (MESSAGE_ID	CHAR(24) FOR BIT DATA 	NOT NULL, MIME_SEQUENCE_NUMBER	VARCHAR(3) NOT NULL, CORREL_ID CHAR(24) FOR BIT DATA, STORE_NAME VARCHAR(50), STORE_NUMBER  VARCHAR(50), INPUT_MSG_TRANS_TYPE VARCHAR(75),   	PUT_TIMESTAMP TIMESTAMP, SOURCE_QUEUE VARCHAR(75), DESTINATION_QUEUE VARCHAR(75));

ALTER TABLE "TLOG".MESSAGE ADD PRIMARY KEY(MESSAGE_ID, MIME_SEQUENCE_NUMBER);

                                                                                              

--------------------------------------------------------
-- TABLE "TLOG".STORE_DAY
--------------------------------------------------------
DROP TABLE "TLOG".STORE_DAY;

CREATE TABLE "TLOG".STORE_DAY (STORE_NAME VARCHAR(50) NOT NULL, STORE_NUMBER VARCHAR(50) NOT NULL, DATA_DATE DATE NOT NULL, TIME_STORE_CLOSE	TIME, TIME_LAST_MSG_RECVD	TIMESTAMP, POSLOGXML_MSGCOUNT	INTEGER, TOTAL_SALES_AMOUNT DECIMAL(14,2) DEFAULT 0);


ALTER TABLE "TLOG".STORE_DAY ADD PRIMARY KEY(STORE_NAME, STORE_NUMBER, DATA_DATE);


--------------------------------------------------------
-- TABLE "TLOG".STORE_HOUR
--------------------------------------------------------
DROP TABLE "TLOG".STORE_HOUR;

CREATE TABLE "TLOG".STORE_HOUR (STORE_NAME VARCHAR(50)	NOT NULL, STORE_NUMBER	VARCHAR(50) NOT NULL, SAMPLE_DATE DATE NOT NULL, SAMPLE_HOUR  INTEGER NOT NULL, SUM_HOUR_TRANS_MINUTES DECIMAL(14,2) DEFAULT 0, SUM_HOUR_TRANS_MINUTES_SQRD DECIMAL(14,2) 	DEFAULT 0, SUM_HOUR_REVENUE DECIMAL(14,2) DEFAULT 0, SUM_HOUR_REVENUE_SQRD DECIMAL(14,2) DEFAULT 0, SUM_DAY_REVENUE 	DECIMAL(14,2) 	DEFAULT 0, SUM_HOUR_TIME_REVENUE DECIMAL(14,2) 	DEFAULT 0, SUM_DAY_TRANS_COUNT	INTEGER, SUM_HOUR_SAMPLE_COUNT INTEGER);


ALTER TABLE "TLOG".STORE_HOUR ADD PRIMARY KEY(STORE_NAME, STORE_NUMBER, SAMPLE_DATE, SAMPLE_HOUR);
                          

--------------------------------------------------------
-- TABLE "TLOG".STORE_SCRATCH
--------------------------------------------------------
DROP TABLE "TLOG".STORE_SCRATCH;

CREATE TABLE "TLOG".STORE_SCRATCH (STORE_NAME VARCHAR(50), STORE_NUMBER	VARCHAR(50), LAST_SAMPLE_DATE DATE, LAST_SAMPLE_TIME	TIME, SUM_DAY_REVENUE DECIMAL(14,2) DEFAULT 0, SUM_DAY_TRANS_COUNT INTEGER);


-- CONNECT RESET;
-- TERMINATE;