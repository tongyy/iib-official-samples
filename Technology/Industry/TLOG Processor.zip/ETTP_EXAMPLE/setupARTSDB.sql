--------------------------------------------------------
-- CREATE DATABASE TLOGARTS
--------------------------------------------------------

-- DROP DATABASE TLOGARTS

-- CREATE DATABASE TLOGARTS

-- CONNECT TO TLOGARTS

GRANT  DBADM,CREATETAB,BINDADD,CONNECT,CREATE_NOT_FENCED_ROUTINE,IMPLICIT_SCHEMA,LOAD,CREATE_EXTERNAL_ROUTINE,QUIESCE_CONNECT ON DATABASE TO USER TLOG

ALTER BUFFERPOOL IBMDEFAULTBP SIZE 5000

-- CONNECT RESET
-- TERMINATE

-------------------------------------------------

-- CONNECT TO TLOGARTS

--------------------------------------------------------
-- Database and Database Manager configuration parameters
--------------------------------------------------------

-- UPDATE DBM CFG USING intra_parallel NO
-- UPDATE DBM CFG USING federated NO

-- UPDATE DB CFG FOR TLOGARTS USING sortheap 256
-- UPDATE DB CFG FOR TLOGARTS USING locklist 500
-- UPDATE DB CFG FOR TLOGARTS USING dft_degree 1
-- UPDATE DB CFG FOR TLOGARTS USING maxlocks 22
-- UPDATE DB CFG FOR TLOGARTS USING avg_appls 1
-- UPDATE DB CFG FOR TLOGARTS USING stmtheap 2048
-- UPDATE DB CFG FOR TLOGARTS USING dft_queryopt 5
-- UPDATE DB CFG FOR TLOGARTS USING dbheap 1200
-- UPDATE DB CFG FOR TLOGARTS USING logbufsz 128
-- UPDATE DB CFG FOR TLOGARTS USING stmtheap 4096

-- UPDATE DB CFG FOR TLOGARTS USING logfilsiz 2000
-- UPDATE DB CFG FOR TLOGARTS USING logprimary 5
-- UPDATE DB CFG FOR TLOGARTS USING logsecond 5
-- UPDATE DB CFG FOR TLOGARTS USING locktimeout 30

-- CONNECT RESET

--------------------------------------------------------
-- CREATE TABLES
--------------------------------------------------------
-- CONNECT TO TLOGARTS
SET SCHEMA TLOG

--------------------------------------------------------
-- TABLE TLOG.AS_ITM
--------------------------------------------------------
DROP TABLE TLOG.AS_ITM

CREATE TABLE TLOG.AS_ITM (ID_ITM INTEGER NOT NULL, ID_ITM_SL_PRC        INTEGER, ID_RU_ITM_SL         INTEGER, ID_DPT_PS INTEGER, ID_LN_PRC            INTEGER, ID_MRHRC_GP          INTEGER, NM_BRN               VARCHAR(40), FL_AZN_FR_SLS SMALLINT, FL_ITM_DSC           SMALLINT, FL_ADT_ITM_PRC       SMALLINT, LU_EXM_TX            CHAR(2), LU_ITM_USG  CHAR(2), NM_ITM               VARCHAR(40), DE_ITM               VARCHAR(255), TY_ITM               CHAR(4), LU_KT_ST             CHAR(2), FL_ITM_SBST_IDN      SMALLINT, LU_CLN_ORD   CHAR(2))

COMMENT ON TABLE TLOG.AS_ITM IS 'The lowest level of merchandise for which inventory and sales records are retained within the retail store. It is analogous to the SKU ( Stock Keeping Unit).'
COMMENT ON COLUMN TLOG.AS_ITM.ID_ITM IS 'The retailer''s SKU or unique item identifier for items sold or returned.'
COMMENT ON COLUMN TLOG.AS_ITM.ID_MRHRC_GP IS 'Unique identifier for a merchandise structure.'
COMMENT ON COLUMN TLOG.AS_ITM.ID_ITM_SL_PRC IS 'A unique system assigned identifier for the ItemSellingPrices.'
COMMENT ON COLUMN TLOG.AS_ITM.ID_RU_ITM_SL IS 'A unique system assigned identifier for the ItemSellingPrices.'
COMMENT ON COLUMN TLOG.AS_ITM.ID_DPT_PS IS 'A unique system-assigned identifier for the POSDepartment'
COMMENT ON COLUMN TLOG.AS_ITM.ID_LN_PRC IS 'A unique identifier for this price point.'
COMMENT ON COLUMN TLOG.AS_ITM.NM_BRN IS 'A unique name to denote a class of ITEMs as a product of a single supplier or manufacturer. The brand can include private label ITEMs.'
COMMENT ON COLUMN TLOG.AS_ITM.FL_AZN_FR_SLS IS 'A flag to indicate that the RETAIL STORE is authorized to stock this particular ITEM.'
COMMENT ON COLUMN TLOG.AS_ITM.FL_ITM_DSC IS 'A flag to indicate whether this ITEM can be discounted.'
COMMENT ON COLUMN TLOG.AS_ITM.FL_ADT_ITM_PRC IS 'A flag to denote whether this ITEM was validated (scanned) during verification of the ITEM table.'
COMMENT ON COLUMN TLOG.AS_ITM.LU_EXM_TX IS 'A code to denote the tax exemption status from sales and use tax. The codes refer to the UCC code, Tax Exempt Code, defined in data element 441.'
COMMENT ON COLUMN TLOG.AS_ITM.LU_ITM_USG IS 'This code defines how this item may be used within a store.  Usage is a function of how an item may be consumed or disposed of by the store.'
COMMENT ON COLUMN TLOG.AS_ITM.NM_ITM IS 'The name by which the ITEM is known.'
COMMENT ON COLUMN TLOG.AS_ITM.DE_ITM IS 'The textural description of the ITEM and its characteristics.'
COMMENT ON COLUMN TLOG.AS_ITM.TY_ITM IS 'This code indicates whether the item is a STOCK ITEM or SERVICE ITEM.'
COMMENT ON COLUMN TLOG.AS_ITM.LU_KT_ST IS 'This code signifies this ITEM is provided as a kit which has to made up either by the customer or by the store at an additional cost.'
COMMENT ON COLUMN TLOG.AS_ITM.FL_ITM_SBST_IDN IS 'An ITEM for which there is a substitute available for sale within the RETAIL STORE.'
COMMENT ON COLUMN TLOG.AS_ITM.LU_CLN_ORD IS 'A code to signify that this ITEM is ordered as part of a collection of ITEMs.'
CREATE INDEX IF1649Item ON TLOG.AS_ITM (ID_DPT_PS  ASC)

CREATE INDEX IF2030Item ON TLOG.AS_ITM(ID_RU_ITM_SL ASC)

CREATE INDEX IF2039Item ON TLOG.AS_ITM(ID_ITM_SL_PRC ASC)

CREATE INDEX XIF417ITEM ON TLOG.AS_ITM(ID_MRHRC_GP ASC)

CREATE INDEX XIF453ITEM ON TLOG.AS_ITM(NM_BRN ASC)

CREATE INDEX XIF947ITEM ON TLOG.AS_ITM(ID_LN_PRC ASC, ID_MRHRC_GP ASC)


ALTER TABLE TLOG.AS_ITM ADD PRIMARY KEY (ID_ITM)



--------------------------------------------------------
-- TABLE TLOG.AS_WS
--------------------------------------------------------
DROP TABLE TLOG.AS_WS

CREATE TABLE TLOG.AS_WS (ID_STR_RT  INTEGER NOT NULL, ID_WS  INTEGER NOT NULL, ID_EQ INTEGER, NM_WS_MF VARCHAR(40), NM_MDL_WS_TML        VARCHAR(40), SC_TML_WS            CHAR(2), QU_TL_WS             DECIMAL(3,0) NOT NULL DEFAULT 0, TY_WS CHAR(4), FL_MOD_TRG           SMALLINT, FL_WS_OTSD           SMALLINT, NM_ADS_DVC           VARCHAR(40))

COMMENT ON TABLE TLOG.AS_WS IS 'A device used as an as interface to any store business function .  This includes the capture and storage of TRANSACTIONS and operational performance reporting'
COMMENT ON COLUMN TLOG.AS_WS.ID_STR_RT IS 'A unique retailer assigned identifier for a RetailStore'
COMMENT ON COLUMN TLOG.AS_WS.ID_WS IS 'The unique identifier for the WORKSTATION, typically the serial number.'
COMMENT ON COLUMN TLOG.AS_WS.ID_EQ IS 'The fixed asset number assigned by the retailer for this particular piece of equipment.'
COMMENT ON COLUMN TLOG.AS_WS.NM_WS_MF IS 'The name of the MANUFACTURER of the WORKSTATION. Currently most MANUFACTURERs simply assembly the components and place their badge on the device.'
COMMENT ON COLUMN TLOG.AS_WS.NM_MDL_WS_TML IS 'The model number of the WORKSTATION.'
COMMENT ON COLUMN TLOG.AS_WS.SC_TML_WS IS 'The status code of the WORKSTATION, i.e. active, closed, off-line, etc.'
COMMENT ON COLUMN TLOG.AS_WS.QU_TL_WS IS 'The number of tills that can be supported through the one WORKSTATION. In most instances each WORKSTATION has one. In cases such as duty free stores or where the retailer wants to maintain operator accountability there may be two.'
COMMENT ON COLUMN TLOG.AS_WS.TY_WS IS 'A code to denote the type or use of WORKSTATION, such as POS register, goods receipt terminal.'
COMMENT ON COLUMN TLOG.AS_WS.FL_MOD_TRG IS 'A flag to denote whether the WORKSTATION is in normal operation or training mode. In the latter none of the history accumulators are updated.'
COMMENT ON COLUMN TLOG.AS_WS.FL_WS_OTSD IS 'A flag denoting that this Workstation is positioned outside the store (Perhaps at a FuelingPosition in the Forecourt business segment)'
COMMENT ON COLUMN TLOG.AS_WS.NM_ADS_DVC IS 'The device address of this WORKSTATION'
CREATE INDEX XIF1056POINT_OF_SA ON TLOG.AS_WS (       ID_STR_RT                      ASC)

CREATE INDEX IF1583Workstation ON TLOG.AS_WS(       ID_EQ                          ASC)


ALTER TABLE TLOG.AS_WS  ADD PRIMARY KEY (ID_STR_RT, ID_WS)


--------------------------------------------------------
-- TABLE TLOG.CO_AZN_TND
--------------------------------------------------------
DROP TABLE TLOG.CO_AZN_TND

CREATE TABLE TLOG.CO_AZN_TND (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_TND_AZN           SMALLINT NOT NULL, ID_PRV               INTEGER, ID_AZN_PRE           SMALLINT,  MO_RQS               DECIMAL(8,3) DEFAULT 0, MO_RQS_CHN           DECIMAL(8,3) DEFAULT 0, LU_ADJN_TND_AZN      VARCHAR(20), ID_RFC_TND_AZN       INTEGER, TS_TM_DT             DATE, ID_RQS_TML           INTEGER, FL_HOS_AZN           SMALLINT, BM_SGN               SMALLINT, NA_HOS               VARCHAR(255), FL_CT_PRST           SMALLINT)

COMMENT ON TABLE TLOG.CO_AZN_TND IS 'A request to an external agency to authorize the use of some form of tender to complete a RetailTransaction. Eg: Cheques, Credit & Debit Cards, Gift Certificates or Vouchers.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.AI_TND_AZN IS 'A unique sequence number for this TenderAuthorization. Required because a particular TenderLineItem may have more than one TenderAuthorization attempt.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.ID_PRV IS 'A unique identifier for the external agency that is providing this TenderAuthorization'
COMMENT ON COLUMN TLOG.CO_AZN_TND.ID_AZN_PRE IS 'A unique sequence number for the TenderAuthorization that "Pre-Authorized" this TenderAuthorization'
COMMENT ON COLUMN TLOG.CO_AZN_TND.MO_RQS IS 'The monetary value of the purchases for which an authorization is being requested.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.MO_RQS_CHN IS 'The monetary value cash-back for which an authorization is being requested'
COMMENT ON COLUMN TLOG.CO_AZN_TND.LU_ADJN_TND_AZN IS 'The adjudication code returned by the external agency to this TenderAuthorizationRequest'
COMMENT ON COLUMN TLOG.CO_AZN_TND.ID_RFC_TND_AZN IS 'A unique identifier (which may be assigned by the external authorization agency) for this TenderAuthorization'
COMMENT ON COLUMN TLOG.CO_AZN_TND.TS_TM_DT IS 'The Date and Time the TenderAuthorization was made.  This may be assigned by the external agency that is providing the TenderAuthorization.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.ID_RQS_TML IS 'A unique identifier (usually assigned by an external agency that provides TenderAuthorizations) that identifies the financial terminal that is making this TenderAuthorization'
COMMENT ON COLUMN TLOG.CO_AZN_TND.FL_HOS_AZN IS 'A flag denoting that this TenderAuthorization was authorized by an external agency.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.BM_SGN IS 'A bitmap image of the customer''s signature that was captured as part of the TenderAuthorization process.'
COMMENT ON COLUMN TLOG.CO_AZN_TND.NA_HOS IS 'Narrative text provided by the external agency for inclusion on any reciepts printed as a result of the TenderAuthorization'
COMMENT ON COLUMN TLOG.CO_AZN_TND.FL_CT_PRST IS 'A flag denoting whether the Customer was or was not present during the transaction.  This flag would be False for Phone, Web & Mail-Order sales.'
-- c0001
-- CREATE INDEX IF1782TenderAuthor ON TLOG.CO_AZN_TND
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX IF1782TenderAuthor ON TLOG.CO_AZN_TND (AI_LN_ITM                      ASC, LOOKUP1_ID                     ASC)

-- c0001
-- CREATE INDEX IF1784TenderAuthor ON TLOG.CO_AZN_TND
-- (
--        ID_AZN_PRE                     ASC,
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX IF1784TenderAuthor ON TLOG.CO_AZN_TND(ID_AZN_PRE                     ASC,AI_LN_ITM                      ASC, LOOKUP1_ID                     ASC)

CREATE INDEX IF1928TenderAuthor ON TLOG.CO_AZN_TND(       ID_PRV                         ASC)


ALTER TABLE TLOG.CO_AZN_TND   ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, AI_TND_AZN)


-------------------------------------------------------
-- TABLE TLOG.CO_CNY
--------------------------------------------------------
DROP TABLE TLOG.CO_CNY

CREATE TABLE TLOG.CO_CNY (ID_CNY               INTEGER NOT NULL, DE_CNY               VARCHAR(255), SY_CNY               VARCHAR(40), LU_CNY_ISSG_CY       CHAR(4))

COMMENT ON TABLE TLOG.CO_CNY IS 'Specifies the national designation and quantitative value of monetary media used as tender in the processing of this TENDER LINE ITEM.'
COMMENT ON COLUMN TLOG.CO_CNY.ID_CNY IS 'The unique identifier of the CURRENCY.'
COMMENT ON COLUMN TLOG.CO_CNY.DE_CNY IS 'A description of the currency, i.e. pounds sterling, US dollars, Canadian dollars, etc.'
COMMENT ON COLUMN TLOG.CO_CNY.SY_CNY IS 'National symbol for the main unit of currency, e.g. �, $, etc'
COMMENT ON COLUMN TLOG.CO_CNY.LU_CNY_ISSG_CY IS 'Identification of the country issuing the currency. This code relates to the UCC data element 100, Currency Code,'

ALTER TABLE TLOG.CO_CNY ADD PRIMARY KEY (ID_CNY)



--------------------------------------------------------
-- TABLE TLOG.CO_MDFR_CMN
--------------------------------------------------------
DROP TABLE TLOG.CO_MDFR_CMN

CREATE TABLE TLOG.CO_MDFR_CMN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_MDFR_CMN          SMALLINT NOT NULL, ID_EM                INTEGER, MO_MDFR_CMN          DECIMAL(14,3) NOT NULL DEFAULT 0, PE_MDFR_CMN          DECIMAL(5,2) NOT NULL DEFAULT 0, FL_PE_CMN_AMT        VARCHAR(20), LU_ACTN_ASCTN        VARCHAR(20), TS_TM_DT             DATE)

COMMENT ON TABLE TLOG.CO_MDFR_CMN IS 'A modifier that captures earned commissions by an employee involved in serving the customer purchasing the merchandise or service item identified in the SALE/RETURN LINE ITEM.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.AI_MDFR_CMN IS 'A sequential counter used to uniquely identify an instance of a COMMISSION MODIFIER.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.ID_EM IS 'A unique, non-significant number used to identify a store employee.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.MO_MDFR_CMN IS 'Defines the flat amount of commission earned on the sale of this item'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.PE_MDFR_CMN IS 'Defines the percentage applied to the sold-at retail amount to arrive at the commission for an item or service sold in the SALE/RETURN LINE ITEM.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.FL_PE_CMN_AMT IS 'A code denoting the commission calculation method to be used.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.LU_ACTN_ASCTN IS 'A code denoting what action the Associate did on this sale to earn the commission. This action code may affect the commission calculation.'
COMMENT ON COLUMN TLOG.CO_MDFR_CMN.TS_TM_DT IS 'The date and time that the associate performed the action for which a commission is payable.'
-- c0001
-- CREATE INDEX XIF593COMMISSION_M ON TLOG.CO_MDFR_CMN
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF593COMMISSION_M ON TLOG.CO_MDFR_CMN(AI_LN_ITM                      ASC,LOOKUP1_ID                     ASC)

CREATE INDEX XIF594COMMISSION_M ON TLOG.CO_MDFR_CMN(ID_EM                          ASC)


ALTER TABLE TLOG.CO_MDFR_CMN  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, AI_MDFR_CMN)


--------------------------------------------------------
-- TABLE TLOG.CO_MDFR_RTL_PRC
--------------------------------------------------------
DROP TABLE TLOG.CO_MDFR_RTL_PRC

CREATE TABLE TLOG.CO_MDFR_RTL_PRC (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_MDFR_RT_PRC       INTEGER NOT NULL, ID_EM                INTEGER, ID_PRM               INTEGER, RC_MDFR_RT_PRC       CHAR(2), PE_MDFR_RT_PRC       DECIMAL(5,2) NOT NULL DEFAULT 0, MO_MDFR_RT_PRC       DECIMAL(14,3) NOT NULL DEFAULT 0, DP_LDG_STK_MDFR      CHAR(4), MO_PRV_PRC           DECIMAL(8,3) DEFAULT 0, MO_NW_PRC            DECIMAL(8,3) DEFAULT 0)

COMMENT ON TABLE TLOG.CO_MDFR_RTL_PRC IS ' A line item modifier that reflects a modification of the retail selling price. It is provided by PLU through the application of a predefined price change rule that depends on parameters provided during the sale transaction.  Examples of the kinds of par'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.AI_MDFR_RT_PRC IS 'The sequence number for this RetailPriceModifier allowing more than one price modification to occur on each retail transaction line item.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.ID_EM IS 'A unique, non-significant number used to identify a store employee.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.ID_PRM IS 'The unique identifier for a promotion.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.RC_MDFR_RT_PRC IS 'A code that describes why the price modifier is applied to the line item. Possible values include PROMOTION fired and Price label is always right.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.PE_MDFR_RT_PRC IS 'The percent reduction that was applied to the unit retail price to arrive at the modified selling price.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.MO_MDFR_RT_PRC IS 'The flat amount of the price reduction that was removed from the unit selling price to arrive at the modified selling price.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.DP_LDG_STK_MDFR IS 'A code that determines how the price change reflected in this modifier is to be treated for stock ledger accounting purposes.  This code allows price change modifiers to be treated as discounts (expenses below the gross margin line) OR as markdowns (trea'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.MO_PRV_PRC IS 'The unit price that was used as the basis of the price modification.'
COMMENT ON COLUMN TLOG.CO_MDFR_RTL_PRC.MO_NW_PRC IS 'The unit price that was the result of the price modification.'
CREATE INDEX IF1526RetailPriceM ON TLOG.CO_MDFR_RTL_PRC (ID_PRM                         ASC)

CREATE INDEX IF1994RetailPriceM ON TLOG.CO_MDFR_RTL_PRC(ID_EM                          ASC)

-- C0001
-- CREATE INDEX XIF71RETAIL_PRICE_ ON TLOG.CO_MDFR_RTL_PRC
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF71RETAIL_PRICE_ ON TLOG.CO_MDFR_RTL_PRC(AI_LN_ITM                      ASC,LOOKUP1_ID              ASC)


ALTER TABLE TLOG.CO_MDFR_RTL_PRC ADD PRIMARY KEY ( LOOKUP1_ID, AI_LN_ITM, AI_MDFR_RT_PRC)

--------------------------------------------------------
-- TABLE TLOG.CO_MDFR_SRZ
--------------------------------------------------------
DROP TABLE TLOG.CO_MDFR_SRZ

CREATE TABLE TLOG.CO_MDFR_SRZ( LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_ITM	            INTEGER, ID_NMB_SRZ           VARCHAR(40), TY_SRZ	            CHAR(2))


COMMENT ON TABLE TLOG.CO_MDFR_SRZ IS 'A record of the serial number of some item that is related to a particular SaleItem. Eg: Sale of camera & service contract may result in two SaleReturnLineItems each with an instance of SerializedUnitSaleModeifier - one for the camera and one for th'
COMMENT ON COLUMN TLOG.CO_MDFR_SRZ.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_MDFR_SRZ.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_MDFR_SRZ.TY_SRZ IS 'A code denoting if this is a sale, rental or sale of a  related item (eg: Service Contract)'
COMMENT ON COLUMN TLOG.CO_MDFR_SRZ.ID_NMB_SRZ IS 'A unique code, which can be either alpha, numeric or alpha-numeric, to identify an individual ITEM.'
COMMENT ON COLUMN TLOG.CO_MDFR_SRZ.ID_ITM IS 'The retailer''s SKU or unique item identifier for items sold or returned.'
CREATE INDEX IF1958SerializedUn ON TLOG.CO_MDFR_SRZ(ID_NMB_SRZ                     ASC,ID_ITM                         ASC)


ALTER TABLE TLOG.CO_MDFR_SRZ ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.CO_MDFR_TX_EXM
--------------------------------------------------------
DROP TABLE TLOG.CO_MDFR_TX_EXM

CREATE TABLE TLOG.CO_MDFR_TX_EXM (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, MO_EXM_TXBL          DECIMAL(8,3) DEFAULT 0, MO_EXM_TX            DECIMAL(14,3) NOT NULL DEFAULT 0, RC_EXM_TX            CHAR(2), ID_CF_TX_EXM         INTEGER, NM_HLDR_TX_EXM_CF    VARCHAR(40))

COMMENT ON TABLE TLOG.CO_MDFR_TX_EXM IS 'A line item modifier to the TaxLineItem component of a RetailTransaction that provides supplementary data regarding tax exemptions.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.MO_EXM_TX IS 'The amount of TAX the CUSTOMER is exempt from paying.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.RC_EXM_TX IS 'A reason code for the tax exemption. Typically the CUSTOMER belongs a special group, such foreign diplomats, religious bodies, etc. The bearer must have a certificate to qualify for the tax exemption. AUTHORITY.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.ID_CF_TX_EXM IS 'The certificate number assigned to a purchaser by a TaxAuthority exempting the purchaser from tax in that aurhority.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_EXM.NM_HLDR_TX_EXM_CF IS 'The name of the individual or organization who holds the tax exemption certificate.'

ALTER TABLE TLOG.CO_MDFR_TX_EXM ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.MDFR_TX_OVRD
--------------------------------------------------------
DROP TABLE TLOG.CO_MDFR_TX_OVRD

CREATE TABLE TLOG.CO_MDFR_TX_OVRD ( LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_ATHY_TX           VARCHAR(40), ID_GP_TX             INTEGER, MO_TX_ORGL           DECIMAL(8,3) DEFAULT 0, RC_TX_OVRD           CHAR(2), ID_CF_TX_OVRD        INTEGER, NM_CF_HLDR           VARCHAR(40))

COMMENT ON TABLE TLOG.CO_MDFR_TX_OVRD IS 'A line item modifier to the TaxLineItem component of a RetailTransaction that provides supplementary data regarding tax overrides. (Where the amount of tax collected is reduced rather than exempted).'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.ID_ATHY_TX IS 'A specific TAX AUTHORITY that establishes the tax rate. The TAX AUTHORITY is normally a government body.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.MO_TX_ORGL IS 'The original amount of tax that does not have to be collected.'
COMMENT ON COLUMN TLOG.CO_MDFR_TX_OVRD.ID_CF_TX_OVRD IS 'The certificate number assigned to a purchaser by a TaxAuthority,  overriding the normal taxation rules.'
CREATE INDEX IF1786TaxOverrideM ON TLOG.CO_MDFR_TX_OVRD(ID_GP_TX                       ASC, ID_ATHY_TX          ASC)


ALTER TABLE TLOG.CO_MDFR_TX_OVRD ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.CO_VLD_RST
--------------------------------------------------------
DROP TABLE TLOG.CO_VLD_RST

CREATE TABLE TLOG.CO_VLD_RST (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_QST_RST_VLD  INTEGER, NA_ANS               VARCHAR(255))

COMMENT ON TABLE TLOG.CO_VLD_RST IS 'A modifier to a SaleReturnLineItem denoting how a particular SalesRestriction was validated.Eg: In some jurisdictions it is a legal requirement to record the Customer''s fire-arms license number in order to sell ammunition.'
COMMENT ON COLUMN TLOG.CO_VLD_RST.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.CO_VLD_RST.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.CO_VLD_RST.ID_QST_RST_VLD IS 'A unique identifer for the restriction validation question.'
COMMENT ON COLUMN TLOG.CO_VLD_RST.NA_ANS IS 'The answer given by the customer to the given question.'
CREATE INDEX IF1744RestrictionV ON TLOG.CO_VLD_RST(ID_QST_RST_VLD                 ASC)


ALTER TABLE TLOG.CO_VLD_RST  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.CO_VLD_RST_QST
--------------------------------------------------------
DROP TABLE TLOG.CO_VLD_RST_QST

CREATE TABLE TLOG.CO_VLD_RST_QST (ID_QST_RST_VLD       INTEGER NOT NULL,NA_QST_RST_VLD       VARCHAR(255))

COMMENT ON TABLE TLOG.CO_VLD_RST_QST IS 'A standard question that may be asked of a Customer as part of the process of negotiating a SalesRestriction that has been placed upon a class of items.'
COMMENT ON COLUMN TLOG.CO_VLD_RST_QST.ID_QST_RST_VLD IS 'A unique identifer for the restriction validation question.'
COMMENT ON COLUMN TLOG.CO_VLD_RST_QST.NA_QST_RST_VLD IS 'The text of the question that the customer is to be asked when validating a restriction.'

ALTER TABLE TLOG.CO_VLD_RST_QST  ADD PRIMARY KEY (ID_QST_RST_VLD)



--------------------------------------------------------
-- TABLE TLOG.LO_ADS_STD_DMS
--------------------------------------------------------
DROP TABLE TLOG.LO_ADS_STD_DMS

CREATE TABLE TLOG.LO_ADS_STD_DMS (ID_ADS               INTEGER NOT NULL,A1_ADS               VARCHAR(40), A2_ADS               VARCHAR(40), CI_CNCT              VARCHAR(30), ST_CNCT              CHAR(2), PC_CNCT              VARCHAR(15) DEFAULT '')

COMMENT ON TABLE TLOG.LO_ADS_STD_DMS IS 'A non-foreign address that conforms to postal standards.'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.ID_ADS IS 'A unique identifier for a location and mail address.'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.A1_ADS IS 'The first line of the address, normally the street number and name.'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.A2_ADS IS 'The second line of an address, normally the Flat or Building Suite number.'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.CI_CNCT IS 'The city component of an address'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.ST_CNCT IS 'The state component of an address'
COMMENT ON COLUMN TLOG.LO_ADS_STD_DMS.PC_CNCT IS 'The postal or zip code of an address'
-- CREATE INDEX XIF1127STANDARDIZE ON TLOG.LO_ADS_STD_DMS
-- (
--       ID_ADS                         ASC
-- )

-- CREATE INDEX XIF1127STANDARDIZE ON TLOG.LO_ADS_STD_DMS
-- (
--        ID_ADS                         ASC
-- )


ALTER TABLE TLOG.LO_ADS_STD_DMS   ADD PRIMARY KEY (ID_ADS)


--------------------------------------------------------
-- TABLE TLOG.LO_PH
--------------------------------------------------------
DROP TABLE TLOG.LO_PH

CREATE TABLE TLOG.LO_PH (ID_PRTY              INTEGER NOT NULL, ID_PH_TYP            INTEGER NOT NULL, CC_PH                CHAR(3), TA_PH                CHAR(5), TL_PH                CHAR(8), PH_EXTN              CHAR(5))

COMMENT ON TABLE TLOG.LO_PH IS 'A telephone, cellular, pager, fax or other telecommunication device number.'
COMMENT ON COLUMN TLOG.LO_PH.ID_PRTY IS 'A unique, automatically assigned identity for a PARTY.'
COMMENT ON COLUMN TLOG.LO_PH.ID_PH_TYP IS 'A category or telephone (number) types (cell, fax, voice, etc.)'
COMMENT ON COLUMN TLOG.LO_PH.CC_PH IS 'A code assigned by the telephone industry to a country or other region.'
COMMENT ON COLUMN TLOG.LO_PH.TA_PH IS 'A code that identifies a geographic grouping of telephone numbers within the US and Canada.'
COMMENT ON COLUMN TLOG.LO_PH.TL_PH IS 'A number that is used to contact a PARTY via a telephone or device.'
COMMENT ON COLUMN TLOG.LO_PH.PH_EXTN IS 'Addtional numbers required to reach a person, extension, or voice mailbox.'
CREATE INDEX XIF1086TELEPHONE ON TLOG.LO_PH(ID_PRTY                        ASC)

CREATE INDEX XIF1087TELEPHONE ON TLOG.LO_PH(ID_PH_TYP                      ASC)


ALTER TABLE TLOG.LO_PH ADD PRIMARY KEY (ID_PRTY, ID_PH_TYP)


--------------------------------------------------------
-- TABLE TLOG.PA_PRS
--------------------------------------------------------
DROP TABLE TLOG.PA_PRS

CREATE TABLE TLOG.PA_PRS ( ID_PRTY_PRS          INTEGER NOT NULL, NM_PRS_SLN           VARCHAR(40), FN_PRS               VARCHAR(40) NOT NULL, TY_NM_FS             CHAR(2), MD_PRS               VARCHAR(40), TY_NM_MID            CHAR(2), LN_PRS               VARCHAR(40) NOT NULL, TY_NM_LS             CHAR(2), NM_PRS_SFX           VARCHAR(40), TY_GND_PRS           CHAR(2), DC_PRS_BRT           TIMESTAMP, NM_PRS_SR            VARCHAR(40), NM_PRS_ML            VARCHAR(40), NM_PRS_OFCL          VARCHAR(40))

COMMENT ON TABLE TLOG.PA_PRS IS 'A individual of interest to the retail store or retail enterprise.'
COMMENT ON COLUMN TLOG.PA_PRS.ID_PRTY_PRS IS 'A unique, automatically assigned identity for a PARTY.'
COMMENT ON COLUMN TLOG.PA_PRS.NM_PRS_SLN IS 'Extra words that don''t  form part of the person''s name but are normally printed before the FirstName as a courtesy title. For instance, Mr. Ms., Miss, Dr., Prof. etc.'
COMMENT ON COLUMN TLOG.PA_PRS.FN_PRS IS 'A person''s first name. In western cultures, this is the given name, in other cultures it may be the family name.'
COMMENT ON COLUMN TLOG.PA_PRS.TY_NM_FS IS 'A code denoting what kind of name the FirstName is, possible values include: GivenName, OtherGivenName, FamilyName, Patronymic'
COMMENT ON COLUMN TLOG.PA_PRS.MD_PRS IS 'One or more middle names, that are printed between the person''s first and last names.'
COMMENT ON COLUMN TLOG.PA_PRS.TY_NM_MID IS 'A code denoting what kind of name the MiddleName is, possible values include: GivenName, OtherGivenName, FamilyName, Patronymic'
COMMENT ON COLUMN TLOG.PA_PRS.LN_PRS IS 'A person''s last name. In western cultures, this is the family (or patronymic) name, in other cultures it may be the given name.'
COMMENT ON COLUMN TLOG.PA_PRS.TY_NM_LS IS 'A code denoting what kind of name the LastName is, possible values include: GivenName, OtherGivenName, FamilyName, Patronymic'
COMMENT ON COLUMN TLOG.PA_PRS.NM_PRS_SFX IS 'Extra words that don''t  form part of the person''s name but are normally printed after the LastName to help identify the person.  Example values include, Sr, Jr, III'
COMMENT ON COLUMN TLOG.PA_PRS.TY_GND_PRS IS 'A code for specifying a person''s gender.'
COMMENT ON COLUMN TLOG.PA_PRS.DC_PRS_BRT IS 'A person''s date of birth.'
COMMENT ON COLUMN TLOG.PA_PRS.NM_PRS_SR IS 'A culturally sensitive version of the person''s name that is used when producing a sorted list of names.  Examples:Jones, W S ''McGrigor, S F Tryggvi, T'
COMMENT ON COLUMN TLOG.PA_PRS.NM_PRS_ML IS 'A culturally sensitive version of the person''s name that is used when contacting them Examples:Bill Jones,Stuey McGrigor Tryggvi Thordarson'
COMMENT ON COLUMN TLOG.PA_PRS.NM_PRS_OFCL IS 'A culturally sensitive version of the person''s name that is used for all legal documents.Examples:William Stephen Jones Stuart Fergus McGrigor Tryggvi Magnus Thordarson'
-- CREATE INDEX XIF1105PERSON ON TLOG.PA_PRS
-- (
--        ID_PRTY_PRS                    ASC
-- )


ALTER TABLE TLOG.PA_PRS  ADD PRIMARY KEY (ID_PRTY_PRS)



--------------------------------------------------------
-- TABLE TLOG.TR_FDSV
--------------------------------------------------------
DROP TABLE TLOG.TR_FDSV

CREATE TABLE TLOG.TR_FDSV (LOOKUP1_ID BIGINT  NOT NULL, ID_SRV               INTEGER, ID_TB                INTEGER, QU_SZ_PRTY           DECIMAL(3,0) DEFAULT 0 )

COMMENT ON TABLE TLOG.TR_FDSV IS 'A sub-type of RetailTransaction specifically for the Food Service segment of the retail industry. Which can be used to record TableNumber, PartySize, Servers, etc...'
COMMENT ON COLUMN TLOG.TR_FDSV.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_FDSV.ID_SRV IS 'A unique identifier for the Server'
COMMENT ON COLUMN TLOG.TR_FDSV.ID_TB IS 'A unique identifier for the table that was used for the hospitality transaction.'
COMMENT ON COLUMN TLOG.TR_FDSV.QU_SZ_PRTY IS 'The number of people served at the table during the hospitality transaction.'
-- CREATE INDEX IF1750FoodServiceT ON TLOG.TR_FDSV
-- (
--        ID_SRV                         ASC,
--        ID_STR_RT                      ASC
-- )

-- CREATE INDEX IF1752FoodServiceT ON TLOG.TR_FDSV
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX IF1753FoodServiceT ON TLOG.TR_FDSV
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_FDSV ADD PRIMARY KEY (LOOKUP1_ID)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_CHK_TND
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_CHK_TND

CREATE TABLE TLOG.TR_LTM_CHK_TND (LOOKUP1_ID              BIGINT NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_BK_CHK            INTEGER, ID_ACNT_CHK          VARCHAR(20), LU_MTH_ACNT_ENR      VARCHAR(20), AI_CHK               SMALLINT, LU_MTH_SQN_ENR       VARCHAR(20), TY_ID_PRSL_RQ        CHAR(2), ID_PRSL_AZN          INTEGER, ID_ADJN_CHK          CHAR(4), DC_BRT_CHK           CHAR(2))

COMMENT ON TABLE TLOG.TR_LTM_CHK_TND IS 'A type of TENDER LINE ITEM that records the specifics about a check received from a customer in settling a transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.ID_BK_CHK IS 'The unique identifier of the bank or third party authorization center.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.ID_ACNT_CHK IS 'The check account number of CUSTOMERs whose checks have been previously honored or rejected. Retaining a check history by CUSTOMER provides the RETAIL STORE with a means of tender authorization.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.LU_MTH_ACNT_ENR IS 'A code denoting how the CheckAccountNumber was entered into the system.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.AI_CHK IS 'A unique sequence number relating to a particular check authorization.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.LU_MTH_SQN_ENR IS 'A code denoting how the CheckSequenceNumber was entered into the system.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.TY_ID_PRSL_RQ IS 'Identifies the type of personal identification required to authorize tender.  Examples include driver''s license, a second credit card, social security card, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.ID_PRSL_AZN IS 'The personal identification number that must be keyed by an individual at the point of sale when paying by personal check.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.ID_ADJN_CHK IS 'A code to denote that approval has been received from the authorization center.'
COMMENT ON COLUMN TLOG.TR_LTM_CHK_TND.DC_BRT_CHK IS 'The customer''s date of birth captured as part of the personal data required to verify their identity and authorize their use of a check to pay for a purchase.'

-- CREATE INDEX XIF445TENDER_CHECK ON TLOG.TR_LTM_CHK_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF445TENDER_CHECK ON TLOG.TR_LTM_CHK_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_LTM_CHK_TND ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_CPN_TND
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_CPN_TND

CREATE TABLE TLOG.TR_LTM_CPN_TND (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM	          SMALLINT NOT NULL, ID_MF                INTEGER,  FC_FMY_MF            CHAR(3), AI_LN_ITM_VL         SMALLINT, UC_CPN_SC            VARCHAR(15) DEFAULT '', DC_CPN_EP            VARCHAR(20), LU_CPN_PRM           CHAR(6), FL_ENR_CPN_KY        SMALLINT)

COMMENT ON TABLE TLOG.TR_LTM_CPN_TND IS 'Records the use of a coupon (which must be valiated against an item in the TRANSACTION) to tender part (or all) of a TRANSACTION.'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.AI_LN_ITM_VL IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.ID_MF IS 'A unique identifier to denote the ITEM MANUFACTURER.'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.FC_FMY_MF IS 'The UPC designated three digit coupon family code for the manufacturer item.'
-- COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.UC_CPN_SC IS 'The barcode on a store or manufacturer coupon. The coupon scan code comprises two pTLOGARTS: the first is a fixed 12 character code that contains the manufacturer identification, family code, and coupon value, the second is based on Code 128 and comprises up'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.DC_CPN_EP IS 'The date a coupon may no longer be used as part of the settlement of a sale transaction. It is normally found in the UCC/EAN-128 coupon extended code. In this code, the expiration code is only four digits and contains only month and year. The day is alwa'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.LU_CPN_PRM IS 'Identifies a promotion associated with the coupon.  Promotion codes are used by manufacturers and suppliers to analyze the impact their promotion is having on sales across a geographic area and over a specified promotional period of time.'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.FL_ENR_CPN_KY IS 'A flag to denote whether the coupon is key entered or scanned, i.e. 0=no (scanned), 1=yes (key entered)'
COMMENT ON COLUMN TLOG.TR_LTM_CPN_TND.AI_LN_ITM_VL IS 'The sequence number of line item within the context of this RetailTransaction.'
CREATE INDEX XIF1018COUPON_LINE ON TLOG.TR_LTM_CPN_TND( FC_FMY_MF                      ASC,ID_MF                          ASC)

-- CREATE INDEX XIF444COUPON_LINE_ ON TLOG.TR_LTM_CPN_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF164COUPON_LINE_ ON TLOG.TR_LTM_CPN_TND
-- (
--       AI_LN_ITM	                ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF444COUPON_LINE_ ON TLOG.TR_LTM_CPN_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_LTM_CPN_TND ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_CRDB_CRD_TN
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_CRDB_CRD_TN

CREATE TABLE TLOG.TR_LTM_CRDB_CRD_TN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, TY_CRD               CHAR(6), ID_ISSR_TND_MD       INTEGER, ID_ACNT_DB_CR_CRD    VARCHAR(40), LU_NMB_CRD_SWP_KY    CHAR(2), LU_SCR_ENR           CHAR(2), TY_ID_PRSL_RQ        CHAR(2), ID_RFC_PRSL_ID       INTEGER, LU_MTH_AZN           CHAR(4), DE_TRCK_1_BT_MP      BLOB, DE_TRCK_2_BT_MP      BLOB, DE_TRCK_3_BT         BLOB, LU_ADJN_CRDB         CHAR(6), CH_IM_TND_AZN_CT     CHAR(2), DC_EP_CRD            CHAR(4), NM_CRD_HLD           VARCHAR(40),AI_CRD_ISS           INTEGER)

COMMENT ON TABLE TLOG.TR_LTM_CRDB_CRD_TN IS 'A type of TENDER LINE ITEM that records the specifics about a credit or debit card used to settle a transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.TY_CRD IS 'A code denoting which kind of card is being accepted.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.ID_ISSR_TND_MD IS 'The identifying number of the bank, credit union, financial services firm or other third party issuing the debit/credit card used in the transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.ID_ACNT_DB_CR_CRD IS 'The account number appearing on a debit/credit card and identifying the card issuer''s customer account to be charged or credited for the transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.LU_NMB_CRD_SWP_KY IS 'A code that indicates whether the credit or debit card account number was read using a magnetic stripe reader (i.e. swiped) or keyed.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.LU_SCR_ENR IS 'A code denoting who entered the card: Merchant or Customer.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.TY_ID_PRSL_RQ IS 'Identifies the type of personal identification required to authorize tender.  Examples include driver''s license, a second credit card, social security card, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.ID_RFC_PRSL_ID IS 'The identifying number of the driver license or other personal id provided by the customer to verify his/her identity at the point of sale.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.LU_MTH_AZN IS 'Identifies the method used to authorize tender. Examples include by electronic query, by sales employee visual inspection of customer card and id.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.DE_TRCK_1_BT_MP IS 'Defines the bit pattern used on track 1 of the magnetic strip on the back of a credit card.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.DE_TRCK_2_BT_MP IS 'Defines the bit pattern used on track 2 of the magnetic strip on the back of a credit card.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.DE_TRCK_3_BT IS 'Defines the bit pattern used on track 3 of the magnetic strip on the back of a credit card.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.LU_ADJN_CRDB IS 'A code indicating the result of a request to authorize the use of tender to settle a transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.CH_IM_TND_AZN_CT IS 'Digitized image of the customer''s signature.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.DC_EP_CRD IS 'The expiration date of the Credit or Debit card, as taken from the card in MMYY format.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.NM_CRD_HLD IS 'The name of the cardholder, as taken from the card.'
COMMENT ON COLUMN TLOG.TR_LTM_CRDB_CRD_TN.AI_CRD_ISS IS 'The IssueSequnce number of the credit card being used.'
-- CREATE INDEX XIF446CREDIT_DEBIT ON TLOG.TR_LTM_CRDB_CRD_TN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF446CREDIT_DEBIT ON TLOG.TR_LTM_CRDB_CRD_TN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_LTM_CRDB_CRD_TN ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_DSC
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_DSC

CREATE TABLE TLOG.TR_LTM_DSC (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, TY_DSC               CHAR(2), MO_DSC               DECIMAL(14,3) NOT NULL DEFAULT 0)

COMMENT ON TABLE TLOG.TR_LTM_DSC IS 'A line item component of a RETAIL that records the granting of a reduction of price on items and/or services purchased by a customer and treats that price reduction as an expense item for accounting purposes.'
COMMENT ON COLUMN TLOG.TR_LTM_DSC.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_DSC.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_DSC.TY_DSC IS 'The type code used as a look up key for the standard discount types represented in the DISCOUNT entity collection'
COMMENT ON COLUMN TLOG.TR_LTM_DSC.MO_DSC IS 'The monetary value for the discount line item.'
CREATE INDEX XIF153DISCOUNT_LIN ON TLOG.TR_LTM_DSC(TY_DSC                         ASC)

-- CREATE INDEX XIF85DISCOUNT_LINE ON TLOG.TR_LTM_DSC
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- C0001
-- CREATE INDEX XIF85DISCOUNT_LINE ON TLOG.TR_LTM_DSC
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF85DISCOUNT_LINE ON TLOG.TR_LTM_DSC( LOOKUP1_ID                         ASC)


ALTER TABLE TLOG.TR_LTM_DSC ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_GF_CF
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_GF_CF

CREATE TABLE TLOG.TR_LTM_GF_CF (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_STR_ISSG          INTEGER,    ID_NMB_SRZ_GF_CF     VARCHAR(40) NOT NULL, LU_NMB_SRZ_SC_KY     CHAR(2))

COMMENT ON TABLE TLOG.TR_LTM_GF_CF IS 'A type of RETAIL TRANSACTION LINE ITEM that records the sale of  redeemable form of tender for a predetermined monetary value of sellable merchandise in the store.  Creates a liability for the retailer in the amount denoted on the face value of the certi'
COMMENT ON COLUMN TLOG.TR_LTM_GF_CF.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_GF_CF.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_GF_CF.ID_STR_ISSG IS 'A unique store number reference to identify the RETAIL STORE that issued the GIFT CERTIFICATE.'
COMMENT ON COLUMN TLOG.TR_LTM_GF_CF.ID_NMB_SRZ_GF_CF IS 'The serial number that uniquely identifies a GIFT CERTIFICATE.'
COMMENT ON COLUMN TLOG.TR_LTM_GF_CF.LU_NMB_SRZ_SC_KY IS 'A code that indicates whether the serial number for the gift certificate was keyed or scanned.'
-- c0001
-- CREATE INDEX XIF128GIFT_CERTIFI ON TLOG.TR_LTM_GF_CF
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
--)
CREATE INDEX XIF128GIFT_CERTIFI ON TLOG.TR_LTM_GF_CF(LOOKUP1_ID                         ASC)

CREATE INDEX XIF434GIFT_CERTIFI ON TLOG.TR_LTM_GF_CF(ID_STR_ISSG                    ASC, ID_NMB_SRZ_GF_CF               ASC)

-- CREATE INDEX XIF128GIFT_CERTIFI ON TLOG.TR_LTM_GF_CF
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_LTM_GF_CF ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_PYAN
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_PYAN

CREATE TABLE TLOG.TR_LTM_PYAN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_ACNT_CT_CRD       INTEGER, ID_CTAC              INTEGER, FL_PYM_RCV           SMALLINT, MO_PYM_AGT_RCV       DECIMAL(14,3) NOT NULL DEFAULT 0, LU_ACNT_PYMAGT_RCV   CHAR(4), ID_ACNT_PYMAGT_RCV   INTEGER)

COMMENT ON TABLE TLOG.TR_LTM_PYAN IS 'A detail line item recording a payment for a product or service purchased on an installment account basis. These line items are different from those charged to a house account. In this case the account normally has to be completely paid off within a spec'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.AI_ACNT_CT_CRD IS 'A unique retailer assigned identifier for a CustomerAccountCard.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.ID_CTAC IS 'A unique identifier for a customer account.  Generally assigned by the home office.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.FL_PYM_RCV IS 'A flag to denote that payment is outstanding on the account.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.MO_PYM_AGT_RCV IS 'The monetary payment on account received from the CUSTOMER.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.LU_ACNT_PYMAGT_RCV IS 'A code to denote the type of payment on account, eg layaway, house, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_PYAN.ID_ACNT_PYMAGT_RCV IS 'The unique identifier for the customer account .'
-- c0001
-- CREATE INDEX XIF120PAYMENT_ON_A ON TLOG.TR_LTM_PYAN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF120PAYMENT_ON_A ON TLOG.TR_LTM_PYAN( LOOKUP1_ID                         ASC)

CREATE INDEX IF1930PaymentOnAcc ON TLOG.TR_LTM_PYAN(AI_ACNT_CT_CRD                 ASC)

-- CREATE INDEX XIF120PAYMENT_ON_A ON TLOG.TR_LTM_PYAN
-- (
--        AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

CREATE INDEX XIF770PAYMENT_ON_A ON TLOG.TR_LTM_PYAN(ID_CTAC                        ASC)


ALTER TABLE TLOG.TR_LTM_PYAN ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_RTL_TRN
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_RTL_TRN

CREATE TABLE TLOG.TR_LTM_RTL_TRN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_LN_ITM_VD         SMALLINT, TY_LN_ITM            CHAR(2), TS_LN_ITM_BGN        TIMESTAMP,  FL_VD_LN_ITM         SMALLINT, TS_LN_ITM_END        TIMESTAMP, LU_MTH_LTM_RTL_TRN   VARCHAR(20))

COMMENT ON TABLE TLOG.TR_LTM_RTL_TRN IS 'A detail line item of a RetailTransaction that records the business conducted between the retail store and another party involving the exchange in ownership and/or accountability for merchandise and/or tender or involving the exchange of tender for servi'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.AI_LN_ITM_VD IS 'The sequence number of another line item within the transaction - THAT THIS LINE ITEM voids.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.TY_LN_ITM IS 'A code to denote the type of retail transaction line item, such as Sale/Return, Void,  miscellaneous fee, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.TS_LN_ITM_BGN IS 'The start time of the RETAIL TRANSACTION line item.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.FL_VD_LN_ITM IS 'Flag that determines whether this line item has been voided/reversed by another line item in the transaction.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.TS_LN_ITM_END IS 'The end time of the RETAIL TRANSACTION line item.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN.LU_MTH_LTM_RTL_TRN IS 'A retailer assigned code to denote how the ReteailTransactionLineItem was entered at the Workstation. Example values include: Keyed, Scanned, MICR, MSR, SmartCard, RFID.'
-- C0001
-- CREATE INDEX IF1925RetailTransa ON TLOG.TR_LTM_RTL_TRN
-- (
--        AI_LN_ITM_VD                   ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX IF1925RetailTransa ON TLOG.TR_LTM_RTL_TRN ( AI_LN_ITM_VD                   ASC, LOOKUP1_ID                         ASC)

-- C0001
-- CREATE INDEX XIF81POS_SALE_TRAN ON TLOG.TR_LTM_RTL_TRN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF81POS_SALE_TRAN ON TLOG.TR_LTM_RTL_TRN(LOOKUP1_ID                         ASC)


ALTER TABLE TLOG.TR_LTM_RTL_TRN  ADD PRIMARY KEY (LOOKUP1_ID,AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_RTL_TRN_OVR
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_RTL_TRN_OVR

CREATE TABLE TLOG.TR_LTM_RTL_TRN_OVR (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_OPR               INTEGER NOT NULL, TS_LTM_RTL_TRN_OVR   TIMESTAMP, RC_LTM_RTL_TRN_OVR   VARCHAR(255))

COMMENT ON TABLE TLOG.TR_LTM_RTL_TRN_OVR IS 'A supervisory authorization for overriding a transaction parameter such as price or quantity limits.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN_OVR.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN_OVR.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN_OVR.ID_OPR IS 'A unique, automatically assigned number used to identify a workstation OPERATOR.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN_OVR.TS_LTM_RTL_TRN_OVR IS 'The date and time that a transaction line item is being overridden.'
COMMENT ON COLUMN TLOG.TR_LTM_RTL_TRN_OVR.RC_LTM_RTL_TRN_OVR IS 'Descriptive narrative about the reason a transaction line item is being overridden.'
-- CREATE INDEX IF1313RetailTransa ON TLOG.TR_LTM_RTL_TRN_OVR
-- (
--        ID_OPR                         ASC,
--        ID_STR_RT                      ASC
-- )


ALTER TABLE TLOG.TR_LTM_RTL_TRN_OVR ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_SLS_RTN
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_SLS_RTN

CREATE TABLE TLOG.TR_LTM_SLS_RTN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_STR_RT_ORG        INTEGER, ID_WS_ORG            INTEGER, DC_DY_BSN_ORG        INTEGER, AI_TRN_ORG           INTEGER, AI_LN_ITM_ORG        SMALLINT, ID_ITM_PS_STRGP	    INTEGER, ID_ITM_PS	    INTEGER, ID_ITM_PS_QFR	    INTEGER, ID_ITM		    INTEGER,  ID_DPT_PS	    INTEGER, LU_UOM		    CHAR(2), ID_GP_TX             INTEGER, TY_ITM               CHAR(4),  MO_PRC_REG           DECIMAL(8,3) NOT NULL DEFAULT 0,  MO_PRC_ACT           DECIMAL(8,3) DEFAULT 0, QU_ITM_LM_RTN_SLS    DECIMAL(9,2) NOT NULL DEFAULT 0, QU_UN                DECIMAL(9,2) DEFAULT 0, MO_EXTND             DECIMAL(14,3) NOT NULL DEFAULT 0, RC_RTN_MR            CHAR(2), LU_MTH_ID_ENR        CHAR(4), LU_ENR_RT_PRC        CHAR(4), LU_PRC_RT_DRVN       CHAR(4), LU_ACTN_CD           CHAR(2))
--       ID_STR_RT            INTEGER,
--       ID_WS                INTEGER,
--       DC_DY_BSN            TIMESTAMP,
--       AI_TRN               INTEGER
-- )

COMMENT ON TABLE TLOG.TR_LTM_SLS_RTN IS 'A line item component of a  RETAIL  TRANSACTION that records the exchange in ownership of a merchandise item (i.e. a sale or return) or the sale or refund related to a service.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.ID_DPT_PS IS 'A unique system-assigned identifier for the POSDepartment'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.ID_ITM_PS IS 'The barcode, point of sale scan code or other keyed identifying number used at POS and the internal stock keping ItemID for the item. Will generally be filled with the GTIN (UPC, EAN etc) for an item -- but it is not mandatory -- A retailer may devel'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.ID_ITM_PS_QFR IS 'A secondary qualifier on the POSItemID which denotes a separate item. Eg: When single bottles & six-packs of the same beverage both have the same UPC or other barcode, the POSItemIDQualifier holds denotes the two different items.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.ID_ITM IS 'The retailer''s SKU or unique item identifier for items sold or returned.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LU_UOM IS 'The code used to specify the units in which a value is being expressed, or manner in which a measurement has been taken. This code relates to the UCC data element 355.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.AI_LN_ITM_ORG IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.TY_ITM IS 'Meta-Data denoting the kind of item being sold (or returned) in the line item'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.MO_PRC_REG IS 'The regular or lookup per-unit price for the item before any discounts have been applied.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.MO_PRC_ACT IS 'The actual per-unit price paid by the customer for this particular sale. It is obtained by applying  applicable price derivation rules to the regular unit price.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.QU_ITM_LM_RTN_SLS IS 'The number of retail selling units sold to or returned by a customer.  For services the number of units (e.g. hours or job) sold or in the case of refunds, reduced to zero revenue.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.QU_UN IS 'The number of units sold, when selling bulk merchandise. Eg: A sale of 20 Gallons of Gas: Quantity=1, Units=20, UnitOfMeasure=Ga Eg: A sale of 3 cans of Beans: Quantity=3, Units=1, UnitOfMeasure=Ea'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.MO_EXTND IS 'The product of multiplying Quantity by the retail selling unit price derived from price lookup (and any applicable price derivation rules).  This retail sale unit price excludes sales and/or value added tax.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.RC_RTN_MR IS 'A code that describes why a customer is returning merchandise.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LU_MTH_ID_ENR IS 'A code that describes how this line item''s item identification is being entered (e.g. it is scanned, keyed SKU, keyed department, etc.)'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LU_ENR_RT_PRC IS 'A code that describes how this line item''s retail selling unit price is being entered (e.g. it is manually keyed, obtained from price lookup,  etc.)'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LU_PRC_RT_DRVN IS 'A code that documents how the selling unit retail prices were derived for this line item.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LU_ACTN_CD IS 'A code denoting how the item is being treated in the item.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
--CREATE INDEX XIF1025SALE_RETURN ON TLOG.TR_LTM_SLS_RTN
--(
--       AI_LN_ITM_ORGL                 ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
--)

--CREATE INDEX IF1419SaleReturnLi ON TLOG.TR_LTM_SLS_RTN
--(
--       ID_GP_TX                       ASC
--)

--CREATE INDEX IF1753SaleReturnLi ON TLOG.TR_LTM_SLS_RTN
--(
--       LU_UOM                         ASC
--)

--CREATE INDEX IF1841SaleReturnLi ON TLOG.TR_LTM_SLS_RTN
--(
--      ID_ITM                         ASC
--)

--CREATE INDEX IF2005SaleReturnLi ON TLOG.TR_LTM_SLS_RTN
--(
--       ID_DPT_PS                      ASC
--)

--CREATE INDEX IF2006SaleReturnLi ON TLOG.TR_LTM_SLS_RTN
--(
--       ID_ITM_PS                      ASC,
--       ID_ITM_PS_QFR                  ASC
--)

-- CREATE INDEX XIF94SALE_RETURN_T ON TLOG.TR_LTM_SLS_RTN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF431SALE_RETURN_ ON TLOG.TR_LTM_SLS_RTN
-- (
--       ID_DPT_PS                      ASC
-- )

-- C0001
-- CREATE INDEX XIF94SALE_RETURN_T ON TLOG.TR_LTM_SLS_RTN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF94SALE_RETURN_T ON TLOG.TR_LTM_SLS_RTN( LOOKUP1_ID                         ASC)


ALTER TABLE TLOG.TR_LTM_SLS_RTN ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_SLS_RTN_TX
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_SLS_RTN_TX

CREATE TABLE TLOG.TR_LTM_SLS_RTN_TX (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,ID_ATHY_TX           VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL,  MO_TXBL_RTN_SLS      DECIMAL(14,3) NOT NULL DEFAULT 0, MO_TX_RTN_SLS        DECIMAL(14,3) NOT NULL DEFAULT 0)

COMMENT ON TABLE TLOG.TR_LTM_SLS_RTN_TX IS 'A Line Item to record taxation implications of a single SALE RETURN LINE ITEM rather than an entire RETAIL TRANSACTION.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.ID_ATHY_TX IS 'A specific TAX AUTHORITY that establishes the tax rate. The TAX AUTHORITY is normally a government body.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.MO_TXBL_RTN_SLS IS 'The monetary amount for which tax is applicable.'
COMMENT ON COLUMN TLOG.TR_LTM_SLS_RTN_TX.MO_TX_RTN_SLS IS 'The  monetary value tax that is being collected by this LineItem.'
-- C0001
-- CREATE INDEX XIF1041SALE_RETURN ON TLOG.TR_LTM_SLS_RTN_TX
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF1041SALE_RETURN ON TLOG.TR_LTM_SLS_RTN_TX(AI_LN_ITM                      ASC, LOOKUP1_ID                         ASC)

CREATE INDEX XIF1042SALE_RETURN ON TLOG.TR_LTM_SLS_RTN_TX(ID_GP_TX                       ASC, ID_ATHY_TX                     ASC)


ALTER TABLE TLOG.TR_LTM_SLS_RTN_TX ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, ID_ATHY_TX, ID_GP_TX )


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_TND
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_TND

CREATE TABLE TLOG.TR_LTM_TND (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,TY_TND               CHAR(4), ID_ACNT_NMB          INTEGER,ID_ACNT_TND          INTEGER, MO_FRG_CY            DECIMAL(8,3) NOT NULL DEFAULT 0, MO_ITM_LN_TND        DECIMAL(14,3) NOT NULL DEFAULT 0, TY_VR_ADS            CHAR(2))

COMMENT ON TABLE TLOG.TR_LTM_TND IS 'A line item component of a POS TRANSACTION that records the settlement of that transaction with an offsetting, valid tender type.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.TY_TND IS 'A code which uniquely identifies the type of tender, ie cash, check, credit card, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.ID_ACNT_NMB IS 'The CUSTOMER''s account number against which previous tender authorization is held.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.ID_ACNT_TND IS 'The account number of the customer tendering the TENDER. This account number is retained as a means of an authorization history against which future payments can be referenced.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.MO_FRG_CY IS 'The monetary value (in the currency submitted by the Customer)  of the tender submitted by the Customer.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.MO_ITM_LN_TND IS 'The monetary value (in the default currency of the RetailStore) of the tender submitted by the Customer.'
COMMENT ON COLUMN TLOG.TR_LTM_TND.TY_VR_ADS IS 'A code denoting how the customer''s address was verified.'
CREATE INDEX XIF172TENDER_LINE_ ON TLOG.TR_LTM_TND( ID_ACNT_NMB                    ASC, TY_TND                         ASC)

-- CREATE INDEX XIF88TENDER_LINE_I ON TLOG.TR_LTM_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- C0001
-- CREATE INDEX XIF88TENDER_LINE_I ON TLOG.TR_LTM_TND
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- )
CREATE INDEX XIF88TENDER_LINE_I ON TLOG.TR_LTM_TND(LOOKUP1_ID                         ASC)

CREATE INDEX XIF96TENDER_LINE_I ON TLOG.TR_LTM_TND(TY_TND                         ASC)


ALTER TABLE TLOG.TR_LTM_TND  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_TND_CHN
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_TND_CHN

CREATE TABLE TLOG.TR_LTM_TND_CHN (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, TY_TND               CHAR(4),  MO_LN_ITM_TND_CHN    DECIMAL(14,3) NOT NULL DEFAULT 0)

COMMENT ON TABLE TLOG.TR_LTM_TND_CHN IS 'A line item component of a POS TRANSACTION that records the tender returned to a customer as change as part of the settlement of a TRANSACTION.'
COMMENT ON COLUMN TLOG.TR_LTM_TND_CHN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_TND_CHN.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_TND_CHN.TY_TND IS 'A code which uniquely identifies the type of tender, ie cash, check, credit card, etc.'
COMMENT ON COLUMN TLOG.TR_LTM_TND_CHN.MO_LN_ITM_TND_CHN IS 'A line item for the monetary amount due back to a CUSTOMER when an overtender is made in exchange for ITEMs.'
CREATE INDEX XIF426TENDER_CHANG ON TLOG.TR_LTM_TND_CHN(TY_TND                         ASC)

-- CREATE INDEX XIF90TENDER_CHANGE ON TLOG.TR_LTM_TND_CHN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

CREATE INDEX XIF90TENDER_CHANGE ON TLOG.TR_LTM_TND_CHN(LOOKUP1_ID			ASC)
-- c0001
--	LOOKUP1_ID			ASC
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
--	)


ALTER TABLE TLOG.TR_LTM_TND_CHN  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_LTM_TX
--------------------------------------------------------
DROP TABLE TLOG.TR_LTM_TX

CREATE TABLE TLOG.TR_LTM_TX ( LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,ID_ATHY_TX           VARCHAR(40), ID_GP_TX             INTEGER, MO_TXBL              DECIMAL(14,3) NOT NULL DEFAULT 0, MO_TX                DECIMAL(14,3) DEFAULT 0)

COMMENT ON TABLE TLOG.TR_LTM_TX IS 'A line item component of a RETAIL TRANSACTION that records the charging and offsetting liability credit for sales tax on merchandise items and services sold by the store or debit for merchandise returned to the store.'
COMMENT ON COLUMN TLOG.TR_LTM_TX.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_LTM_TX.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_LTM_TX.ID_ATHY_TX IS 'A specific TAX AUTHORITY that establishes the tax rate. The TAX AUTHORITY is normally a government body.'
COMMENT ON COLUMN TLOG.TR_LTM_TX.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.TR_LTM_TX.MO_TXBL IS 'The amount of the line for which tax is applicable.'
COMMENT ON COLUMN TLOG.TR_LTM_TX.MO_TX IS 'The monetary amount of sales TAX calculated by applying a set percentage to the line item. These percentages can vary by county, state and country.'
CREATE INDEX XIF805SALES_TAX_LI ON TLOG.TR_LTM_TX(ID_GP_TX                       ASC, ID_ATHY_TX                     ASC)

-- CREATE INDEX XIF92SALES_TAX_LIN ON TLOG.TR_LTM_TX
-- (
--        AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

CREATE INDEX XIF92SALES_TAX_LIN ON TLOG.TR_LTM_TX(LOOKUP1_ID			ASC)
-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_LTM_TX ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM)


--------------------------------------------------------
-- TABLE TLOG.TR_MDFR_SLS_TX_EXM
--------------------------------------------------------
DROP TABLE TLOG.TR_MDFR_SLS_TX_EXM

CREATE TABLE TLOG.TR_MDFR_SLS_TX_EXM (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,ID_ATHY_TX           VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL,  MO_EXM_TXBL          DECIMAL(8,3) DEFAULT 0, MO_EXM_TX            DECIMAL(8,3) DEFAULT 0, RC_EXM_TX            CHAR(2), ID_CF_TX_EXM         INTEGER, NM_CF_HLDR           VARCHAR(40))

COMMENT ON TABLE TLOG.TR_MDFR_SLS_TX_EXM IS 'A line item modifier to the SaleReturnTaxLineItem component of a RetailTransaction that provides supplementary data regarding tax exemptions.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.ID_ATHY_TX IS 'A specific TAX AUTHORITY that establishes the tax rate. The TAX AUTHORITY is normally a government body.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.MO_EXM_TXBL IS 'The Taxable amount which the customer would''ve been liable to pay tax on had they not been granted this exemption.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.MO_EXM_TX IS 'The amount of tax that the customer would''ve been liable to pay had thus TaxExemption not been granted.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.RC_EXM_TX IS 'A retailer assigned code denoting why this TaxExemption was granted.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.ID_CF_TX_EXM IS 'A unique identifier taken from the TaxExemption Certificate that the customer presented in order to get this Tax Exemption.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_EXM.NM_CF_HLDR IS 'The Customer name taken from the TaxExemption Certificate that the customer presented in order to get this Tax Exemption.'

ALTER TABLE TLOG.TR_MDFR_SLS_TX_EXM ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, ID_ATHY_TX, ID_GP_TX )


--------------------------------------------------------
-- TABLE TLOG.TR_MDFR_SLS_TX_OVRD
--------------------------------------------------------
DROP TABLE TLOG.TR_MDFR_SLS_TX_OVRD

CREATE TABLE TLOG.TR_MDFR_SLS_TX_OVRD (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_ATHY_TX           VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL,  MO_TX_ORGL           DECIMAL(8,3) DEFAULT 0, RC_TX_OVRD           CHAR(2), ID_CF_TX_OVRD        INTEGER,  NM_CF_HLDR           VARCHAR(40))

COMMENT ON TABLE TLOG.TR_MDFR_SLS_TX_OVRD IS 'A line item modifier to the SaleReturnTaxLineItem component of a RetailTransaction that provides supplementary data regarding tax overrides. (Where the amount of tax collected is reduced rather than exempted).'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.ID_ATHY_TX IS 'A specific TAX AUTHORITY that establishes the tax rate. The TAX AUTHORITY is normally a government body.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.ID_GP_TX IS 'A unique retailer assigned identifier for the TaxGroup'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.MO_TX_ORGL IS 'The Original amount of Tax that should''ve been collected but wasn''t because of this TaxOverrideModifier.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.RC_TX_OVRD IS 'A retailer assigned reason code denoting why this TaxOverride is being granted.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.ID_CF_TX_OVRD IS 'A unique identifier taken from a TaxOverride certificate that was presented by the Customer in order to claim the TaxOverride.'
COMMENT ON COLUMN TLOG.TR_MDFR_SLS_TX_OVRD.NM_CF_HLDR IS 'The name of the Customer taken from a TaxOverride certificate that was presented by the Customer in order to claim the TaxOverride.'
CREATE INDEX IF1860SaleReturnTa ON TLOG.TR_MDFR_SLS_TX_OVRD(ID_GP_TX                       ASC, ID_ATHY_TX                     ASC)


ALTER TABLE TLOG.TR_MDFR_SLS_TX_OVRD  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, ID_ATHY_TX, ID_GP_TX )


--------------------------------------------------------
-- TABLE TLOG.TR_RTL
--------------------------------------------------------
DROP TABLE TLOG.TR_RTL

CREATE TABLE TLOG.TR_RTL (LOOKUP1_ID BIGINT  NOT NULL, ID_CT                INTEGER,IN_RNG_ELPSD         DECIMAL(5,0) NOT NULL DEFAULT 0, IN_TND_ELPSD         DECIMAL(5,0) NOT NULL DEFAULT 0, IN_ELPSD_IDL         DECIMAL(5,0) NOT NULL DEFAULT 0, IN_LCK_ELPSD         DECIMAL(5,0) NOT NULL DEFAULT 0, QU_UN_RTL_TRN        DECIMAL(3,0) DEFAULT 0, QU_ITM_LN_SC         DECIMAL(7,0) NOT NULL DEFAULT 0, PE_ITM_LN_SC         DECIMAL(5,2) NOT NULL DEFAULT 0, QU_ITM_LN_KY         DECIMAL(7,0) NOT NULL DEFAULT 0, PE_ITM_LN_KY         DECIMAL(5,2) NOT NULL DEFAULT 0, QU_DPT_KY            DECIMAL(7,0) NOT NULL DEFAULT 0, PE_DPT_KY            DECIMAL(5,2) NOT NULL DEFAULT 0, FL_SPN               SMALLINT)

COMMENT ON TABLE TLOG.TR_RTL IS 'A type of TRANSATION that records the business conducted between the RETAIL STORE and another party involving the exchange in ownership and/or accountability for merchandise and/or tender or involving the exchange of tender for services.'
COMMENT ON COLUMN TLOG.TR_RTL.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_RTL.ID_CT IS 'A unique identifier for the customer that conducted the RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_RTL.IN_RNG_ELPSD IS 'The total time elapsed between commencement of the RetailTransaction and the commencement of the transaction tendering process.'
COMMENT ON COLUMN TLOG.TR_RTL.IN_TND_ELPSD IS 'The total time taken to receive all the tender and complete the RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_RTL.IN_ELPSD_IDL IS 'The total time taken that a particular Workstation was idle between completion of the previous and commencement of the current RetailTransaction'
COMMENT ON COLUMN TLOG.TR_RTL.IN_LCK_ELPSD IS 'The total time the workstation is in lock mode, ie securement of the WORKSTATION to prevent misuse by another party, between the previous and current RetailTransactions.'
COMMENT ON COLUMN TLOG.TR_RTL.QU_UN_RTL_TRN IS 'The total number of individual ITEMs which are sold in the transaction'
COMMENT ON COLUMN TLOG.TR_RTL.QU_ITM_LN_SC IS 'The total number of individual ITEMs which are scanned at the point of sale, in comparison to those keyed.'
COMMENT ON COLUMN TLOG.TR_RTL.PE_ITM_LN_SC IS 'The total number of individual ITEMs which are scanned at the point of sale, as a percentage of the total data capture time.'
COMMENT ON COLUMN TLOG.TR_RTL.QU_ITM_LN_KY IS 'the total number of ITEMs which are keyed at the point of sale in comparison to scanned.'
COMMENT ON COLUMN TLOG.TR_RTL.PE_ITM_LN_KY IS 'The total number of individual ITEMs which are keyed at the point of sale, as a percentage of the total data capture time.'
COMMENT ON COLUMN TLOG.TR_RTL.QU_DPT_KY IS 'The total number of ITEMs which are keyed by department at the point of sale.'
COMMENT ON COLUMN TLOG.TR_RTL.PE_DPT_KY IS 'The total number of individual ITEMs which are keyed by department at the point of sale, as a percentage of the total data capture time.'
COMMENT ON COLUMN TLOG.TR_RTL.FL_SPN IS 'A flag denoting that the transaction is suspended, and may be resumed and completed at some time in the near future.'
CREATE INDEX XIF1219TR_RTL ON TLOG.TR_RTL (ID_CT                          ASC)

-- CREATE INDEX XIF125POINT_OF_SAL ON TLOG.TR_RTL
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_RTL ADD PRIMARY KEY (LOOKUP1_ID)


--------------------------------------------------------
-- TABLE TLOG.TR_SHP_RTL
--------------------------------------------------------
DROP TABLE TLOG.TR_SHP_RTL

CREATE TABLE TLOG.TR_SHP_RTL (ID_SHP_RTL_TRN       INTEGER NOT NULL, ID_CRR               INTEGER,ID_ADS               INTEGER, ID_PRTY              INTEGER, TY_RO_PRTY           CHAR(6), ID_TRCK_SHP          INTEGER, UR_URL_TRCK_SHP      VARCHAR(255), TY_LV_SV             CHAR(2), TS_DT_PRFC           DATE, MO_PYM_RQ            DECIMAL(8,3) DEFAULT 0, LU_PYM_MTH           CHAR(2),  NA_INST_SPL          CLOB)

COMMENT ON TABLE TLOG.TR_SHP_RTL IS 'The record of a shipment which was made to deliver the goods purchased in a particular RetailTransaction to the customer''s shipping address(es)'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.ID_SHP_RTL_TRN IS 'A unique, retailer supplied identifier for a RetailTransactionShipment.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.ID_CRR IS 'The carrier who does the actual shipping of the RetailTransactionShipment'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.ID_ADS IS 'A unique identifier for a location and mail address.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.ID_PRTY IS 'A unique, automatically assigned identity for a PARTY.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.TY_RO_PRTY IS 'A code that identifies a group of PARTY ROLES.  This is used for subtyping the PARTY ROLEs.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.ID_TRCK_SHP IS 'A tracking number provided by the service provider who actually delivers the shipment.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.UR_URL_TRCK_SHP IS 'A URL to the service provider''s website, which allows interested parties to track the shipment.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.TY_LV_SV IS 'A code denoting the level of delivery service that is being used to deliver this shipment'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.TS_DT_PRFC IS 'The preferred delivery date & time'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.MO_PYM_RQ IS 'How much is required to be paid for COD shipment?'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.LU_PYM_MTH IS 'A code denoting which payment method was used when paying for a COD shipment.'
COMMENT ON COLUMN TLOG.TR_SHP_RTL.NA_INST_SPL IS 'Narrative text, giving special delivery instructions.'
CREATE INDEX IF1741RetailTransa ON TLOG.TR_SHP_RTL(ID_ADS                         ASC,ID_PRTY                        ASC, TY_RO_PRTY                     ASC)

CREATE INDEX IF1931RetailTransa ON TLOG.TR_SHP_RTL( ID_CRR                         ASC)


ALTER TABLE TLOG.TR_SHP_RTL ADD PRIMARY KEY (ID_SHP_RTL_TRN)


--------------------------------------------------------
-- TABLE TLOG.TR_TND_AZN_RVS
--------------------------------------------------------
DROP TABLE TLOG.TR_TND_AZN_RVS

CREATE TABLE TLOG.TR_TND_AZN_RVS (LOOKUP1_ID BIGINT  NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_TND_AZN           SMALLINT NOT NULL, AI_RVS_TND_AZN       INTEGER NOT NULL, LU_ADJN              DECIMAL(14,3) DEFAULT 0,  TS_TM_DT             DATE, ID_RFC               INTEGER,  NA_HOS               VARCHAR(255))

COMMENT ON TABLE TLOG.TR_TND_AZN_RVS IS 'A request to an external agency to revers a previously requested authorization of the use of some form of tender to complete a RetailTransaction. Eg: Cheques, Credit & Debit Cards, Gift Certificates or Vouchers.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.AI_TND_AZN IS 'A unique sequence number for this TenderAuthorization. Required because a particular TenderLineItem may have more than one TenderAuthorization attempt.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.AI_RVS_TND_AZN IS 'A unique sequence number for this TenderAuthorizationReversal. Required because a particular TenderAuthorization may have more than one reversal attempt.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.AI_LN_ITM IS 'The sequence number of line item within the context of this RetailTransaction.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.LU_ADJN IS 'The adjudication code returned by the external agency for this TenderAuthorizationReversal'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.TS_TM_DT IS 'The date and time that this reversal was performed.'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.ID_RFC IS 'The identifying reference number for this reversal. (Usually assigned by the external agency that performs TenderAuthorizations).'
COMMENT ON COLUMN TLOG.TR_TND_AZN_RVS.NA_HOS IS 'Narrative text provided by the external agency for inclusion on any reciepts printed as a result of the TenderAuthorizationReversal'
CREATE INDEX IF1783TenderAuthor ON TLOG.TR_TND_AZN_RVS( AI_TND_AZN                     ASC,   AI_LN_ITM                      ASC,	LOOKUP1_ID			ASC)
-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_TND_AZN_RVS ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM, AI_TND_AZN, AI_RVS_TND_AZN  )


--------------------------------------------------------
-- TABLE TLOG.TR_TOT_RTL
--------------------------------------------------------
DROP TABLE TLOG.TR_TOT_RTL

CREATE TABLE TLOG.TR_TOT_RTL (	LOOKUP1_ID BIGINT  NOT NULL, TY_TRN_TOT           VARCHAR(20) NOT NULL, MO_TOT_RTL_TRN       DECIMAL(14,3) DEFAULT 0)

COMMENT ON TABLE TLOG.TR_TOT_RTL IS 'A monetary or unit count total for the RetailTransaction.  Ususally TotalTaxableAmount, TotalTaxCollected, TotalAmountPaid, TotalItemCount,  etc...'
COMMENT ON COLUMN TLOG.TR_TOT_RTL.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_TOT_RTL.TY_TRN_TOT IS 'A unique assigned mnemonic identifier that identifies the TransactionTotalType'
CREATE INDEX IF1826RetailTransa ON TLOG.TR_TOT_RTL(TY_TRN_TOT                     ASC)

CREATE INDEX IF1828RetailTransa ON TLOG.TR_TOT_RTL(	LOOKUP1_ID			ASC)
-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_TOT_RTL ADD PRIMARY KEY (LOOKUP1_ID, TY_TRN_TOT)


--------------------------------------------------------
-- TABLE TLOG.TR_TRN
--------------------------------------------------------
DROP TABLE TLOG.TR_TRN

CREATE TABLE TLOG.TR_TRN (LOOKUP1_ID BIGINT  NOT NULL, ID_OPR               INTEGER,TS_TM_SRT            TIMESTAMP, TY_TRN               CHAR(6), TS_TRN_BGN           TIMESTAMP, TS_TRN_END           TIMESTAMP, FL_CNCL              SMALLINT, FL_VD                SMALLINT, FL_TRG_TRN           SMALLINT, FL_KY_OFL            SMALLINT)

COMMENT ON TABLE TLOG.TR_TRN IS 'A record of business activity that involves a financial and/or merchandise unit exchange or the granting of access to conduct business at a specific device, at a specific point in time for a specific employee.'
COMMENT ON COLUMN TLOG.TR_TRN.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.TR_TRN.ID_OPR IS 'A unique, automatically assigned number used to identify a workstation OPERATOR.'
COMMENT ON COLUMN TLOG.TR_TRN.TS_TM_SRT IS 'The time and date at the start of the SESSION.'
COMMENT ON COLUMN TLOG.TR_TRN.TY_TRN IS 'A code to denote the type of TRANSACTION, eg CONTROL, FINANCIAL, and RETAIL.'
COMMENT ON COLUMN TLOG.TR_TRN.TS_TRN_BGN IS 'The time and date a transaction is initiated.'
COMMENT ON COLUMN TLOG.TR_TRN.TS_TRN_END IS 'The time and date stamp a transaction is completed.'
COMMENT ON COLUMN TLOG.TR_TRN.FL_CNCL IS 'A flag denoting that this entire transaction has been cancelled BEFORE it was completed at the POS. Various business rules may surround the setting of this flag, Eg: Perhaps all sub-ordinate RetailTransactionLineItems must have the VoidFlag set.'
COMMENT ON COLUMN TLOG.TR_TRN.FL_VD IS 'A flag denoting that this entire transaction has been voided (and reversed) after it was completed at the POS via a PostVoidTransaction. Various business rules may surround the setting of this flag. Eg: May only use PostVoid at the same POS as the voi'
COMMENT ON COLUMN TLOG.TR_TRN.FL_TRG_TRN IS 'A flag to signify whether the workstation is in training mode.'
COMMENT ON COLUMN TLOG.TR_TRN.FL_KY_OFL IS 'An indicator as to whether or not this transaction data was captured during a regular on-line POS session or was entered during an off-line period.'
-- D0001
-- CREATE INDEX XIF1053POINT_OF_SA ON TLOG.TR_TRN
-- (
--        ID_STR_RT                      ASC
-- )

-- D0001
-- CREATE INDEX XIF123POINT_OF_SAL ON TLOG.TR_TRN
-- (
--        ID_WS                          ASC,
--        ID_OPR                         ASC,
--        TS_TM_SRT                      ASC,
--       ID_STR_RT                      ASC
--)

-- D0001
-- CREATE INDEX XIF174POINT_OF_SAL ON TLOG.TR_TRN
-- (
--        ID_WS                          ASC,
--        ID_STR_RT                      ASC
-- )

CREATE INDEX XIF371POINT_OF_SAL ON TLOG.TR_TRN(TY_TRN                         ASC)

-- D0001
-- CREATE INDEX XIF576POINT_OF_SAL ON TLOG.TR_TRN
-- (
--        DC_DY_BSN                      ASC,
--        ID_STR_RT                      ASC
-- )


ALTER TABLE TLOG.TR_TRN ADD PRIMARY KEY (LOOKUP1_ID)


--------------------------------------------------------
-- TABLE TLOG.TR_VD_PST
--------------------------------------------------------
DROP TABLE TLOG.TR_VD_PST

CREATE TABLE TLOG.TR_VD_PST (LOOKUP1_ID BIGINT  NOT NULL, ID_WS_VD             INTEGER, DC_DY_BSN_VD         TIMESTAMP, AI_TRN_VD            INTEGER)

COMMENT ON TABLE TLOG.TR_VD_PST IS 'A non sales transaction that cancels a prior SALES/ RETURN TRANSACTION. The workstation will normally record each individual instance of this TRANSACTION by EMPLOYEE.'
COMMENT ON COLUMN TLOG.TR_VD_PST.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
-- COMMENT ON COLUMN TLOG.TR_VD_PST.ID_WS IS 'The unique identifier for the WORKSTATION, typically the serial number.'
-- COMMENT ON COLUMN TLOG.TR_VD_PST.DC_DY_BSN IS 'The calendar date of the BusinessDay.'
-- COMMENT ON COLUMN TLOG.TR_VD_PST.AI_TRN IS 'A unique, non-significant, automatically assigned sequential number used
-- to identify a TRANSACTION within the context of a WORKSTATION and a BUSINESS PERIOD.'
-- CREATE INDEX XIF108POST_VOID_TR ON TLOG.TR_VD_PST
-- (
--        ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )

-- CREATE INDEX XIF844POST_VOID_TR ON TLOG.TR_VD_PST
-- (
--       ID_WS                          ASC,
--       AI_TRN                         ASC,
--       DC_DY_BSN                      ASC,
--       ID_STR_RT                      ASC
-- )

-- CREATE INDEX XIF108POST_VOID_TR ON TLOG.TR_VD_PST
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- )


ALTER TABLE TLOG.TR_VD_PST ADD PRIMARY KEY (LOOKUP1_ID)


----------------------------------
-- Added tables for v1.0.4              a0001
----------------------------------

-- These tables were alterd with the new key...
--    TR_LTM_CHK_TND   **
--    TR_FDSV	**
--    TR_TRN	**
--    TR_TND_AZN_RVS	**
--    TR_RTL	**
--    CO_MDFR_TX_EXM	**
--    TR_LTM_DSC	* not in esql
--    CO_MDFR_RTL_PRC	**
--    TR_MDFR_SLS_TX_OVRD	**
--    TR_LTM_RTL_TRN_OVR	**
--    TR_TOT_RTL	**
--    CO_MDFR_CMN	**
--    TR_VD_PST	* not in esql
--    TR_LTM_SLS_RTN	**
--    TR_LTM_TND_CHN	**
--    CO_VLD_RST	**
--    TR_LTM_RTL_TRN	**
--    CO_MDFR_SRZ	**
--    TR_MDFR_SLS_TX_EXM	**
--    CO_MDFR_TX_OVRD	**
--    TR_LTM_CPN_TND	**
--    TR_LTM_SLS_RTN_TX	**
--    TR_LTM_TX	**
--    TR_LTM_TND	**
--    TR_LTM_GF_CF	**
--    TR_LTM_PYAN	**
--    TR_LTM_CRDB_CRD_TN	**
--    CO_AZN_TND	* not in esql
--     CA_DY_BSN

--------------------------------------------------------
-- TABLE TLOG.LOOKUP1
--------------------------------------------------------

DROP TABLE TLOG.LOOKUP1

CREATE TABLE TLOG.LOOKUP1 ( LOOKUP1_ID BIGINT  NOT NULL  GENERATED ALWAYS AS IDENTITY (START WITH 0, INCREMENT BY 1, NO CACHE ) , AI_TRN INTEGER  NOT NULL , ID_STR_RT INTEGER  NOT NULL , ID_WS INTEGER  NOT NULL , DC_DY_BSN TIMESTAMP  NOT NULL  , CONSTRAINT CC1107359436730 PRIMARY KEY ( AI_TRN, ID_STR_RT, ID_WS, DC_DY_BSN))
--	CONSTRAINT CC1107193377078 PRIMARY KEY ( LOOKUP1_ID)

COMMENT ON TABLE TLOG.LOOKUP1 IS 'Lookup table for TLOGARTS normalization.'
COMMENT ON COLUMN TLOG.LOOKUP1.LOOKUP1_ID IS 'Lookup ID for TLOG implementation.'
COMMENT ON COLUMN TLOG.LOOKUP1.ID_STR_RT IS 'A unique retailer assigned identifier for a RetailStore'
COMMENT ON COLUMN TLOG.LOOKUP1.ID_WS IS 'The unique identifier for the WORKSTATION, typically the serial number.'
COMMENT ON COLUMN TLOG.LOOKUP1.DC_DY_BSN IS 'The calendar date of the BusinessDay.'
COMMENT ON COLUMN TLOG.LOOKUP1.AI_TRN IS 'A unique, non-significant, automatically assigned sequential number used to identify a TRANSACTION within the context of a WORKSTATION and a BUSINESS PERIOD.'


--------------------------------------------------------
-- TABLE TLOG.CA_DY_BSN
--------------------------------------------------------
DROP TABLE TLOG.CA_DY_BSN

CREATE TABLE TLOG.CA_DY_BSN ( DC_DY_BSN 	TIMESTAMP  	NOT NULL,	ID_STR_RT 	INTEGER		NOT NULL, ID_WS 		INTEGER, AI_TRN 		INTEGER, TS_BGN		TIMESTAMP	NOT NULL, TS_END		TIMESTAMP	NOT NULL)

COMMENT ON TABLE TLOG.CA_DY_BSN IS 'A calendar date that corresponds to an accounting period fiscal day at a particular RetailStore, has financial transactions attributed to it and is aggregated using the CalendarPeriod structure.'
COMMENT ON COLUMN TLOG.CA_DY_BSN.ID_STR_RT IS 'A unique retailer assigned identifier for a RetailStore'
COMMENT ON COLUMN TLOG.CA_DY_BSN.ID_WS IS 'The unique identifier for the WORKSTATION, typically the serial number.'
COMMENT ON COLUMN TLOG.CA_DY_BSN.DC_DY_BSN IS 'The calendar date of the BusinessDay.'
COMMENT ON COLUMN TLOG.CA_DY_BSN.AI_TRN IS 'A unique, non-significant, automatically assigned sequential number used to identify a TRANSACTION within the context of a WORKSTATION and a BUSINESS PERIOD.'
COMMENT ON COLUMN TLOG.CA_DY_BSN.TS_BGN IS 'The date & time the BusinessDay begain at the nominated RetailStore - This is normally defined by the closure of the previous BusinessDay.'
COMMENT ON COLUMN TLOG.CA_DY_BSN.TS_END IS 'The date & time the BusinessDay ended at the nominated RetailStore.'

ALTER TABLE TLOG.CA_DY_BSN ADD PRIMARY KEY (DC_DY_BSN, ID_STR_RT)

--------------------------------------------------------
-- TABLE TLOG.PA_OPR
--------------------------------------------------------
DROP TABLE TLOG.PA_OPR

CREATE TABLE TLOG.PA_OPR (ID_STR_RT		INTEGER NOT NULL,ID_OPR			INTEGER NOT NULL,ID_EM			INTEGER,PW_ACS_OPR		VARCHAR(20))

COMMENT ON TABLE TLOG.PA_OPR IS 'An employee or any other authorized individual who may enter transactions into the stores workstations. The OPERATOR is accountable for the tender collected and dispensed while assigned to a WORKSTATION.'
COMMENT ON COLUMN TLOG.PA_OPR.ID_STR_RT IS 'A unique retailer assigned identifier for a RetailStore'
COMMENT ON COLUMN TLOG.PA_OPR.ID_OPR IS 'A unique, automatically assigned number used to identify a workstation OPERATOR.'
COMMENT ON COLUMN TLOG.PA_OPR.ID_EM IS 'A unique, non-significant number used to identify a store employee.'
COMMENT ON COLUMN TLOG.PA_OPR.PW_ACS_OPR IS 'A security password entered by an operator and used to verify his/her identity when signing on to a WORKSTATION.'

ALTER TABLE TLOG.PA_OPR  ADD PRIMARY KEY (ID_STR_RT, ID_OPR)

--------------------------------------------------------
-- TABLE TLOG.PA_STR_RTL
--------------------------------------------------------
DROP TABLE TLOG.PA_STR_RTL

CREATE TABLE TLOG.PA_STR_RTL (ID_STR_RT		INTEGER NOT NULL,ID_PRTY			INTEGER,TY_RO_PRTY		CHAR(6),ID_STRGP		INTEGER,DC_OPN_RT_STR		TIMESTAMP,DC_CL_RT_STR		TIMESTAMP,QU_SZ_STR		DECIMAL(9,2),QU_SZ_AR_SL		DECIMAL(9,2))

COMMENT ON TABLE TLOG.PA_STR_RTL IS 'An organization that sells merchandise and services through a physical location, catalog, web page or other channel.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.ID_STR_RT IS 'A unique retailer assigned identifier for a RetailStore'
COMMENT ON COLUMN TLOG.PA_STR_RTL.ID_PRTY IS 'A unique, automatically assigned identity for a PARTY.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.TY_RO_PRTY IS 'A code that identifies a group of PARTY ROLES. This is used for subtyping the PARTY ROLEs.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.ID_STRGP IS 'A unique system-assigned identifier for the RetailStoreGroup.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.DC_OPN_RT_STR IS 'The opening date for the RETAIL STORE.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.DC_CL_RT_STR IS 'The closing date for the RETAIL STORE.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.QU_SZ_STR IS 'The size of the RETAIL STORE. This is usually split by the non-sales and sales areas.'
COMMENT ON COLUMN TLOG.PA_STR_RTL.QU_SZ_AR_SL IS 'The size of the selling floor. in a large STORE this is further split by the sales floor and by the merchandise departments.'

ALTER TABLE TLOG.PA_STR_RTL ADD PRIMARY KEY (ID_STR_RT)

----------------------------------
-- END Added tables for v1.0.4              a0001
----------------------------------


--------------------------------------------------------
-- FOREIGN KEYS
--------------------------------------------------------


ALTER TABLE TLOG.CO_AZN_TND ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM, ID_AZN_PRE) REFERENCES CO_AZN_TND ON DELETE SET NULL


ALTER TABLE TLOG.CO_AZN_TND ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.CO_MDFR_CMN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_SLS_RTN ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.CO_MDFR_RTL_PRC ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT  ON UPDATE RESTRICT

ALTER TABLE TLOG.CO_MDFR_TX_EXM ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_TX ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.CO_MDFR_TX_OVRD ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_TX  ON DELETE RESTRICT  ON UPDATE RESTRICT


ALTER TABLE TLOG.CO_VLD_RST ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT  ON UPDATE RESTRICT


ALTER TABLE TLOG.CO_VLD_RST  ADD FOREIGN KEY (ID_QST_RST_VLD)  REFERENCES CO_VLD_RST_QST  ON DELETE SET NULL


ALTER TABLE TLOG.CO_MDFR_SRZ ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_FDSV ADD FOREIGN KEY (LOOKUP1_ID) REFERENCES TR_RTL ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_CHK_TND ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_TND  ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_CPN_TND ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE CASCADE


-- ALTER TABLE TLOG.TR_LTM_CPN_TND
--        ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)
--                              REFERENCES TR_LTM_SLS_RTN
--                              ON DELETE RESTRICT
--                              ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_LTM_CRDB_CRD_TN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE CASCADE

ALTER TABLE TLOG.TR_LTM_DSC ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_GF_CF ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_PYAN ADD FOREIGN KEY (LOOKUP1_ID,AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_RTL_TRN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM_VD) REFERENCES TR_LTM_RTL_TRN ON DELETE SET NULL


ALTER TABLE TLOG.TR_LTM_RTL_TRN ADD FOREIGN KEY (LOOKUP1_ID) REFERENCES TR_RTL  ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_LTM_RTL_TRN_OVR ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_LTM_SLS_RTN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_SLS_RTN ADD FOREIGN KEY (ID_ITM) REFERENCES AS_ITM ON DELETE SET NULL


ALTER TABLE TLOG.TR_LTM_SLS_RTN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM_ORG)  REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE
-- ID_STR_RT must be cascade                             ON DELETE SET NULL


ALTER TABLE TLOG.TR_LTM_SLS_RTN_TX ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_SLS_RTN ON DELETE RESTRICT ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_LTM_TND ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE RESTRICT
-- ID_STR_RT must not be cascade                             ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_TND_CHN ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE


ALTER TABLE TLOG.TR_LTM_TX ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE


ALTER TABLE TLOG.TR_MDFR_SLS_TX_EXM ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM, ID_ATHY_TX, ID_GP_TX)  REFERENCES TR_LTM_SLS_RTN_TX  ON DELETE RESTRICT  ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_MDFR_SLS_TX_OVRD ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM, ID_ATHY_TX, ID_GP_TX) REFERENCES TR_LTM_SLS_RTN_TX ON DELETE RESTRICT ON UPDATE RESTRICT

ALTER TABLE TLOG.TR_RTL ADD FOREIGN KEY (LOOKUP1_ID) REFERENCES TR_TRN ON DELETE CASCADE


ALTER TABLE TLOG.TR_TND_AZN_RVS ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM, AI_TND_AZN) REFERENCES CO_AZN_TND  ON DELETE RESTRICT  ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_TOT_RTL ADD FOREIGN KEY (LOOKUP1_ID)  REFERENCES TR_RTL  ON DELETE RESTRICT  ON UPDATE RESTRICT


-- d0001
-- ALTER TABLE TLOG.TR_TRN
--        ADD FOREIGN KEY (ID_STR_RT, ID_WS)
--                              REFERENCES AS_WS
--                              ON DELETE RESTRICT
--                              ON UPDATE RESTRICT


ALTER TABLE TLOG.TR_VD_PST  ADD FOREIGN KEY (LOOKUP1_ID)  REFERENCES TR_TRN ON DELETE RESTRICT
-- ID_STR_RT cannot be null                             ON DELETE SET NULL

--	a0001
ALTER TABLE TLOG.PA_OPR  ADD FOREIGN KEY (ID_STR_RT)   REFERENCES PA_STR_RTL ON DELETE RESTRICT ON UPDATE RESTRICT

ALTER TABLE TLOG.CA_DY_BSN ADD FOREIGN KEY (ID_STR_RT)  REFERENCES PA_STR_RTL ON DELETE RESTRICT ON UPDATE RESTRICT


--ALTER TABLE TLOG.CA_DY_BSN
--       ADD FOREIGN KEY (ID_STR_RT, ID_WS)
--                             REFERENCES AS_WS
--                             ON DELETE RESTRICT
--                             ON UPDATE RESTRICT
--	end a0001

-- CONNECT RESET
-- TERMINATE

--------------------------------------------------------
-- PREPOPULATE STORE ID AND OPR ID TABLES IN DATABASE TLOGARTS
--------------------------------------------------------

INSERT INTO TLOG.PA_STR_RTL(ID_STR_RT) VALUES(123)

Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 222)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 1)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 206)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 2)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 49)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 17)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 204)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 116)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 13)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 20)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 30)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 58)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 42)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 205)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 92)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 101)
Insert INTO TLOG.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 1000)