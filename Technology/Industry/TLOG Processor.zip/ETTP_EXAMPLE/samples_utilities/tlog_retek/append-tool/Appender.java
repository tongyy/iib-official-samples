/* Licensed Materials - Property of IBM
 * (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

import javax.jms.*;

import com.ibm.mq.*;
import com.ibm.mq.jms.*;


public class Appender
{
	public final static String ENCODING = System.getProperty("encoding", "ASCII");

	private int trickleNumber = 0;
	private File outputDirectory;


	public static void main(String[] args)
	{
		new Appender(args);
	}


	public Appender(String[] args)
	{
		try
		{
			if (args.length != 3 && args.length != 4)
			{
				System.err.println(" Startup usage: java " + getClass().getName() +
					" queue-manager input-queue output-directory [trickle-number]");
				System.err.println("Shutdown usage: java " + getClass().getName() +
					" queue-manager input-queue --shutdown");
				System.exit(1);
			}

			String queueManagerName = args[0];
			String queueName = args[1];
			String s = args[2];
			boolean shutdown = false;

			if (args.length == 3)
			{
				if (s.equals("--shutdown") || s.equals("-shutdown")) shutdown = true;
				else outputDirectory = new File(s);
			}
			else trickleNumber = Integer.parseInt(args[3]);

			// ---------------------------------------------------------

			MQQueueConnectionFactory factory = new MQQueueConnectionFactory();
			factory.setQueueManager(queueManagerName);
			
			QueueConnection connection = factory.createQueueConnection();
			connection.start();
			
			QueueSession session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			
			com.ibm.mq.jms.MQQueue ioQueue = (com.ibm.mq.jms.MQQueue)session.createQueue(queueName);
			
			if (shutdown)
			{
				QueueSender queueSender = session.createSender(ioQueue);
				
				TextMessage shutdownMsg = session.createTextMessage();
				queueSender.send(shutdownMsg);
				queueSender.close();

			}
			else
			{
				QueueReceiver queueReceiver = session.createReceiver(ioQueue); 
				
				while (true) {
					Message inMessage = queueReceiver.receive(0);

					if (inMessage != null) {
						String storeId = inMessage.getStringProperty("ETTPStore");
						if (storeId != null) {
//							System.out.println("Processing message for storeid [" + storeId + "]");
							if (inMessage instanceof TextMessage) {
								writeMessage(storeId, getContents((TextMessage)inMessage));			
							}
						} else {
							System.out.println("Received shutdown message, closing files and exiting.");
							closeWriters();
							break;
						}
						
					}
				}
				queueReceiver.close();
			}

			session.close();
			connection.close();
		}
		catch (Throwable e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}


	private String getStoreId(byte[] correlationId) throws UnsupportedEncodingException
	{
		int i = 0;

		while (i < correlationId.length && correlationId[i] != 0) i++;

		String s = new String(correlationId, 0, i, ENCODING);

		return s.length() == 0 ? null : s;
	}


	// -----------------------------------------------------------------


	private static class Store
	{
		private Writer stream;
		private int lineId;
		private int tranRecCounter;

		public Store(Writer stream)
		{
			this.stream = stream;
			lineId = 1;
			tranRecCounter = 0;
		}

		public Writer getWriter() { return stream; }

		public int incrementLineId() { return lineId++; }

		public void incrementTranRecCounter(String s)
		{
			int i = 0;

			while (i < s.length() && s.charAt(i) == '0') i++;

			// count is the number of records excluding THEAD and TTAIL
			// records.
			// tranRecCounter is total number of records including THEAD
			// and TTAIL hence the 2.

			int count = 2;

			if (i < s.length()) {
				count += Integer.parseInt(s.substring(i));
			}

			tranRecCounter += count;
		}

		public int getTranRecCounter() { return tranRecCounter; }
	}


	private HashMap storeMap = new HashMap();


	private void writeMessage(String storeId, BufferedReader reader) throws IOException
	{
		Store store = (Store)storeMap.get(storeId);

		if (store == null)
		{
			StringBuffer name = new StringBuffer("RTLOG_");

			name.append(storeId);
			name.append('_');

			Date now = new Date();
			String dateTime = FILENAME_DATE_FORMATTER.format(now);

			name.append(dateTime);
			name.append('_');
			name.append(trickleNumber);

			File file = new File(outputDirectory, name.toString());

			store = new Store(new BufferedWriter(new FileWriter(file)));

			storeMap.put(storeId, store);

			writeHead(storeId, store, now);
		}

		String line;

		while ((line = reader.readLine()) != null)
		{
			String description = line.substring(0, 5);
			line = line.substring(15);

			Writer writer = store.getWriter();

			System.out.println("Description: " + description + ", Line = " + line);
			writer.write(description);
			writer.write(zeroPad(store.incrementLineId()));
			writer.write(line);
			writer.write(LINE_FEED);

			if (description.equals("TTAIL")) {
				store.incrementTranRecCounter(line);
			}
		}
	}


	private void closeWriters() throws IOException
	{
		Iterator iterator = storeMap.values().iterator();

		while (iterator.hasNext())
		{
			Store store = (Store)iterator.next();

			writeTail(store);

			store.getWriter().flush();
			store.getWriter().close();
		}
	}


	private final static String FORMAT_STRING = System.getProperty("date.format", "yyyyMMddHHmmss");
	private final static SimpleDateFormat FILENAME_DATE_FORMATTER =
		new SimpleDateFormat(FORMAT_STRING);
	private final static SimpleDateFormat FHEAD_DATE_FORMATTER =
		new SimpleDateFormat("yyyyMMddHHmmss");
	private final static SimpleDateFormat BUSINESS_DATE =
		new SimpleDateFormat("yyyyMMdd");
	private final static String FHEAD = "FHEAD";
	private final static String FTAIL = "FTAIL";
	private final static String RTLG = "RTLG";
	private final static String REF_NUMBER;
	private final static char LINE_FEED = '\n';

	static
	{
		// Currently field ref_number is always filled out with spaces.
		char[] buffer = new char[30];
		for (int i = 0; i < buffer.length; i++) buffer[i] = ' ';
		REF_NUMBER = new String(buffer);
	}


	// Sample data for FHEAD:
	//
	//  12345+1234567890+1234+YYYYMMDDHHMMSS+YYYYMMDD+1234+123456789012345678901234567890
	//  FHEAD+0000000001+RTLG+20011119221921+20011024+10  +                              \n
	//
	// Note: documentation states location is a 10 character field however
	// sample data seems to show that it's really a 4 character field.

	// Sample data for FTAIL:
	//
	// 12345+1234567890+1234567890
	// FTAIL+0000000284+0000000282\n
	//

	// Note: in the sample data the fields location and ref_number take
	// up 34 characters whereas in the document "WBI for Retail TLOG
	// Processor: Retek Feature - HLD Specification" location is given
	// as a 10 character field and ref_number is given is as a 30
	// character field, i.e. the two together should take up 40
	// characters. In the function writeHead() below they are written
	// out according to the lengths described in this document.

	private void writeHead(String storeId, Store store, Date now) throws IOException
	{
		Writer stream = store.getWriter();

		stream.write(FHEAD);
		stream.write(zeroPad(store.incrementLineId()));
		stream.write(RTLG);

		stream.write(FHEAD_DATE_FORMATTER.format(now));
		stream.write(BUSINESS_DATE.format(now));
		stream.write(spacePad(storeId));
		stream.write(REF_NUMBER);
		stream.write(LINE_FEED);
	}


	private void writeTail(Store store) throws IOException
	{
		Writer stream = store.getWriter();

		stream.write(FTAIL);
		stream.write(zeroPad(store.incrementLineId()));
		stream.write(zeroPad(store.getTranRecCounter()));
		stream.write(LINE_FEED);
	}


	private String zeroPad(int value)
	{
		String s = Integer.toString(value);
		String pad = "0000000000";

		return pad.substring(0, (pad.length() - s.length())) + s;
	}


	private String spacePad(String s)
	{
		String pad = "          ";

		return s + pad.substring(0, (pad.length() - s.length()));
	}


	// -----------------------------------------------------------------


	private final static MQGetMessageOptions GET_OPTIONS = new MQGetMessageOptions();


	static
	{
		GET_OPTIONS.options |= MQC.MQGMO_WAIT;
		GET_OPTIONS.waitInterval = MQC.MQWI_UNLIMITED;
	}

	private static BufferedReader getContents(TextMessage message) throws JMSException
	{
		BufferedReader reader = new BufferedReader(new StringReader(message.getText()));

		return reader;
	}


	private static BufferedReader getContents(MQMessage message) throws IOException
	{
		int length = message.getTotalMessageLength();
		String s = message.readString(length); // Assumes single byte codepage.
		BufferedReader reader = new BufferedReader(new StringReader(s));

		return reader;
	}
}
