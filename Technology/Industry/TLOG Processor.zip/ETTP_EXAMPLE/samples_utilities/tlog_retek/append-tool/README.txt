Licensed Materials - Property of IBM
5724-C12
(C) Copyright IBM Corporation 2003. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.

------------------------------------------------------------------------

This tool, called Appender, is implemented in 'Appender.java'.

The Appender tool can be built using the 'build.cmd' command file.
The resulting class files are created in the 'lib' subdirectory.

The Appender tool can be run using the 'run.cmd' command file.

Note: Both command files reference the MQSeries classes for Java so
it may be necessary to update the path specified.

During a single run of the Appender tool it will generate individual
files for each store for which it receives at least one message. The
names of these files are of the form:

  RTLOG_<STORE_ID>_<CREATE_DATETIME>_<TRICKLE_NUMBER>

[ This form is described in revision 3 of the document 'Enterprise
  Trickle TLOG Processor - Design of WMQI based Components' ]

The format used for the create date component of the name is
'yyyyMMddHHmmss' (the meaning of this format string and how to construct
different ones is covered in the documentation for the Java class
'java.text.SimpleDateFormat'). To use an alternative format a system
property 'date.format' can added to the run.cmd before running the tool:

  java -classpath "%MQ_CLASSPATH%;lib" -Ddate.format=yyyyMMdd ...

The Appender tool takes the following startup arguments:

  run.cmd queue-manager input-queue output-directory [trickle-number]

The 'output-directory' specifies the directory in which the files of the
above form will be placed. The 'trickle-number' will be used as the
final component in the file names generated (if it is not specified 0 is
used.

The Appender tool takes the following shutdown arguments:

  run.cmd queue-manager input-queue --shutdown

This will cause a currently running instance of the Appender tool
listening on the given queue to write tail records to all the files it
has open, close them and then exit.

Note: the Appender tool uses buffered output so while running the files
it generates will not necessarily contain all data received so far, it
is only when instructed to shutdown that the tool will fully flush its
output streams and close them.

The Appender tool expects the store identifier to be provided in the usr
section of the RFH2 header as the property ETTPStore.  An example of 
setting this string property is in the ETTP_RETEK message flow.
------------------------------------------------------------------------