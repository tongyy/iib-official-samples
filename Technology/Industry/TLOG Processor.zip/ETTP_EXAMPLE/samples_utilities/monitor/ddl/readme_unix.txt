------------------------------------------------------------------
Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
-----------------------------------------------------------------

TLOGMON install on UNIX

DB2 installed to /usr/opt/db2_08_01

Database name:  	TLOGMON
Database schema:	TLOG


To create the TLOGMON database and associated tables:

1. Copy the files to the /tmp directory
2. From a command line window, run setuptlogmondb_aix.sh / setuptlogmondb_linux.sh.
3. Check the log files in the current directory:
	tlog_mon_database.log	Log file for and tables creation.
	

AIX DB2 issue:
--------------
On AIX, DB2 allows only 10 connections from a single process when connected
directly. If more that 10 connections are attempted, the connections will fail
and connection errors, such as SQL1224N, are reported in the system log.  To
avoid this problem when connecting to the Monitor database, please see 

http://www-1.ibm.com/support/docview.wss?uid=swg21079674

for instructions on either increasing shared memory segments and/or avoiding 
the use of shared memory with DB2 on AIX.
