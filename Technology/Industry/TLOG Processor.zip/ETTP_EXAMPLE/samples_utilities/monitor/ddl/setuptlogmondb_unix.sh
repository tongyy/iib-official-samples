#!/bin/sh

# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.


#make ddl script files readable by all
chmod 644 ./setupMonitorDB.ddl

#create TLOGMONDB database and tables ...
echo Creating TLOGMONDB database and tables ... ./tlogmon_database.log
db2 -vf setupMonitorDB.ddl > ./tlogmon_database.log

echo TLOGMON database and tables creation commands have been executed.  
echo Check the logfiles located in the installation directory for the execution status.



