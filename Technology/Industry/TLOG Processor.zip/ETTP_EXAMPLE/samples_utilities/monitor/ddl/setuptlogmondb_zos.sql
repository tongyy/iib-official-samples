-- Database Name: TLOGMON         

-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
-- US Government Users Restricted Rights- Use, duplication or
--disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.


--------------------------------------------------------
-- CREATE DATABASE TLOGMON
--------------------------------------------------------

-- DROP DATABASE TLOGMON;
 SET CURRENT SQLID='JM63USR';  

 CREATE DATABASE TLOGMON STOGROUP TLOGARTSSTOR;

 CREATE TABLESPACE TLOG6 IN TLOGMON USING STOGROUP   
 TLOGARTSSTOR                                        
 PRIQTY     120                                      
 SECQTY     40                                       
 ERASE NO                                            
 BUFFERPOOL BP0                                      
 LOCKSIZE ANY;                                       
                                                      



 
--------------------------------------------------------
-- TABLE JM63USR.MESSAGE
--------------------------------------------------------


CREATE TABLE MESSAGE (MESSAGE_ID         CHAR(24)            
FOR BIT DATA                                                 
NOT NULL, MIME_SEQUENCE_NUMBER VARCHAR(3) NOT NULL,          
CORREL_ID CHAR(24) FOR BIT DATA, STORE_NAME VARCHAR(50),     
STORE_NUMBER  VARCHAR(50), INPUT_MSG_TRANS_TYPE VARCHAR(75), 
PUT_TIMESTAMP TIMESTAMP, SOURCE_QUEUE VARCHAR(75),           
DESTINATION_QUEUE VARCHAR(75)) IN TLOGMON.TLOG6;             
CREATE UNIQUE INDEX ITEM21                                   
ON MESSAGE (MESSAGE_ID  ASC)                                 
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;                                                            
                                                                                              

--------------------------------------------------------
-- TABLE JM63USR.STORE_DAY
--------------------------------------------------------


CREATE TABLE STORE_DAY (STORE_NAME VARCHAR(50)            
NOT NULL, STORE_NUMBER VARCHAR(50) NOT NULL, DATA_DATE    
DATE NOT NULL, TIME_STORE_CLOSE TIME, TIME_LAST_MSG_RECVD 
TIMESTAMP, POSLOGXML_MSGCOUNT INTEGER, TOTAL_SALES_AMOUNT 
DECIMAL(14,2) DEFAULT 0) IN TLOGMON.TLOG6;                
CREATE UNIQUE INDEX ITEM22                                
ON STORE_DAY (STORE_NAME, STORE_NUMBER, DATA_DATE ASC)    
USING STOGROUP TLOGARTSSTOR                               
PRIQTY 7200                                               
SECQTY 720                                                
CLUSTER                                                   
BUFFERPOOL BP2                                            
CLOSE NO                                                  
;                                                         

--------------------------------------------------------
-- TABLE JM63USR.STORE_HOUR
--------------------------------------------------------


CREATE TABLE STORE_HOUR (STORE_NAME VARCHAR(50)                 
NOT NULL, STORE_NUMBER VARCHAR(50) NOT NULL, SAMPLE_DATE        
DATE NOT NULL, SAMPLE_HOUR  INTEGER NOT NULL,                   
SUM_HOUR_TRANS_MINUTES DECIMAL(14,2) DEFAULT 0,                 
SUM_HOUR_TRANS_MINUTES_SQRD DECIMAL(14,2)                       
DEFAULT 0, SUM_HOUR_REVENUE DECIMAL(14,2) DEFAULT 0,            
SUM_HOUR_REVENUE_SQRD DECIMAL(14,2) DEFAULT 0, SUM_DAY_REVENUE  
DECIMAL(14,2)  DEFAULT 0, SUM_HOUR_TIME_REVENUE DECIMAL(14,2)   
DEFAULT 0,                                                      
SUM_DAY_TRANS_COUNT INTEGER, SUM_HOUR_SAMPLE_COUNT INTEGER      
) IN TLOGMON.TLOG6;                                             

 CREATE UNIQUE INDEX ITEM23                                 
 ON STORE_HOUR (STORE_NAME, STORE_NUMBER, SAMPLE_DATE,      
 SAMPLE_HOUR ASC)                                           
 USING STOGROUP TLOGARTSSTOR                                
 PRIQTY 7200                                                
 SECQTY 720                                                 
 CLUSTER                                                    
 BUFFERPOOL BP2                                             
 CLOSE NO                                                   
 ;                                                                                    

--------------------------------------------------------
-- TABLE JM63USR.STORE_SCRATCH
--------------------------------------------------------


CREATE TABLE STORE_SCRATCH (STORE_NAME VARCHAR(50),  
STORE_NUMBER                                         
VARCHAR(50), LAST_SAMPLE_DATE DATE, LAST_SAMPLE_TIME 
TIME, SUM_DAY_REVENUE DECIMAL(14,2) DEFAULT 0,       
SUM_DAY_TRANS_COUNT INTEGER) IN TLOGMON.TLOG6;       
CREATE UNIQUE INDEX ITEM24                           
ON STORE_SCRATCH (STORE_NAME ASC)                    
USING STOGROUP TLOGARTSSTOR                          
PRIQTY 7200                                          
SECQTY 720                                           
CLUSTER                                              
BUFFERPOOL BP2                                       
CLOSE NO                                             
;                                                    


-- CONNECT RESET;
-- TERMINATE;