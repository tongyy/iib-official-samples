------------------------------------------------------------------
Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
-----------------------------------------------------------------

Utilities to test and plot analytics have been provided.
All files are provided within the analytics_plotter
directory.  Included in this directory are the three batch/shell files
discussed below, code for building the plot file (in
com\ibm\etr\analytics\queries), and an empty directory called
analytics_output in which is placed the generated plot files (step 2 below).

Running these utilities is a two step process.



1.  Run the script file build_model_sql.bat to retrieve records from the
STORE_HOUR table (recall that this is the table that records cumulative
data by store, by day, by hour).  Records are retrieved to file
analytics_export.csv.  If you have DB2 running on AIX
you should use build_model_sql.sh on AIX, then move the generated file,
analytics_export.csv, back to windows.

2.  Create directory "analytics_output" under <ETTP_EXAMPLE(_V1)>\samples_utilities\monitor\analytics_plotter\. Add "<ETTP_EXAMPLE(_V1)>\samples_utilities\monitor\analytics_plotter\com\ibm\etr\analytics\queries" to the PATH variable.
Run the script file build_model.bat to build a comma delimited
file of data points for the least squares model.  The program generates
one file per store and, for each day for which there is a record for that
store, a pair of data points (time, revenue) for each hour of the day
(a point at the beginning of the hour and one at the end, to determine the
regression line for that hour) over the course of the day. These data points
can easily be (scatter) plotted with any spreadsheet application.  The
output files are placed in directory analytics_output.


