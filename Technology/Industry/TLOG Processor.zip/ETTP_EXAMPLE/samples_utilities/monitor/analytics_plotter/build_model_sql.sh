#!/bin/sh

#   Licensed Materials - Property of IBM
#   (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
#   US Government Users Restricted Rights- Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.

db2 connect to TLOGMDB

db2 EXPORT TO analytics_test_export.csv OF DEL MESSAGES analytics_test_exporterror.csv SELECT STORE_NAME CONCAT STORE_NUMBER,SAMPLE_DATE,SAMPLE_HOUR,SUM_HOUR_TRANS_MINUTES,SUM_HOUR_TRANS_MINUTES_SQRD,SUM_HOUR_REVENUE,SUM_HOUR_REVENUE_SQRD,SUM_DAY_REVENUE,SUM_HOUR_TIME_REVENUE,SUM_DAY_TRANS_COUNT,SUM_HOUR_SAMPLE_COUNT FROM  TLOG.STORE_HOUR
