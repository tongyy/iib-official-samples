#!/bin/sh

# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.

# This demo script is used to show one way to clear the ARTS database used with 
# TLOG Processor.  The user accepts all responsibility for its use.  As always, 
# be sure all permanent data is backed up prior to deleting the contents 
# of any database.

db2 -vf ClearTLOG_ARTSTables.ddl


