#!/bin/sh

# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2003, 2005. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.


#make ddl script files readable by all
chmod 644 ./prepopulatetlogartstbls.ddl

echo Prepopulating TLOGARTSDB PA_STR_RTL and PA_OPR tables ... /tlog_arts_prepop.log
db2 -vf prepopulatetlogartstbls.ddl > ./tlog_arts_prepop.log

echo TLOGARTS prepopulation complete
echo Check the logfiles located in installation directory for the execution status.


