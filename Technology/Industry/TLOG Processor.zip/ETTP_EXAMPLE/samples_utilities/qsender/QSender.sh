java -classpath qsender.jar:$CLASSPATH com.ibm.wbi.utils.qsender.QSender -f ETTP_SAMPLE_ParmsFile.txt
