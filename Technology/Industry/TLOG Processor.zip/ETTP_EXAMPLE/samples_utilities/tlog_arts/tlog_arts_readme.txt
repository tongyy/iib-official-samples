=======================================================================
Licensed Materials - Property of IBM
5724-C12
(C) Copyright IBM Corporation 2003. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
=======================================================================

This readme details the known issues in the population of the ARTS data model.  These issues are due to omissions in the ARTS 4.01 data model or to the lack of sufficient mapping logic at the time of release.  Many of the data model omissions will be resolved in the next release of the ARTS data model v4.10.


The ARTS subflow uses a filter node to filter out any messages which do not have sufficient data to populate the ARTS data model.

The population of the Person, StandardizedDomesticAddress and Telephone entities had insufficient mapping details at the time of release.  The stub ESQL procedures UpdatePersonEntity, UpdateAddressEntity and UpdateTelephoneEntity should be implemented to populate these entities.

RetailTransactionLineItemSequenceNumber (attribute AI_LN_ITM) is derived from the POSLog element /Transaction/LineItem.SequenceNumber.  The ARTS 4.01 data model does not support duplicate LineItem sequence numbers so all duplicates are ignored in the population of the ARTS data model.

The Transaction RetailStoreID (attribute ID_STR_RT) is defined as an integer in the ARTS data model.  As the corresponding POSLog string element /Transaction/RetailStoreID contains alphanumeric data, the ESQL SUBSTRING function is used to extract the numeric portion of the string before inserting into the ARTS data model.  It is proposed to alter the ARTS model DDL to allow alphanumeric data in the next release.

The Transaction SessionStartDateTimestamp (entity TR_TRN, attribute TS_TM_SRT) is defined as NOT NULL in the ARTS data model.  As no mapping was defined for this field at the time of release, the NOT NULL was removed from the ARTS model DDL.

The RetailTransactionTotal TransactionTotalTypeCode (entity TR_TOT_RTL, 
attribute TY_TRN_TOT) is defined as length 20 in the ARTS data model.  However, the POSLog element, /Transaction/Total/TotalType, from which it is derived, can contain the values 'TransactionGrossAmount', 'TransactionNettAmount', 'TransactionTaxAmount', 'TransactionTaxExemptAmount' and 'TransactionGrandAmount'.  The ESQL SUBSTRING function is used to ensure that the inserted value does not exceed 20 characters in length.

The SaleReturnLineItem POSItemID and POSItemIDQualifier (entity TR_LTM_SLS_RTN, attributes ID_ITM_PS and ID_ITM_PS_QFR) are derived from the POSLog string element /Transaction/LineItem/Sale/POSIdentity. The data model attributes are defined as integer fields which are too small to hold the converted POSLog string.  This results in a truncation of these values in the population of the ARTS data model.  It is proposed to alter the ARTS model DDL to model these attributes as strings in the next release.

The SaleReturnLineItem ItemID (entity TR_LTM_SLS_RTN, attribute ID_ITM) is derived from the POSLog element /Transaction/LineItem/Sale/ItemID but the population of this attribute violates a foreign key constraint against the AS_ITM entity which is not populated.  This foreign key constraint should be removed to allow the population of this attribute.

The SaleReturnLineItem POSDepartmentID (entity TR_LTM_SLS_RTN, attribute ID_DPT_PS) is defined as an integer attribute which is derived from the POSLog string element /Transaction/LineItem/Sale/MerchandiseHierarchy.  As this string element is of the format 'Department/Class' the ESQL SUBSTRING function is used to extract up to the '/' character.  Also, note that as the POSLog MerchandiseHierarchy element is of the form:
<MerchandiseHierarchy Level="Department/Class">000000000348/34834812
</MerchandiseHierarchy>
the ESQL uses .*[2] to address the anonymous second element.

The SaleReturnLineItem POSDepartmentID (entity TR_LTM_SLS_RTN, attribute ID_ITM_PS) appears in the POSLog data with both '/' and ';' delimiter characters so the ESQL checks for both delimiter characters when deriving the department.

The CommissionModifier CommissionModifierSequenceNumber (entity CO_MDFR_CMN, attribute AI_MDFR_CMN) has no mapping defined from POSLog and so a sequence number is generated in the ESQL code.

The RetailPriceModifier ReasonCode (entity CO_MDFR_RTL_PRC, attribute RC_MDFR_RT_PRC) is defined as length 2 in the ARTS data model.  However, the POSLog element, /Transaction/LineItem/Sale/RetailPriceModifier/ReasonCode, from which it is derived, can contain the values 'Allowance' and 'Discount'.  The ESQL SUBSTRING function is used to ensure that the inserted value does not exceed 2 characters in length.

The SaleReturnTaxExemptionModifier ReasonCode (entity TR_MDFR_SLS_TX_EXM, attribute RC_EXM_TX) is defined as length 2 in the ARTS data model.  However, the POSLog element, /Transaction/LineItem/Sale/Tax/TaxExemption/ReasonCode, from which it is derived, can contain longer values.  The ESQL SUBSTRING function is used to ensure that the inserted value does not exceed 2 characters in length.

The RetailTransactionShipment entity (entity TR_SHP_RTL) had insufficient mapping details at time of release to allow this entity to be populated and so the ESQL insert statement (within the ESQL procedure UpdateRtlTxnShpEntity) is commented out of the code. It is proposed that the primary key attribute, RetailTransactionShipmentID, be generated in the next release.  Also, the RetailTransactionShipment PreferredDateTime (attribute TS_DT_PRFC) should be derived from both the POSLog PreferredDate and PreferredTime elements instead of just the PreferredDate.

The TaxExemptionModifier ReasonCode (entity CO_MDFR_TX_EXM, attribute RC_EXM_TX) is defined as length 2 in the ARTS data model.  However, the POSLog element, /Transaction/LineItem/Sale/Tax/TaxExemption/ReasonCode, from which it is derived, can contain longer values.  The ESQL SUBSTRING function is used to ensure that the inserted value does not exceed 2 characters in length.

The mappings for the TaxOverrideModifier TaxAuthorityID and TaxGroupID (entity CO_MDFR_TX_OVRD, attributes ID_ATHY_TX and ID_GP_TX) were not defined at the time of release.  It is proposed to populate these attributes in the next release.

The TenderAuthorizationReversal TenderAuthorizationSequenceNumber and TenderAuthorizationReversalSequenceNumber (entity TR_TND_AZN_RVS, attributes AI_TND_AZN and AI_RVS_TND_AZN) had insufficient mapping details at time of release to allow the entity to be populated and so the ESQL insert statement is commented out of the ESQL code. It is proposed that these primary key attributes be generated in the next release.

The CreditDebitCardTenderLineItem CardExpirationDate (entity TR_LTM_CRDB_CRD_TN, attribute DC_EP_CRD) is derived from the POSLog data element /Transaction/LineItem/Tender/CreditDebit/ExpirationDate.  The year portion of the date is extracted using the ESQL EXTRACT function.  The value inserted should in fact be the year and month portions of this date in the format MMYY.

The CouponTenderLineItem entity (entity TR_LTM_CPN_TND) is defined in the ARTS data model as having a foreign key constraint on SaleReturnLineItem (entity TR_LTM_SLS_RTN).  This foreign key constraint was removed from the ARTS model DDL as the SaleReturnLineItem is not always present.

The RestrictionValidationQuestion QuestionID (entity CO_VLD_RST_QST, attribute ID_QST_RST_VLD) had insufficient mapping details at time of release to allow this entity to be populated and so the ESQL insert statement is commented out of the ESQL code.

The RestrictionValidationModifier is defined in the ARTS data model as having a foreign key constraint on RestrictionValidationQuestion (which is not populated) and so the ESQL insert statement is commented out of the ESQL code.

The TaxAuthorityID attribute (attribute ID_ATHY_TX) is defined as an integer in the ARTS data model.  As the corresponding POSLog string element /Transaction/RetailStoreID contains alphanumeric data, it is proposed to alter the ARTS model DDL to allow alphanumeric data in the next release.

The CheckTenderLineItem CheckAccountNumber (entity TR_LTM_CHK_TND, attribute ID_ACNT_CHK) is defined as an integer in the ARTS data model.  The ARTS model DDL has been altered to allow spaces or hyphens as well as digits.

The CouponTenderLineItem ScanCode (entity TR_LTM_CPN_TND, attribute UC_CPN_SC) is defined as a string of length 15 in the ARTS data model.  Some POSLOg data was found to exceed this length so an ESQL substring function was added to avoid a string truncation error.

=======================================================================
END
=======================================================================


