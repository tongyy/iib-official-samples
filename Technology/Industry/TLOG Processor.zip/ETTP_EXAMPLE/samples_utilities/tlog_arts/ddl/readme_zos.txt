------------------------------------------------------------------
Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2007, 2008. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
-----------------------------------------------------------------

Database setup on z/OS

Database name:  TLOGARTS



To create the TLOGARTS database and associated tables:
1. Create the database storage group.
2. Create a Member (JCL) using the file runsetuptlogartsdb_zos.sql.
    
    > ftp hostname
    > cd 'argo.broker.sql'
    > put runsetuptlogartsdb_zos.sql TLOGARTS
    > Change the USERID of the database user in the TLOGARTS JCL.
    > Execute the JCL TLOGARTS to create database, tables and records.
    
 The above steps creates:
    > Create the database TLOGARTS with associated storage group.
    > Create the tablespace for the database and its associated storage group.

    
	