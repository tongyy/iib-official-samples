------------------------------------------------------------------
Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2003, 2004. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
-----------------------------------------------------------------

TLOGDB install on Windows

Database name:  	TLOGARTS
Database schema:	TLOG


To create the TLOGARTS database and associated tables:
1. From a DB2 command line window (db2cmd), run setuptlogartsdb_win.bat.
2. Check the log files created in the current directory.
	tlog_arts_database.log		Log file for database and tables creation.	
	