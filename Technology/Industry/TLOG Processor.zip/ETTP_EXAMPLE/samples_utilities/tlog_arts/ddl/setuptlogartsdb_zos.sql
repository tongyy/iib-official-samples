--------------------------------------------------------
-- CREATE DATABASE TLOGARTS
--------------------------------------------------------

-- DROP DATABASE TLOGARTS;

SET CURRENT SQLID='JM63USR';  
CREATE DATABASE TLOGARTS STOGROUP TLOGARTSSTOR;


SET CURRENT SQLID='JM63USR';  

 CREATE TABLESPACE TLOG6 IN TLOGARTS USING STOGROUP   
 TLOGARTSSTOR                                        
 PRIQTY     120                                      
 SECQTY     40                                       
 ERASE NO                                            
 BUFFERPOOL BP0                                      
 LOCKSIZE ANY;                                       

--------------------------------------------------------
-- TABLE AS_ITM
--------------------------------------------------------
--DROP TABLE AS_ITM;

CREATE TABLE AS_ITM (ID_ITM INTEGER NOT NULL, ID_ITM_SL_PRC
INTEGER, ID_RU_ITM_SL    INTEGER, ID_DPT_PS INTEGER, ID_LN_PRC 
INTEGER, ID_MRHRC_GP     INTEGER, NM_BRN           
VARCHAR(40), FL_AZN_FR_SLS SMALLINT, FL_ITM_DSC        
SMALLINT, FL_ADT_ITM_PRC       SMALLINT, LU_EXM_TX       
CHAR(2), LU_ITM_USG  CHAR(2), NM_ITM              
VARCHAR(40), DE_ITM               VARCHAR(255), TY_ITM   
CHAR(4), LU_KT_ST             CHAR(2), FL_ITM_SBST_IDN    
SMALLINT, LU_CLN_ORD   CHAR(2)) IN TLOGARTS.TLOG6;


CREATE UNIQUE INDEX IF1649Item ON AS_ITM (ID_DPT_PS  ASC, ID_ITM_SL_PRC ASC,ID_MRHRC_GP ASC, NM_BRN ASC, ID_LN_PRC ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;             






--------------------------------------------------------
-- TABLE AS_WS
--------------------------------------------------------
--DROP TABLE AS_WS;

CREATE TABLE AS_WS (ID_STR_RT  INTEGER NOT NULL, ID_WS 
INTEGER NOT NULL, ID_EQ INTEGER, NM_WS_MF VARCHAR(40),
NM_MDL_WS_TML        VARCHAR(40), SC_TML_WS         
CHAR(2), QU_TL_WS             DECIMAL(3,0) NOT NULL DEFAULT 0,
TY_WS CHAR(4), FL_MOD_TRG           SMALLINT, FL_WS_OTSD   
SMALLINT, NM_ADS_DVC           VARCHAR(40)) IN TLOGARTS.TLOG6;;

CREATE UNIQUE INDEX XIF1056POINT_OF_SA ON AS_WS (ID_STR_RT 
ASC, ID_EQ 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        




--------------------------------------------------------
-- TABLE CO_AZN_TND
--------------------------------------------------------
--DROP TABLE CO_AZN_TND;

CREATE TABLE CO_AZN_TND (LOOKUP1_ID INTEGER  NOT NULL, 
AI_LN_ITM            SMALLINT NOT NULL, AI_TND_AZN 
SMALLINT NOT NULL, ID_PRV               INTEGER, ID_AZN_PRE
SMALLINT,  MO_RQS               DECIMAL(8,3) DEFAULT 0,
MO_RQS_CHN           DECIMAL(8,3) DEFAULT 0, LU_ADJN_TND_AZN
VARCHAR(20), ID_RFC_TND_AZN       INTEGER, TS_TM_DT     
DATE, ID_RQS_TML           INTEGER, FL_HOS_AZN        
SMALLINT, BM_SGN               SMALLINT, NA_HOS     
VARCHAR(255), FL_CT_PRST           SMALLINT) IN TLOGARTS.TLOG6;

-- c0001
-- CREATE UNIQUE INDEX IF1782TenderAuthor ON CO_AZN_TND
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
CREATE UNIQUE INDEX IF1782TenderAuthor ON CO_AZN_TND (AI_LN_ITM
ASC, LOOKUP1_ID  ASC, ID_PRV ASC) 
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        




-------------------------------------------------------
-- TABLE CO_CNY
--------------------------------------------------------
--DROP TABLE CO_CNY;

CREATE TABLE CO_CNY (ID_CNY              
INTEGER NOT NULL, DE_CNY               VARCHAR(255), SY_CNY  
VARCHAR(40), LU_CNY_ISSG_CY       CHAR(4)) IN TLOGARTS.TLOG6;




--------------------------------------------------------
-- TABLE CO_MDFR_CMN
--------------------------------------------------------
--DROP TABLE CO_MDFR_CMN;

CREATE TABLE CO_MDFR_CMN (LOOKUP1_ID INTEGER 
NOT NULL, AI_LN_ITM 
SMALLINT NOT NULL, AI_MDFR_CMN  SMALLINT NOT NULL, ID_EM   
INTEGER, MO_MDFR_CMN          DECIMAL(14,3) NOT NULL DEFAULT 0,
PE_MDFR_CMN          DECIMAL(5,2) NOT NULL DEFAULT 0, FL_PE_CMN_AMT
VARCHAR(20), LU_ACTN_ASCTN        VARCHAR(20), TS_TM_DT     
DATE) IN TLOGARTS.TLOG6;

-- c0001
-- CREATE UNIQUE INDEX XIF593COMMISSION_M ON CO_MDFR_CMN
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
CREATE UNIQUE INDEX XIF593COMMISSION_M ON CO_MDFR_CMN(AI_LN_ITM 
ASC,LOOKUP1_ID                     ASC, ID_EM ASC)

USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


--------------------------------------------------------
-- TABLE CO_MDFR_RTL_PRC
--------------------------------------------------------
DROP TABLE CO_MDFR_RTL_PRC;

CREATE TABLE CO_MDFR_RTL_PRC (LOOKUP1_ID INTEGER 
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_MDFR_RT_PRC 
INTEGER NOT NULL, ID_EM                INTEGER, ID_PRM     
INTEGER, RC_MDFR_RT_PRC       CHAR(2), PE_MDFR_RT_PRC    
DECIMAL(5,2) NOT NULL DEFAULT 0, MO_MDFR_RT_PRC      
DECIMAL(14,3) NOT NULL DEFAULT 0, DP_LDG_STK_MDFR     
CHAR(4), MO_PRV_PRC           DECIMAL(8,3) DEFAULT 0, MO_NW_PRC 
DECIMAL(8,3) DEFAULT 0) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1526RetailPriceM ON CO_MDFR_RTL_PRC (ID_PRM 
ASC, ID_EM 
ASC, AI_LN_ITM
ASC,LOOKUP1_ID              ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        

  

-- C0001
-- CREATE UNIQUE INDEX XIF71RETAIL_PRICE_ ON CO_MDFR_RTL_PRC
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
 


--------------------------------------------------------
-- TABLE CO_MDFR_SRZ
--------------------------------------------------------
--DROP TABLE CO_MDFR_SRZ;

CREATE TABLE CO_MDFR_SRZ( LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM            SMALLINT NOT NULL, ID_ITM	       
INTEGER, ID_NMB_SRZ           VARCHAR(40), TY_SRZ	
CHAR(2)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF7LOOKUP ON CO_MDFR_SRZ(LOOKUP1_ID
ASC,AI_LN_ITM              ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        




--------------------------------------------------------
-- TABLE CO_MDFR_TX_EXM
--------------------------------------------------------
--DROP TABLE CO_MDFR_TX_EXM;

CREATE TABLE CO_MDFR_TX_EXM (LOOKUP1_ID INTEGER  NOT NULL, 
AI_LN_ITM            SMALLINT NOT NULL, MO_EXM_TXBL       
DECIMAL(8,3) DEFAULT 0, MO_EXM_TX            DECIMAL(14,3) 
NOT NULL DEFAULT 0, RC_EXM_TX            CHAR(2), ID_CF_TX_EXM 
INTEGER, NM_HLDR_TX_EXM_CF    VARCHAR(40)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF7CO_MDFR ON CO_MDFR_TX_EXM(LOOKUP1_ID
ASC,AI_LN_ITM              ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        

--------------------------------------------------------
-- TABLE MDFR_TX_OVRD
--------------------------------------------------------
--DROP TABLE CO_MDFR_TX_OVRD;

CREATE TABLE CO_MDFR_TX_OVRD ( LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM            SMALLINT NOT NULL, ID_ATHY_TX      
VARCHAR(40), ID_GP_TX             INTEGER, MO_TX_ORGL   
DECIMAL(8,3) DEFAULT 0, RC_TX_OVRD        
CHAR(2), ID_CF_TX_OVRD        INTEGER, NM_CF_HLDR  
VARCHAR(40)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1786TaxOverrideM ON CO_MDFR_TX_OVRD(ID_GP_TX 
ASC, ID_ATHY_TX          ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        



--------------------------------------------------------
-- TABLE CO_VLD_RST
--------------------------------------------------------
--DROP TABLE CO_VLD_RST;

CREATE TABLE CO_VLD_RST (LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM            SMALLINT NOT NULL, ID_QST_RST_VLD 
INTEGER, NA_ANS               VARCHAR(255)) IN TLOGARTS.TLOG6

CREATE UNIQUE INDEX IF1744RestrictionV ON CO_VLD_RST(ID_QST_RST_VLD 
ASC) 
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        



--ALTER TABLE CO_VLD_RST  ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE CO_VLD_RST_QST
--------------------------------------------------------
--DROP TABLE CO_VLD_RST_QST;

CREATE TABLE CO_VLD_RST_QST (ID_QST_RST_VLD 
INTEGER NOT NULL,NA_QST_RST_VLD   VARCHAR(255)) IN TLOGARTS.TLOG6;


--ALTER TABLE CO_VLD_RST_QST  ADD PRIMARY KEY (ID_QST_RST_VLD);



--------------------------------------------------------
-- TABLE LO_ADS_STD_DMS
--------------------------------------------------------
--DROP TABLE LO_ADS_STD_DMS;

CREATE TABLE LO_ADS_STD_DMS (ID_ADS    
INTEGER NOT NULL,A1_ADS               VARCHAR(40), A2_ADS     
VARCHAR(40), CI_CNCT              VARCHAR(30), ST_CNCT      
CHAR(2), PC_CNCT              VARCHAR(15) DEFAULT '')
IN TLOGARTS.TLOG6;
-- CREATE UNIQUE INDEX XIF1127STANDARDIZE ON LO_ADS_STD_DMS
-- (
--       ID_ADS                         ASC
-- );

-- CREATE UNIQUE INDEX XIF1127STANDARDIZE ON LO_ADS_STD_DMS
-- (
--        ID_ADS                         ASC
-- );


--ALTER TABLE LO_ADS_STD_DMS   ADD PRIMARY KEY (ID_ADS);


--------------------------------------------------------
-- TABLE LO_PH
--------------------------------------------------------
--DROP TABLE LO_PH;

CREATE TABLE LO_PH (ID_PRTY  
INTEGER NOT NULL, ID_PH_TYP            INTEGER NOT NULL, CC_PH
CHAR(3), TA_PH                CHAR(5), TL_PH   CHAR(8),
PH_EXTN              CHAR(5)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF1086TELEPHONE ON LO_PH(ID_PRTY    
ASC, ID_PH_TYP  
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        





--ALTER TABLE LO_PH ADD PRIMARY KEY (ID_PRTY, ID_PH_TYP);


--------------------------------------------------------
-- TABLE PA_PRS
--------------------------------------------------------
--DROP TABLE PA_PRS;

CREATE TABLE PA_PRS ( ID_PRTY_PRS     
INTEGER NOT NULL, NM_PRS_SLN           VARCHAR(40), FN_PRS  
VARCHAR(40) NOT NULL, TY_NM_FS             CHAR(2), MD_PRS   
VARCHAR(40), TY_NM_MID            CHAR(2), LN_PRS           
VARCHAR(40) NOT NULL, TY_NM_LS             CHAR(2), NM_PRS_SFX  
VARCHAR(40), TY_GND_PRS           CHAR(2), DC_PRS_BRT       
TIMESTAMP, NM_PRS_SR            VARCHAR(40), NM_PRS_ML    
VARCHAR(40), NM_PRS_OFCL          VARCHAR(40)) IN TLOGARTS.TLOG6;

-- CREATE UNIQUE INDEX XIF1105PERSON ON PA_PRS
-- (
--        ID_PRTY_PRS                    ASC
-- );


--ALTER TABLE PA_PRS  ADD PRIMARY KEY (ID_PRTY_PRS);



--------------------------------------------------------
-- TABLE TR_FDSV
--------------------------------------------------------
--DROP TABLE TR_FDSV;

CREATE TABLE TR_FDSV (LOOKUP1_ID INTEGER  NOT NULL, ID_SRV 
INTEGER, ID_TB                INTEGER, QU_SZ_PRTY         
DECIMAL(3,0) DEFAULT 0 ) IN TLOGARTS.TLOG6;

-- CREATE UNIQUE INDEX IF1750FoodServiceT ON TR_FDSV
-- (
--        ID_SRV                         ASC,
--        ID_STR_RT                      ASC
-- );

-- CREATE UNIQUE INDEX IF1752FoodServiceT ON TR_FDSV
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX IF1753FoodServiceT ON TR_FDSV
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );


--ALTER TABLE TR_FDSV ADD PRIMARY KEY (LOOKUP1_ID);


--------------------------------------------------------
-- TABLE TR_LTM_CHK_TND
--------------------------------------------------------
--DROP TABLE TR_LTM_CHK_TND;

CREATE TABLE TR_LTM_CHK_TND (LOOKUP1_ID          
INTEGER NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, ID_BK_CHK 
INTEGER, ID_ACNT_CHK          VARCHAR(20), LU_MTH_ACNT_ENR    
VARCHAR(20), AI_CHK               SMALLINT, LU_MTH_SQN_ENR    
VARCHAR(20), TY_ID_PRSL_RQ        CHAR(2), ID_PRSL_AZN        
INTEGER, ID_ADJN_CHK          CHAR(4), DC_BRT_CHK         
CHAR(2)) IN TLOGARTS.TLOG6;


-- CREATE UNIQUE INDEX XIF445TENDER_CHECK ON TR_LTM_CHK_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF445TENDER_CHECK ON TR_LTM_CHK_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_CHK_TND ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_CPN_TND
--------------------------------------------------------
--DROP TABLE TR_LTM_CPN_TND;

CREATE TABLE TR_LTM_CPN_TND (LOOKUP1_ID INTEGER  NOT NULL, AI_LN_ITM
SMALLINT NOT NULL, ID_MF                INTEGER,  FC_FMY_MF 
CHAR(3), AI_LN_ITM_VL         SMALLINT, UC_CPN_SC         
VARCHAR(15) DEFAULT '', DC_CPN_EP            VARCHAR(20), LU_CPN_PRM 
CHAR(6), FL_ENR_CPN_KY        SMALLINT) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF1018COUPON_LINE ON TR_LTM_CPN_TND( FC_FMY_MF
ASC,ID_MF                          ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF444COUPON_LINE_ ON TR_LTM_CPN_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF164COUPON_LINE_ ON TR_LTM_CPN_TND
-- (
--       AI_LN_ITM	                ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF444COUPON_LINE_ ON TR_LTM_CPN_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_CPN_TND ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_CRDB_CRD_TN
--------------------------------------------------------
--DROP TABLE TR_LTM_CRDB_CRD_TN;

CREATE TABLE TR_LTM_CRDB_CRD_TN (LOOKUP1_ID INTEGER 
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, TY_CRD 
CHAR(6), ID_ISSR_TND_MD       INTEGER, ID_ACNT_DB_CR_CRD
VARCHAR(40), LU_NMB_CRD_SWP_KY    CHAR(2), LU_SCR_ENR   
CHAR(2), TY_ID_PRSL_RQ        CHAR(2), ID_RFC_PRSL_ID   
INTEGER, LU_MTH_AZN           CHAR(4), DE_TRCK_1_BT_MP  
BLOB, DE_TRCK_2_BT_MP      BLOB, DE_TRCK_3_BT        
BLOB, LU_ADJN_CRDB         CHAR(6), CH_IM_TND_AZN_CT   
CHAR(2), DC_EP_CRD            CHAR(4), NM_CRD_HLD      
VARCHAR(40),AI_CRD_ISS           INTEGER) IN TLOGARTS.TLOG6;

-- CREATE UNIQUE INDEX XIF446CREDIT_DEBIT ON TR_LTM_CRDB_CRD_TN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF446CREDIT_DEBIT ON TR_LTM_CRDB_CRD_TN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_CRDB_CRD_TN ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_DSC
--------------------------------------------------------
--DROP TABLE TR_LTM_DSC;

CREATE TABLE TR_LTM_DSC (LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM            SMALLINT NOT NULL, TY_DSC            
CHAR(2), MO_DSC               DECIMAL(14,3) NOT NULL DEFAULT 0)
IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF153DISCOUNT_LIN ON TR_LTM_DSC(TY_DSC 
ASC, LOOKUP1_ID 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF85DISCOUNT_LINE ON TR_LTM_DSC
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- C0001
-- CREATE UNIQUE INDEX XIF85DISCOUNT_LINE ON TR_LTM_DSC
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );



--ALTER TABLE TR_LTM_DSC ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_GF_CF
--------------------------------------------------------
--DROP TABLE TR_LTM_GF_CF;

CREATE TABLE TR_LTM_GF_CF (LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM            SMALLINT NOT NULL, ID_STR_ISSG         
INTEGER,    ID_NMB_SRZ_GF_CF     VARCHAR(40) NOT NULL, 
LU_NMB_SRZ_SC_KY     CHAR(2)) IN TLOGARTS.TLOG6;

-- c0001
-- CREATE UNIQUE INDEX XIF128GIFT_CERTIFI ON TR_LTM_GF_CF
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
--);
CREATE UNIQUE INDEX XIF128GIFT_CERTIFI ON TR_LTM_GF_CF(LOOKUP1_ID
ASC, ID_STR_ISSG 
ASC, ID_NMB_SRZ_GF_CF               ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


  


-- CREATE UNIQUE INDEX XIF128GIFT_CERTIFI ON TR_LTM_GF_CF
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_GF_CF ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_PYAN
--------------------------------------------------------
--DROP TABLE TR_LTM_PYAN;

CREATE TABLE TR_LTM_PYAN (LOOKUP1_ID INTEGER  NOT NULL, 
AI_LN_ITM            SMALLINT NOT NULL, AI_ACNT_CT_CRD      
INTEGER, ID_CTAC              INTEGER, FL_PYM_RCV         
SMALLINT, MO_PYM_AGT_RCV       DECIMAL(14,3) NOT NULL DEFAULT 0,
LU_ACNT_PYMAGT_RCV   CHAR(4), ID_ACNT_PYMAGT_RCV   INTEGER);

-- c0001
-- CREATE UNIQUE INDEX XIF120PAYMENT_ON_A ON TR_LTM_PYAN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );


CREATE UNIQUE INDEX IF1930PaymentOnAcc ON TR_LTM_PYAN(
AI_ACNT_CT_CRD                 ASC, ID_CTAC  
ASC, LOOKUP1_ID                         ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF120PAYMENT_ON_A ON TR_LTM_PYAN
-- (
--        AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_PYAN ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_RTL_TRN
--------------------------------------------------------
--DROP TABLE TR_LTM_RTL_TRN;

CREATE TABLE TR_LTM_RTL_TRN (LOOKUP1_ID INTEGER  NOT NULL,
AI_LN_ITM 
SMALLINT NOT NULL, AI_LN_ITM_VD         SMALLINT, TY_LN_ITM     
CHAR(2), TS_LN_ITM_BGN        TIMESTAMP,  FL_VD_LN_ITM      
SMALLINT, TS_LN_ITM_END        TIMESTAMP, LU_MTH_LTM_RTL_TRN  
VARCHAR(20)) IN TLOGARTS.TLOG6;

-- C0001
-- CREATE UNIQUE INDEX IF1925RetailTransa ON TR_LTM_RTL_TRN
-- (
--        AI_LN_ITM_VD                   ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
CREATE UNIQUE INDEX IF1925RetailTransa ON TR_LTM_RTL_TRN (
AI_LN_ITM_VD                   ASC, LOOKUP1_ID      
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- C0001
-- CREATE UNIQUE INDEX XIF81POS_SALE_TRAN ON TR_LTM_RTL_TRN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_RTL_TRN  ADD PRIMARY KEY (LOOKUP1_ID,AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_RTL_TRN_OVR
--------------------------------------------------------
--DROP TABLE TR_LTM_RTL_TRN_OVR;

CREATE TABLE TR_LTM_RTL_TRN_OVR (LOOKUP1_ID INTEGER  NOT NULL, 
AI_LN_ITM            SMALLINT NOT NULL, ID_OPR       
INTEGER NOT NULL, TS_LTM_RTL_TRN_OVR   TIMESTAMP, RC_LTM_RTL_TRN_OVR 
VARCHAR(255)) IN TLOGARTS.TLOG6;

-- CREATE UNIQUE INDEX IF1313RetailTransa ON TR_LTM_RTL_TRN_OVR
-- (
--        ID_OPR                         ASC,
--        ID_STR_RT                      ASC
-- );


--ALTER TABLE TR_LTM_RTL_TRN_OVR ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_SLS_RTN
--------------------------------------------------------
--DROP TABLE TR_LTM_SLS_RTN;

CREATE TABLE TR_LTM_SLS_RTN (LOOKUP1_ID INTEGER  NOT NULL, AI_LN_ITM 
SMALLINT NOT NULL, ID_STR_RT_ORG        INTEGER, ID_WS_ORG          
INTEGER, DC_DY_BSN_ORG        INTEGER, AI_TRN_ORG           INTEGER,
AI_LN_ITM_ORG        SMALLINT, ID_ITM_PS_STRGP	    INTEGER, ID_ITM_PS	
INTEGER, ID_ITM_PS_QFR	    INTEGER, ID_ITM		    INTEGER, 
ID_DPT_PS	    INTEGER, LU_UOM		    CHAR(2), ID_GP_TX 
INTEGER, TY_ITM               CHAR(4),  MO_PRC_REG       
DECIMAL(8,3) NOT NULL DEFAULT 0,  MO_PRC_ACT           DECIMAL(8,3) 
DEFAULT 0, QU_ITM_LM_RTN_SLS    DECIMAL(9,2) NOT NULL DEFAULT 0, QU_UN 
DECIMAL(9,2) DEFAULT 0, MO_EXTND             DECIMAL(14,3) NOT
NULL DEFAULT 0, RC_RTN_MR            CHAR(2), LU_MTH_ID_ENR  
CHAR(4), LU_ENR_RT_PRC        CHAR(4), LU_PRC_RT_DRVN       
CHAR(4), LU_ACTN_CD           CHAR(2)) IN TLOGARTS.TLOG6;

--       ID_STR_RT            INTEGER,
--       ID_WS                INTEGER,
--       DC_DY_BSN            TIMESTAMP,
--       AI_TRN               INTEGER
-- );

--CREATE UNIQUE INDEX XIF1025SALE_RETURN ON TR_LTM_SLS_RTN
--(
--       AI_LN_ITM_ORGL                 ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
--);

--CREATE UNIQUE INDEX IF1419SaleReturnLi ON TR_LTM_SLS_RTN
--(
--       ID_GP_TX                       ASC
--);

--CREATE UNIQUE INDEX IF1753SaleReturnLi ON TR_LTM_SLS_RTN
--(
--       LU_UOM                         ASC
--);

--CREATE UNIQUE INDEX IF1841SaleReturnLi ON TR_LTM_SLS_RTN
--(
--      ID_ITM                         ASC
--);

--CREATE UNIQUE INDEX IF2005SaleReturnLi ON TR_LTM_SLS_RTN
--(
--       ID_DPT_PS                      ASC
--);

--CREATE UNIQUE INDEX IF2006SaleReturnLi ON TR_LTM_SLS_RTN
--(
--       ID_ITM_PS                      ASC,
--       ID_ITM_PS_QFR                  ASC
--);

-- CREATE UNIQUE INDEX XIF94SALE_RETURN_T ON TR_LTM_SLS_RTN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF431SALE_RETURN_ ON TR_LTM_SLS_RTN
-- (
--       ID_DPT_PS                      ASC
-- );

-- C0001
-- CREATE UNIQUE INDEX XIF94SALE_RETURN_T ON TR_LTM_SLS_RTN
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
CREATE UNIQUE INDEX XIF94SALE_RETURN_T ON TR_LTM_SLS_RTN( LOOKUP1_ID 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        



--ALTER TABLE TR_LTM_SLS_RTN ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_SLS_RTN_TX
--------------------------------------------------------
--DROP TABLE TR_LTM_SLS_RTN_TX;

CREATE TABLE TR_LTM_SLS_RTN_TX (LOOKUP1_ID INTEGER  
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,ID_ATHY_TX 
VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL, 
MO_TXBL_RTN_SLS      DECIMAL(14,3) NOT NULL DEFAULT 0, MO_TX_RTN_SLS
DECIMAL(14,3) NOT NULL DEFAULT 0)
IN TLOGARTS.TLOG6;

-- C0001
-- CREATE UNIQUE INDEX XIF1041SALE_RETURN ON TR_LTM_SLS_RTN_TX
-- (
--        AI_LN_ITM                      ASC,
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
CREATE UNIQUE INDEX XIF1041SALE_RETURN ON TR_LTM_SLS_RTN_TX(AI_LN_ITM
ASC, LOOKUP1_ID                         ASC, ID_GP_TX
ASC, ID_ATHY_TX                     ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        





--ALTER TABLE TR_LTM_SLS_RTN_TX ADD PRIMARY KEY (LOOKUP1_ID, 
--AI_LN_ITM, ID_ATHY_TX, ID_GP_TX );


--------------------------------------------------------
-- TABLE TR_LTM_TND
--------------------------------------------------------
--DROP TABLE TR_LTM_TND;

CREATE TABLE TR_LTM_TND (LOOKUP1_ID INTEGER  NOT NULL, AI_LN_ITM
SMALLINT NOT NULL,TY_TND               CHAR(4), ID_ACNT_NMB    
INTEGER,ID_ACNT_TND          INTEGER, MO_FRG_CY           
DECIMAL(8,3) NOT NULL DEFAULT 0, MO_ITM_LN_TND       
DECIMAL(14,3) NOT NULL DEFAULT 0, TY_VR_ADS            CHAR(2))
IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF172TENDER_LINE_ ON TR_LTM_TND( ID_ACNT_NMB
ASC, TY_TND                         ASC, LOOKUP1_ID 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF88TENDER_LINE_I ON TR_LTM_TND
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- C0001
-- CREATE UNIQUE INDEX XIF88TENDER_LINE_I ON TR_LTM_TND
-- (
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
-- );
 


CREATE UNIQUE INDEX XIF96TENDER_LINE_I ON TR_LTM_TND(TY_TND 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        



--ALTER TABLE TR_LTM_TND  ADD PRIMARY KEY (LOOKUP1_ID, 
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_TND_CHN
--------------------------------------------------------
--DROP TABLE TR_LTM_TND_CHN;

CREATE TABLE TR_LTM_TND_CHN (LOOKUP1_ID INTEGER 
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, TY_TND
CHAR(4),  MO_LN_ITM_TND_CHN    DECIMAL(14,3) NOT NULL DEFAULT 0)
IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF426TENDER_CHANG ON TR_LTM_TND_CHN(TY_TND
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF90TENDER_CHANGE ON TR_LTM_TND_CHN
-- (
--       AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

CREATE UNIQUE INDEX XIF90TENDER_CHANGE ON TR_LTM_TND_CHN(LOOKUP1_ID
ASC);
-- c0001
--	LOOKUP1_ID			ASC
--        ID_STR_RT                      ASC,
--        ID_WS                          ASC,
--        DC_DY_BSN                      ASC,
--        AI_TRN                         ASC
--	);


--ALTER TABLE TR_LTM_TND_CHN  ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_LTM_TX
--------------------------------------------------------
--DROP TABLE TR_LTM_TX;

CREATE TABLE TR_LTM_TX ( LOOKUP1_ID INTEGER  NOT NULL, AI_LN_ITM 
SMALLINT NOT NULL,ID_ATHY_TX           VARCHAR(40), ID_GP_TX     
INTEGER, MO_TXBL              DECIMAL(14,3) NOT NULL DEFAULT 0, MO_TX 
DECIMAL(14,3) DEFAULT 0);
CREATE UNIQUE INDEX XIF805SALES_TAX_LI ON TR_LTM_TX(ID_GP_TX
ASC, ID_ATHY_TX                     ASC);

-- CREATE UNIQUE INDEX XIF92SALES_TAX_LIN ON TR_LTM_TX
-- (
--        AI_LN_ITM                      ASC,
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

CREATE UNIQUE INDEX XIF92SALES_TAX_LIN ON TR_LTM_TX(LOOKUP1_ID			ASC);
-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_LTM_TX ADD PRIMARY KEY (LOOKUP1_ID, AI_LN_ITM);


--------------------------------------------------------
-- TABLE TR_MDFR_SLS_TX_EXM
--------------------------------------------------------
--DROP TABLE TR_MDFR_SLS_TX_EXM;

CREATE TABLE TR_MDFR_SLS_TX_EXM (LOOKUP1_ID INTEGER 
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL,ID_ATHY_TX
VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL, 
MO_EXM_TXBL          DECIMAL(8,3) DEFAULT 0, MO_EXM_TX     
DECIMAL(8,3) DEFAULT 0, RC_EXM_TX            CHAR(2),
ID_CF_TX_EXM         INTEGER, NM_CF_HLDR     
VARCHAR(40)) IN TLOGARTS.TLOG6;

--ALTER TABLE TR_MDFR_SLS_TX_EXM ADD PRIMARY KEY (LOOKUP1_ID,
--AI_LN_ITM, ID_ATHY_TX, ID_GP_TX );


--------------------------------------------------------
-- TABLE TR_MDFR_SLS_TX_OVRD
--------------------------------------------------------
--DROP TABLE TR_MDFR_SLS_TX_OVRD;

CREATE TABLE TR_MDFR_SLS_TX_OVRD (LOOKUP1_ID INTEGER  NOT NULL, 
AI_LN_ITM            SMALLINT NOT NULL, ID_ATHY_TX           
VARCHAR(40) NOT NULL, ID_GP_TX             INTEGER NOT NULL, 
MO_TX_ORGL           DECIMAL(8,3) DEFAULT 0, RC_TX_OVRD       
CHAR(2), ID_CF_TX_OVRD        INTEGER,  NM_CF_HLDR       
VARCHAR(40)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1860SaleReturnTa ON TR_MDFR_SLS_TX_OVRD(ID_GP_TX 
ASC, ID_ATHY_TX                     ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        



--ALTER TABLE TR_MDFR_SLS_TX_OVRD  ADD PRIMARY KEY (LOOKUP1_ID, 
--AI_LN_ITM, ID_ATHY_TX, ID_GP_TX );


--------------------------------------------------------
-- TABLE TR_RTL
--------------------------------------------------------
--DROP TABLE TR_RTL;

CREATE TABLE TR_RTL (LOOKUP1_ID INTEGER  NOT NULL, ID_CT 
INTEGER,IN_RNG_ELPSD     DECIMAL(5,0) NOT NULL DEFAULT 0, IN_TND_ELPSD 
DECIMAL(5,0) NOT NULL DEFAULT 0, IN_ELPSD_IDL         DECIMAL(5,0)
NOT NULL DEFAULT 0, IN_LCK_ELPSD         DECIMAL(5,0) NOT NULL DEFAULT 0, 
QU_UN_RTL_TRN        DECIMAL(3,0) DEFAULT 0, QU_ITM_LN_SC      
DECIMAL(7,0) NOT NULL DEFAULT 0, PE_ITM_LN_SC         DECIMAL(5,2) 
NOT NULL DEFAULT 0, QU_ITM_LN_KY         DECIMAL(7,0) NOT NULL DEFAULT 0,
PE_ITM_LN_KY         DECIMAL(5,2) NOT NULL DEFAULT 0, QU_DPT_KY       
DECIMAL(7,0) NOT NULL DEFAULT 0, PE_DPT_KY            DECIMAL(5,2)
NOT NULL DEFAULT 0, FL_SPN               SMALLINT) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX XIF1219TR_RTL ON TR_RTL (ID_CT     
ASC) 
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- CREATE UNIQUE INDEX XIF125POINT_OF_SAL ON TR_RTL
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_RTL ADD PRIMARY KEY (LOOKUP1_ID);


--------------------------------------------------------
-- TABLE TR_SHP_RTL
--------------------------------------------------------
--DROP TABLE TR_SHP_RTL;

CREATE TABLE TR_SHP_RTL (ID_SHP_RTL_TRN  
INTEGER NOT NULL, ID_CRR               INTEGER,ID_ADS 
INTEGER, ID_PRTY              INTEGER, TY_RO_PRTY     
CHAR(6), ID_TRCK_SHP          INTEGER, UR_URL_TRCK_SHP 
VARCHAR(255), TY_LV_SV             CHAR(2), TS_DT_PRFC 
DATE, MO_PYM_RQ            DECIMAL(8,3) DEFAULT 0, LU_PYM_MTH 
CHAR(2),  NA_INST_SPL          CLOB) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1741RetailTransa ON TR_SHP_RTL(ID_ADS
ASC,ID_PRTY                        ASC, TY_RO_PRTY     
ASC, ID_CRR 
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        





--ALTER TABLE TR_SHP_RTL ADD PRIMARY KEY (ID_SHP_RTL_TRN);


--------------------------------------------------------
-- TABLE TR_TND_AZN_RVS
--------------------------------------------------------
--DROP TABLE TR_TND_AZN_RVS;

CREATE TABLE TR_TND_AZN_RVS (LOOKUP1_ID INTEGER  
NOT NULL, AI_LN_ITM            SMALLINT NOT NULL, AI_TND_AZN
SMALLINT NOT NULL, AI_RVS_TND_AZN       INTEGER NOT NULL,
LU_ADJN              DECIMAL(14,3) DEFAULT 0,  TS_TM_DT   
DATE, ID_RFC               INTEGER,  NA_HOS             
VARCHAR(255)) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1783TenderAuthor ON TR_TND_AZN_RVS( AI_TND_AZN
ASC,   AI_LN_ITM                      ASC,	LOOKUP1_ID	
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        

-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_TND_AZN_RVS ADD PRIMARY KEY (LOOKUP1_ID, 
--AI_LN_ITM,
--AI_TND_AZN, AI_RVS_TND_AZN  );


--------------------------------------------------------
-- TABLE TR_TOT_RTL
--------------------------------------------------------
--DROP TABLE TR_TOT_RTL;

CREATE TABLE TR_TOT_RTL (	LOOKUP1_ID INTEGER  NOT NULL,
TY_TRN_TOT           VARCHAR(20) NOT NULL, MO_TOT_RTL_TRN  
DECIMAL(14,3) DEFAULT 0) IN TLOGARTS.TLOG6;

CREATE UNIQUE INDEX IF1826RetailTransa ON TR_TOT_RTL(TY_TRN_TOT 
ASC, LOOKUP1_ID			ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- C0001
--	LOOKUP1_ID			ASC
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_TOT_RTL ADD PRIMARY KEY (LOOKUP1_ID, TY_TRN_TOT);


--------------------------------------------------------
-- TABLE TR_TRN
--------------------------------------------------------
--DROP TABLE TR_TRN;

CREATE TABLE TR_TRN (LOOKUP1_ID INTEGER  NOT NULL, ID_OPR
INTEGER,TS_TM_SRT            TIMESTAMP, TY_TRN          
CHAR(6), TS_TRN_BGN           TIMESTAMP, TS_TRN_END     
TIMESTAMP, FL_CNCL              SMALLINT, FL_VD          
SMALLINT, FL_TRG_TRN           SMALLINT, FL_KY_OFL      
SMALLINT) IN TLOGARTS.TLOG6;

-- D0001
-- CREATE UNIQUE INDEX XIF1053POINT_OF_SA ON TR_TRN
-- (
--        ID_STR_RT                      ASC
-- );

-- D0001
-- CREATE UNIQUE INDEX XIF123POINT_OF_SAL ON TR_TRN
-- (
--        ID_WS                          ASC,
--        ID_OPR                         ASC,
--        TS_TM_SRT                      ASC,
--       ID_STR_RT                      ASC
--);

-- D0001
-- CREATE UNIQUE INDEX XIF174POINT_OF_SAL ON TR_TRN
-- (
--        ID_WS                          ASC,
--        ID_STR_RT                      ASC
-- );

CREATE UNIQUE INDEX XIF371POINT_OF_SAL ON TR_TRN(TY_TRN  
ASC)
USING STOGROUP TLOGARTSSTOR                                  
PRIQTY 7200                                                  
SECQTY 720                                                   
CLUSTER                                                      
BUFFERPOOL BP2                                               
CLOSE NO                                                     
;        


-- D0001
-- CREATE UNIQUE INDEX XIF576POINT_OF_SAL ON TR_TRN
-- (
--        DC_DY_BSN                      ASC,
--        ID_STR_RT                      ASC
-- );


--ALTER TABLE TR_TRN ADD PRIMARY KEY (LOOKUP1_ID);


--------------------------------------------------------
-- TABLE TR_VD_PST
--------------------------------------------------------
--DROP TABLE TR_VD_PST;

CREATE TABLE TR_VD_PST (LOOKUP1_ID INTEGER  NOT NULL,
ID_WS_VD             INTEGER, DC_DY_BSN_VD        
TIMESTAMP, AI_TRN_VD            INTEGER) IN TLOGARTS.TLOG6;

-- CREATE UNIQUE INDEX XIF108POST_VOID_TR ON TR_VD_PST
-- (
--        ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );

-- CREATE UNIQUE INDEX XIF844POST_VOID_TR ON TR_VD_PST
-- (
--       ID_WS                          ASC,
--       AI_TRN                         ASC,
--       DC_DY_BSN                      ASC,
--       ID_STR_RT                      ASC
-- );

-- CREATE UNIQUE INDEX XIF108POST_VOID_TR ON TR_VD_PST
-- (
--       ID_STR_RT                      ASC,
--       ID_WS                          ASC,
--       DC_DY_BSN                      ASC,
--       AI_TRN                         ASC
-- );


--ALTER TABLE TR_VD_PST ADD PRIMARY KEY (LOOKUP1_ID);


----------------------------------
-- Added tables for v1.0.4              a0001
----------------------------------

-- These tables were alterd with the new key...
--    TR_LTM_CHK_TND   **
--    TR_FDSV	**
--    TR_TRN	**
--    TR_TND_AZN_RVS	**
--    TR_RTL	**
--    CO_MDFR_TX_EXM	**
--    TR_LTM_DSC	* not in esql
--    CO_MDFR_RTL_PRC	**
--    TR_MDFR_SLS_TX_OVRD	**
--    TR_LTM_RTL_TRN_OVR	**
--    TR_TOT_RTL	**
--    CO_MDFR_CMN	**
--    TR_VD_PST	* not in esql
--    TR_LTM_SLS_RTN	**
--    TR_LTM_TND_CHN	**
--    CO_VLD_RST	**
--    TR_LTM_RTL_TRN	**
--    CO_MDFR_SRZ	**
--    TR_MDFR_SLS_TX_EXM	**
--    CO_MDFR_TX_OVRD	**
--    TR_LTM_CPN_TND	**
--    TR_LTM_SLS_RTN_TX	**
--    TR_LTM_TX	**
--    TR_LTM_TND	**
--    TR_LTM_GF_CF	**
--    TR_LTM_PYAN	**
--    TR_LTM_CRDB_CRD_TN	**
--    CO_AZN_TND	* not in esql
--     CA_DY_BSN

--------------------------------------------------------
-- TABLE LOOKUP1
--------------------------------------------------------

--DROP TABLE LOOKUP1;

CREATE TABLE LOOKUP1 ( LOOKUP1_ID INTEGER  NOT NULL 
GENERATED ALWAYS AS IDENTITY (START WITH 0, INCREMENT BY
1, NO CACHE ) , AI_TRN INTEGER  NOT NULL , ID_STR_RT
INTEGER  NOT NULL , ID_WS INTEGER  NOT NULL , DC_DY_BSN 
TIMESTAMP  NOT NULL  , CONSTRAINT CC1107359436730 PRIMARY 
KEY ( AI_TRN, ID_STR_RT, ID_WS, DC_DY_BSN)) IN TLOGARTS.TLOG6;
--	CONSTRAINT CC1107193377078 PRIMARY KEY ( LOOKUP1_ID)

--------------------------------------------------------
-- TABLE CA_DY_BSN
--------------------------------------------------------
--DROP TABLE CA_DY_BSN;

CREATE TABLE CA_DY_BSN ( DC_DY_BSN 
TIMESTAMP  	NOT NULL,	ID_STR_RT 
INTEGER		NOT NULL, ID_WS 	
INTEGER, AI_TRN 		INTEGER, TS_BGN	
TIMESTAMP	NOT NULL, TS_END		
TIMESTAMP	NOT NULL);


--ALTER TABLE CA_DY_BSN ADD PRIMARY KEY (DC_DY_BSN, ID_STR_RT);

--------------------------------------------------------
-- TABLE PA_OPR
--------------------------------------------------------
--DROP TABLE PA_OPR;

CREATE TABLE PA_OPR (ID_STR_RT		
INTEGER NOT NULL,ID_OPR			INTEGER NOT NULL,ID_EM
INTEGER,PW_ACS_OPR		VARCHAR(20)) IN TLOGARTS.TLOG6;


--ALTER TABLE PA_OPR  ADD PRIMARY KEY (ID_STR_RT, ID_OPR);

--------------------------------------------------------
-- TABLE PA_STR_RTL
--------------------------------------------------------
--DROP TABLE PA_STR_RTL;

CREATE TABLE PA_STR_RTL (ID_STR_RT		
INTEGER NOT NULL,ID_PRTY			
INTEGER,TY_RO_PRTY		CHAR(6),ID_STRGP	
INTEGER,DC_OPN_RT_STR		TIMESTAMP,DC_CL_RT_STR	
TIMESTAMP,QU_SZ_STR		DECIMAL(9,2),QU_SZ_AR_SL
DECIMAL(9,2)) IN TLOGARTS.TLOG6;

--ALTER TABLE PA_STR_RTL ADD PRIMARY KEY (ID_STR_RT);

----------------------------------
-- END Added tables for v1.0.4              a0001
----------------------------------


--------------------------------------------------------
-- FOREIGN KEYS
--------------------------------------------------------


--ALTER TABLE CO_AZN_TND ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM, ID_AZN_PRE) REFERENCES CO_AZN_TND ON DELETE SET NULL;


--ALTER TABLE CO_AZN_TND ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE RESTRICT ON
--UPDATE RESTRICT;


--ALTER TABLE CO_MDFR_CMN ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_SLS_RTN ON DELETE RESTRICT 
--ON UPDATE RESTRICT;


--ALTER TABLE CO_MDFR_RTL_PRC ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM)  REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT 
--ON UPDATE RESTRICT;

--ALTER TABLE CO_MDFR_TX_EXM ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM)  REFERENCES TR_LTM_TX ON DELETE RESTRICT ON UPDATE RESTRICT;


--ALTER TABLE CO_MDFR_TX_OVRD ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM)  REFERENCES TR_LTM_TX  ON DELETE RESTRICT  ON 
--UPDATE RESTRICT;


--ALTER TABLE CO_VLD_RST ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM) 
--REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT  ON UPDATE RESTRICT;


--ALTER TABLE CO_VLD_RST  ADD FOREIGN KEY (ID_QST_RST_VLD) 
--REFERENCES CO_VLD_RST_QST  ON DELETE SET NULL;


--ALTER TABLE CO_MDFR_SRZ ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)
--REFERENCES TR_LTM_SLS_RTN  ON DELETE RESTRICT ON UPDATE RESTRICT;


--ALTER TABLE TR_FDSV ADD FOREIGN KEY (LOOKUP1_ID) REFERENCES 
--TR_RTL ON DELETE CASCADE;


--ALTER TABLE TR_LTM_CHK_TND ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM) REFERENCES TR_LTM_TND  ON DELETE CASCADE;


--ALTER TABLE TR_LTM_CPN_TND ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE CASCADE;


-- ALTER TABLE TR_LTM_CPN_TND
--        ADD FOREIGN KEY (LOOKUP1_ID, AI_LN_ITM)
--                              REFERENCES TR_LTM_SLS_RTN
--                              ON DELETE RESTRICT
--                              ON UPDATE RESTRICT;


--ALTER TABLE TR_LTM_CRDB_CRD_TN ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM) REFERENCES TR_LTM_TND ON DELETE CASCADE;

--ALTER TABLE TR_LTM_DSC ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE CASCADE;


--ALTER TABLE TR_LTM_GF_CF ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE;


--ALTER TABLE TR_LTM_PYAN ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE CASCADE;


--ALTER TABLE TR_LTM_RTL_TRN ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM_VD) REFERENCES TR_LTM_RTL_TRN ON DELETE SET NULL;


--ALTER TABLE TR_LTM_RTL_TRN ADD FOREIGN KEY (LOOKUP1_ID)
--REFERENCES TR_RTL  ON DELETE RESTRICT ON UPDATE RESTRICT;


--ALTER TABLE TR_LTM_RTL_TRN_OVR ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE RESTRICT ON 
--UPDATE RESTRICT;


--ALTER TABLE TR_LTM_SLS_RTN ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM)  REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE;


--ALTER TABLE TR_LTM_SLS_RTN ADD FOREIGN KEY (ID_ITM) 
--REFERENCES AS_ITM ON DELETE SET NULL;


--ALTER TABLE TR_LTM_SLS_RTN ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM_ORG)  REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE;

-- ID_STR_RT must be cascade                          ON DELETE SET NULL;


--ALTER TABLE TR_LTM_SLS_RTN_TX ADD FOREIGN KEY (
--LOOKUP1_ID, AI_LN_ITM) REFERENCES TR_LTM_SLS_RTN ON 
--DELETE RESTRICT ON UPDATE RESTRICT;


--ALTER TABLE TR_LTM_TND ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN  ON DELETE RESTRICT;

-- ID_STR_RT must not be cascade                             ON DELETE CASCADE;


--ALTER TABLE TR_LTM_TND_CHN ADD FOREIGN KEY 
--(LOOKUP1_ID, AI_LN_ITM)  REFERENCES TR_LTM_RTL_TRN ON
--DELETE CASCADE;


--ALTER TABLE TR_LTM_TX ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM) REFERENCES TR_LTM_RTL_TRN ON DELETE CASCADE;


--ALTER TABLE TR_MDFR_SLS_TX_EXM ADD FOREIGN KEY (LOOKUP1_ID,
--AI_LN_ITM, ID_ATHY_TX, ID_GP_TX)  REFERENCES TR_LTM_SLS_RTN_TX 
--ON DELETE RESTRICT  ON UPDATE RESTRICT;


--ALTER TABLE TR_MDFR_SLS_TX_OVRD ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM, ID_ATHY_TX, ID_GP_TX) REFERENCES TR_LTM_SLS_RTN_TX ON 
--DELETE RESTRICT ON UPDATE RESTRICT;

--ALTER TABLE TR_RTL ADD FOREIGN KEY (LOOKUP1_ID) REFERENCES 
--TR_TRN ON DELETE CASCADE;


--ALTER TABLE TR_TND_AZN_RVS ADD FOREIGN KEY (LOOKUP1_ID, 
--AI_LN_ITM, AI_TND_AZN) REFERENCES CO_AZN_TND  ON DELETE RESTRICT 
--ON UPDATE RESTRICT;


--ALTER TABLE TR_TOT_RTL ADD FOREIGN KEY (LOOKUP1_ID) 
--REFERENCES TR_RTL  ON DELETE RESTRICT  ON UPDATE RESTRICT;


-- d0001
-- ALTER TABLE TR_TRN
--        ADD FOREIGN KEY (ID_STR_RT, ID_WS)
--                              REFERENCES AS_WS
--                              ON DELETE RESTRICT
--                              ON UPDATE RESTRICT;


--ALTER TABLE TR_VD_PST  ADD FOREIGN KEY (LOOKUP1_ID) 
--REFERENCES TR_TRN ON DELETE RESTRICT;
-- ID_STR_RT cannot be null                         ON DELETE SET NULL;

--	a0001
--ALTER TABLE PA_OPR  ADD FOREIGN KEY (ID_STR_RT)  
--REFERENCES PA_STR_RTL ON DELETE RESTRICT ON UPDATE RESTRICT;

--ALTER TABLE CA_DY_BSN ADD FOREIGN KEY (ID_STR_RT)  
--REFERENCES PA_STR_RTL ON DELETE RESTRICT ON UPDATE RESTRICT;


--ALTER TABLE CA_DY_BSN
--       ADD FOREIGN KEY (ID_STR_RT, ID_WS)
--                             REFERENCES AS_WS
--                             ON DELETE RESTRICT
--                             ON UPDATE RESTRICT;
--	end a0001

-- CONNECT RESET;
-- TERMINATE;

--------------------------------------------------------
-- PREPOPULATE STORE ID AND OPR ID TABLES IN DATABASE TLOGARTS
--------------------------------------------------------

INSERT INTO JM63USR.PA_STR_RTL(ID_STR_RT) VALUES(123);

Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 222);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 1);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 206);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 2);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 49);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 17);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 204);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 116);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 13);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 20);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 30);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 58);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 42);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 205);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 92);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 101);
Insert INTO JM63USR.PA_OPR (ID_STR_RT, ID_OPR) VALUES (123, 1000);