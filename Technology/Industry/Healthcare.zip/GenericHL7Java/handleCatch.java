/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2013
Licensed Materials - Property of IBM
*/
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBrokerException;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRecoverableException;

public class handleCatch extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal failure = getOutputTerminal("failure");

		try {
			out.propagate(assembly);
		} catch (MbBrokerException exception) {
			if (failure.isAttached()) {
				// The failure terminal is attached so create an new 
				// exception, nest the original one inside and throw
				
				// The Java framework will copy this exception (and any nested ones) 
				// to the exception list propagated to the failure terminal
				String[] newErrorInserts = new String[2];
				newErrorInserts[0] = "5";
				newErrorInserts[1] = "HL7 input subflow - rethrowing exception";
				MbRecoverableException newException = new MbRecoverableException("HL7Input", 
					"catch terminal", exception.getMessageSource(), exception.getMessageKey(),
					"Error caught by HL7 input subflow", newErrorInserts);
				
				MbException nested = exception.getNestedException();
				if (null != nested) {
					newException.addNestedException(nested);
				}

				throw newException;
				
			} else {
				// Failure terminal is not attached so throw to upstream
				throw exception;
			}
		}
	}
}
