package sample;

import com.ibm.broker.config.appdev.Terminal;
import com.ibm.broker.config.appdev.nodes.TraceNode;
import com.ibm.broker.config.appdev.nodes.TraceNode.ENUM_TRACE_DESTINATION;
import com.ibm.etools.mft.conversion.esb.extensionpoint.AbstractMediationPrimitiveConverter;
import com.ibm.etools.mft.conversion.esb.extensionpoint.Nodes;
import com.ibm.etools.mft.conversion.esb.model.mfc.AbstractProperty;
import com.ibm.etools.mft.conversion.esb.model.mfc.FailTerminal;
import com.ibm.etools.mft.conversion.esb.model.mfc.Property;

public class TracePrimitiveConverter extends
		AbstractMediationPrimitiveConverter {

	// Constants defining the possible destinations for a Trace primitive.
	private static final int DEST_LOCAL_SERVER_LOG = 0;
	private static final int DEST_USER_TRACE = 1;
	private static final int DEST_FILE = 2;
	
	public String getConvertedTo() {
		return "Trace node";
	}

	@Override
	public String getType() {
		return "Trace";
	}

	@Override
	public Terminal getInputTerminal(String sourceTerminalName, Nodes nodes) {
		TraceNode trace = (TraceNode) nodes.getNode(ROLE_MAIN);
		return trace.INPUT_TERMINAL_IN;
	}

	@Override
	public Terminal getOutputTerminal(String sourceTerminalName, Nodes nodes) {
		TraceNode trace = (TraceNode) nodes.getNode(ROLE_MAIN);
		if ("Out".equals(sourceTerminalName))
			return trace.OUTPUT_TERMINAL_OUT;
		return null;
	}

	/** Get the value of a mediation primitive property, given the default.
	 */
	String getPropertyValue( ConverterContext converterContext, String name, String defaultValue ) {
		String result = defaultValue;
		AbstractProperty ap = getPropertyOfSourcePrimitive(converterContext, name);
		if( ap != null && ap instanceof Property ) {
			Property pr = (Property)ap;
			String val = pr.getValue();
			if( val != null ) result = val;
		}
		return result;
	}

	/** Check if a mediation primitive property is promoted. 
	 */
	boolean isPromoted( ConverterContext converterContext, String name ) {
		AbstractProperty ap = getPropertyOfSourcePrimitive(converterContext, name);
		if( ap != null && ap instanceof Property )
			return ((Property)ap).getPromotedPropertyName() != null;
		return false;
	}
	
	@Override
	public Nodes convert(ConverterContext converterContext) throws Exception {
		// Create the container for the message flow nodes that you create to recreate the mediation primitive in IBM Integration Bus.
		Nodes nodes = createNodes(converterContext);
		
		// Get the default name.
		String nodeName = getProposedIIBNodeNameFromSourcePrimitive(converterContext);
		
		// Get the long description for the primitive.
		String longDescription = converterContext.sourcePrimitive.getDescription();
		if( longDescription == null ) longDescription = "Converted Trace primitive";
		
		// Get the short description for the primitive.
		String shortDescription = converterContext.sourcePrimitive.getDisplayName();
		if( shortDescription == null ) shortDescription = "Converted "+nodeName;
		
		// The trace mediation primitive has the following properties:
		// enabled     - whether the message should be traced or not.
		// destination - the type of tracing required. 
		// file        - the file path if tracing is to a file.
		// literal     - the format of the message to be traced.
		// root        - the location in the SMO from which to trace.
					
		// Get the value of the "enabled" property.
		// This property can have the following values: true or false. The default value is true.
		// The value of the property is used at runtime. 
		// boolean enabled = getPropertyValue(converterContext,"enabled","true").equalsIgnoreCase("true");
		// Its main use is as a promoted property so that the trace can be turned on and off.
		boolean anyPromoted = isPromoted(converterContext,"enabled");
					
		// Get the value of the "destination" property.
		// This property can have any of the following values: 
		// 0: local server log (default)
		// 1: user trace
		// 2: file
		int destinationType = Integer.parseInt(getPropertyValue(converterContext,"destination","0"));
		anyPromoted |= isPromoted(converterContext,"destination");
			
		// Get the value of the "file" property.
		// This property can have the following values: fileName or null. Null is the default value.
		String file = getPropertyValue(converterContext,"file","");
		anyPromoted |= isPromoted(converterContext,"file");
					
		// Get the value of the "literal" property.
		// The value of this property is a format string: {0}, {1}, {2}, {3}, {4}, {5}
		// The trace mediation primitive literal property can have the following values:
		// element {0}; item: Timestamp; Decription: The UTC timestamp, indicating when the Trace primitive was invoked. 
		// element {1}; item: Message ID; Decription: The message ID, from the SMO. 
		// element {2}; item: Mediation Name; Decription: The name of the Trace mediation primitive instance that generated the trace message. 
		// element {3}; item: Module Name; Decription: The name of the module, containing the Trace mediation primitive instance, that generated the trace message. 
		// element {4}; item: Message; Decription: The SMO, or part of the SMO, as specified by the Root property XPath. 
		// element {5}; item: Version; Decription: The version of the SMO. 
		// {0}, {1}, {2}, {3}, {4}, {5} is the default value.
		String literal = getPropertyValue(converterContext,"literal","{0}, {1}, {2}, {3}, {4}, {5}");
		anyPromoted |= isPromoted(converterContext,"literal");
						
		// Get the value of the "root" property.
		// The value of this property is an XPath expression that represents the scope of the message and SMO to be inserted into the trace message.
		// The default value is the entire SMO: "/".
		String root = getPropertyValue(converterContext,"root","/");
		anyPromoted |= isPromoted(converterContext,"root");
					
		// Create the trace node.
		// If you create multiple message flow nodes to recreate a mediation primitive, you must assign a unique role 
		// (which is a free-form string) to each message flow node that you create in the Nodes object.
		// In this sample, there is only one message flow node that needs to be created and the unique id value is set to ROLE_MAIN. 
		TraceNode node = (TraceNode) createNode(converterContext.targetFlow, nodeName, ROLE_MAIN, TraceNode.class, nodes);
					
		// Copy the description fields across.
		node.setLongDescription(longDescription);
		node.setShortDescription(shortDescription);
		// The message catalog and the message number properties are left with their default values.
							
		// Set the trace destination property and the file path property.
		if( destinationType == DEST_FILE ) {
			node.setDestination(ENUM_TRACE_DESTINATION.file);
			node.setFilePath(file);
		} else if( destinationType == DEST_LOCAL_SERVER_LOG )
			node.setDestination(ENUM_TRACE_DESTINATION.localError);
		else if( destinationType == DEST_USER_TRACE )
			node.setDestination(ENUM_TRACE_DESTINATION.userTrace);
		else 
			throw new IllegalArgumentException("For primitive "+nodeName+": invalid destination type value "+destinationType);
					
		// Convert the trace mediation primitive root property value into the variable message.
		// The variable message is used by the pattern property to record the part of the message that you want to trace.
		// Convert "/" to ${Root}
		// Convert "/body" to ${Body}
		// Create a todo task to convert other trace patterns. 
		String message = "${Root}";
		if( root.equalsIgnoreCase("/body") )
			message = "${Body}";
		else 
			createToDoTask(getTargetFlowFile(converterContext),"Trace root property '"+root+"' has been converted to '"+message+"'. " +
					"Check that this is correct and update the value if necessary.");
					
		// Replace the values of the trace mediation primitive literal property with the corresponding IBM Integration Bus values:			
		// Convert the literal value {0} to the current timestamp.
		// Note: The WebSphere ESB format is "10/06/13 11:33". The IBM Integration Bus format is "2013-06-10 11:38:08.923194".
		literal = literal.replace("{0}","${CURRENT_TIMESTAMP}");
					
		// Convert the literal value {1} to the message creation time.
		if( literal.indexOf("{1}") != -1 )
			createToDoTask(getTargetFlowFile(converterContext),"Trace literal property '"+literal+"' includes a reference " + 
					"to message ID {1}. This is converted to message creation time.  Check that this is correct.");
		// Ideally message ID would map to a UUID for the message but that is transport-dependent.
		literal = literal.replace("{1}","${Properties.CreationTime}");			
					
		// Convert the literal value {2} to the message flow node name.
		literal = literal.replace("{2}","${NodeLabel}"); 
					
		// Convert the literal value {3} to the operation subflow name.
		literal = literal.replace("{3}","${MessageFlowLabel}"); 
					
		// Convert the literal value {4} message - specified via the "root" property
		literal = literal.replace("{4}",message);
					
		// Convert the literal value {5} to the IBM Integration Bus version.  
		// Note: The WebSphere ESB version is represented as "7". The IBM Integration Bus version is represented as "9000". 
		literal = literal.replace("{5}","${BrokerVersion}");
					
		//Set the trace message flow node pattern property.
		node.setPattern(literal);
								
						
		// If any properties were promoted, create a to-do task that indicates what action needs to be performed to complete conversion into IBM Integration Bus.
		if( anyPromoted )
			createToDoTask(getTargetFlowFile(converterContext),"The trace mediation primitive includes promoted properties that need to be converted manually.");
					
		// Check for a wired fail terminal, which cannot be converted.
		// The IBM Integration Bus trace node only has an input terminal and an output terminal.
		for( FailTerminal ft: converterContext.sourcePrimitive.getFailTerminal() ) {
			if( ft.getWire().size() > 0 )
				createToDoTask(getTargetFlowFile(converterContext),"Trace primitive has wired a fail terminal, but the converted trace node has no fail terminal. "+
						"There may be additional nodes which are no longer wired in the converted flow.");
		}
			
		return nodes;
	}
}