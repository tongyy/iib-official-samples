package sample;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.wsdl.Operation;
import javax.wsdl.PortType;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;

import com.ibm.broker.config.appdev.MessageMSLMap;
import com.ibm.broker.config.appdev.Terminal;
import com.ibm.broker.config.appdev.nodes.MQInputNode;
import com.ibm.broker.config.appdev.nodes.MQOutputNode;
import com.ibm.broker.config.appdev.nodes.MappingMSLNode;
import com.ibm.broker.config.appdev.nodes.PassthroughNode;
import com.ibm.broker.config.appdev.nodes.ResetContentDescriptorNode;
import com.ibm.broker.config.appdev.nodes.RouteToLabelNode;
import com.ibm.etools.mft.conversion.esb.extensionpoint.AbstractBindingConverter;
import com.ibm.etools.mft.conversion.esb.extensionpoint.Nodes;
import com.ibm.msl.mapping.api.MapGenerator;
import com.ibm.wsspi.sca.scdl.mq.MQConnection;
import com.ibm.wsspi.sca.scdl.mq.MQExportBinding;
import com.ibm.wsspi.sca.scdl.mq.MQExportMethodBinding;
import com.ibm.wsspi.sca.scdl.mq.MQReceiveQueue;
import com.ibm.wsspi.sca.scdl.mq.MQSendQueue;
import com.ibm.wsspi.sca.scdl.mq.RequestType1;
import com.ibm.wsspi.sca.scdl.mq.ResponseType1;
import com.ibm.wsspi.sca.scdl.mqbase.MQConfiguration;

public class MQExportBindingConverter extends AbstractBindingConverter {

	private static final String EXPORT_REQUEST = "_MQInput";
	private static final String EXPORT_RESPONSE = "_MQOutput";
	private static final String EXPORT_ROUTE = "_Route";
	private static final String EXPORT_FUNCTION_SELECTOR = "_FunctionSelector";
	private static final String EXPORT_DATA_HANDLER = "_DataHandler";
	private static final String EXPORT_FS_MAPPING = "_FSMapping";
	
	private static final String FS_SINGLE_OPERATION = "com.ibm.wbiserver.functionselector.ConstantFunctionSelector";
	private static final String FS_HANDLE_MESSAGE = "com.ibm.websphere.sca.mq.selector.impl.Constant";
	private static final String FS_MQ_BODY_FORMAT = "com.ibm.websphere.sca.mq.selector.impl.Format";
	private static final String FS_MQ_MESSAGE_TYPE = "com.ibm.websphere.sca.mq.selector.impl.Type";
	private static final String FS_TARGET_FUNCTION = "com.ibm.websphere.sca.mq.selector.impl.TargetFunctionNameProperty";
	
	private static final String DH_XML = "{http://www.ibm.com/xmlns/prod/websphere/j2ca/configuration/6.1.0}UTF8XMLDataHandler";
	
	@Override
	public String getConvertedTo() {
		return "MQImport node";
	}

	@Override
	public String getType() {
		return "com.ibm.wsspi.sca.scdl.mq.impl.MQExportBindingImpl";
	}

	/**Convert the MQ Export into nodes.
	 * 
	 * This converter uses the following pattern of nodes.
	 * 
	 * MQInput node -> "Function Selector" Mapping node -> "Data Handler" (RCD) node -> RouteToLabel node
	 * 
	 * Label for operation1 -> operation1 subflow -> MQOutputNode
	 * Label for operation2 -> operation2 subflow ----^
	 * 
	 * The mapping node provides the Function Selector implementation, choosing
	 * which operation to route to based on the content of the input message.
	 * 
	 * The Label nodes for each operation and the operation subflows are generated
	 * by the conversion framework.
	 * The subflow outputs are automatically wired to the MQOuputNode.
	 */
	@Override
	public Nodes convert(ConverterContext converterContext) throws Exception {		

		// Create the container for the message flow nodes that you create to recreate the MQ export
		// binding in IBM Integration Bus.
		Nodes nodes = createNodes(converterContext);
		
		// Get the default name for the MQ export binding.
		// This name is used later on to create unique names for the message flow nodes that are created.
		String nodeName = getProposedIIBNodeNameFromBinding(converterContext);

		
		// Get the WebSphere ESB MQ export binding objects.
		MQExportBinding mqExportBinding = (MQExportBinding)converterContext.sourceBinding;	
		RequestType1 mqExportRequest = mqExportBinding.getRequest();
		ResponseType1 mqExportResponse = mqExportBinding.getResponse();		
		
		// Create the MQ input node.
		MQInputNode mqInputNode = (MQInputNode)createNode(converterContext.targetFlow,nodeName+EXPORT_REQUEST,ROLE_ENTRY,MQInputNode.class,nodes);
		
		// The message domain is set to BLOB so that the function selector mapping can update the local
		// environment without needing to know the specific message type. The data handler conversion
		// will then set the message type appropriately.
		mqInputNode.setMessageDomainProperty("BLOB");
		
		// Create a ToDo task for the user so conversion of the failure terminals on theMQInput and
		// MQOutput nodes is handled since the conversion leaves them unwired.
		createToDoTask(converterContext.flowFile,"The fail terminals for MQInput and MQOuput nodes resulting from the " +
				   " conversion of MQ Export binding "+nodeName+" have been left unwired.  Determine the necessary " +
				   " error handling and wire the fail terminals appropriately.");
		
        // Configure the MQInput node to read from the MQ queue defined as the request queue.
		MQReceiveQueue mqReceiveQueue = mqExportRequest.getDestination();
		if( mqReceiveQueue != null ) {
			String receiveQueue = mqReceiveQueue.getQueue();
			if( receiveQueue != null )
				mqInputNode.setQueueName(receiveQueue);
			else
				throw new IllegalArgumentException("For export "+nodeName+": MQ export has no MQ receive queue");
		}
		
		// Get the name of the queue manager the export is configured to receive from.
		// If this is different to the Broker's queue manager then additional conversion work is required.
		// The MQConnection object has other details about the MQ connection, for example whether XA is
		// used and whether the connection is client or bindings mode.
		MQConnection mqConnection = mqExportBinding.getConnection();
		if( mqConnection != null ) {
			MQConfiguration mqConfiguration = mqConnection.getMqConfiguration();
			if( mqConfiguration != null ) {
				String receiveQMgr = mqConfiguration.getQueueManager();
				if( receiveQMgr != null )
					createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
							       " specifies a receive queue manager: "+receiveQMgr+". Check this is correct.");
			}
		}

		// Create the MQ output node.
		// Note: This node is required when the MQ binding export has an interface with request-response
		// operations. For asynchronous invocation style, the MQOutput node can be located in the same
		// message flow as the MQInput node or not. 
		// The sample creates the MQOutput node in the same message flow as the MQInput node.
		MQOutputNode mqOutputNode = (MQOutputNode)createNode(converterContext.targetFlow,nodeName+EXPORT_RESPONSE,ROLE_EXIT,MQOutputNode.class,nodes);
		mqOutputNode.setRequest(false);
		
        // Configure the MQOutput node to write to the MQ queue defined as the response queue.		
		MQSendQueue mqSendQueue = mqExportResponse.getDestination();
		if( mqSendQueue != null ) {
			String sendQueue = mqSendQueue.getQueue();
			if( sendQueue != null )
				mqOutputNode.setQueueName(sendQueue);
			else
				throw new IllegalArgumentException("For export "+nodeName+": MQ export has no MQ send queue");
			
			// Get the name of the queue manager the export is configured to send to.
			// If this is different to the Broker's queue manager then additional conversion work is
			// required.
			String sendQMgr = mqSendQueue.getQmgr();
			if( sendQMgr != null )
				mqOutputNode.setQueueManagerName(sendQMgr);
		}
				
		// This converter currently does not take into account correlation modes, or the case where the
		// response queue is specified by the client in the MQ ReplyTo header.
		// Configuration on the MQ binding controls the way that response messages are formed, for example
		// how the correlation ID and message ID are set in response messages:
		// if( mqExportResponse.getCorrelId().equals(ExportCorrelId.FROM_MSG_ID_LITERAL) )

		// Get method bindings; put them in a map keyed off the native method name.
		// Check if any method binding overrides the input or output data handler.
		// Also check whether the native method name to operation name mapping is actually an identity
		// mapping.
		List methodBindingList = mqExportBinding.getMethodBinding();
		Map<String,MQExportMethodBinding> methodBindings = new HashMap<String,MQExportMethodBinding>();
		boolean identityMap = true;
		for( Iterator i = methodBindingList.iterator(); i.hasNext(); )
		{
			MQExportMethodBinding mb = (MQExportMethodBinding)i.next();
			String nativeMethod = mb.getNativeMethod();
			if( nativeMethod != null ) {
				methodBindings.put(nativeMethod,mb);
				if( !nativeMethod.equals(mb.getMethod()) ) 
					identityMap = false;
			}
			if( mb.getInputDataBindingType() != null )
				createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
				 			   " operation "+mb.getMethod()+" overrides input data handler with "+mb.getInputDataBindingType());
			if( mb.getOutputDataBindingType() != null )
				createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
			 			   	   " operation "+mb.getMethod()+" overrides output data handler with "+mb.getInputDataBindingType());
		}		

		// Convert the function selector.
		//
		// Function selection is a two-step process:
		// 1) the function selector resolves the "native method name"
		// 2) the method binding maps the "native method name" into an operation name.
		// If there's no matching method binding the operation name is assumed to be the native
		// method name.
		//
		// There are five built-in function selectors identified by name:
		// Single Operation - the native method name is the name of the single operation in the interface.
		// Handle Message - the native method name is "handleMessage".
		// Target Function - the native method name is the value of the MQ message header called "TargetFunctionName".
		// Body Format - the native method name is the value of the MQ message body format string.
		// Message Type - the native method name is the value of the MQ message type header.	

		// In preparation for converting the function selector, get the 
		// list of operations in the export's interface.
		String portTypeName = converterContext.portType.getPortType().toString();
		PortType portType = conversionContext.indexer.wsdlPortTypes.get(portTypeName);
		if( portType == null )
			throw new IllegalArgumentException("For export "+nodeName+": Could not locate WSDL Port Type for "+portTypeName);
		List operations = portType.getOperations();
		
		// In this sample, every supported function selector is represented by a Mapping node connected
		// to a RouteToLabel node. Create the mapping node.
		MappingMSLNode fsMappingNode = (MappingMSLNode)createNode(converterContext.targetFlow,nodeName+EXPORT_FUNCTION_SELECTOR,"FS",MappingMSLNode.class,nodes);

		// Connect the MQ Input node to the Function Selector mapping node.
		converterContext.targetFlow.connect(mqInputNode.OUTPUT_TERMINAL_OUT,fsMappingNode.INPUT_TERMINAL_IN);

		// The mapping file defines the input and output message elements and the actions that are taken
		// to update the input message so that the RouteToLabel node can route each message to the correct
		// Label and from there to the operation-specific request subflow.
		String mapFileName = nodeName+EXPORT_FS_MAPPING;
		String mappingContent = null;
		
		// This string defines the common start of the mapping file for all supported function selectors.
		String mappingPrefix = 		
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?><mappingRoot domainID=\"com.ibm.msl.mapping.xml\" domainIDExtension=\"mb\" mainMap=\"true\" targetNamespace=\"default\" version=\"8.0.4.0\" xmlns=\"http://www.ibm.com/2008/ccl/Mapping\" xmlns:map=\"default\">" +
	    "<input path=\"jar:file://!com/ibm/etools/mft/map/xsds/predefined/BlobMessage.xsd\"/>" +
	    "<output path=\"jar:file://!com/ibm/etools/mft/map/xsds/predefined/BlobMessage.xsd\"/>" +
	    "<generation engine=\"xquery\"/>" +
        // Specify the name of the .map file
		"<mappingDeclaration name=\""+mapFileName+"\">" +
		// Specify the scope of the input for the mapping node: message payload BLOB, message assembly,
		// message properties, MQMD and MQRFH2
		// The MQMD and MQRFH2 might be sources of native function name for some function selectors.
		// The LocalEnvironment is assumed to be empty after the MQInput node and so is not an input to this map.
        "<input path=\"mb:msg(BLOB,assembly,BLOB,Properties,MQMD,MQRFH2)\"/>" +
		// Specify the scope of the output for the mapping: message payload BLOB, assembly,
        // message properties, LocalEnvironment
        // The LocalEnvironment is the target for the routing label name.    
        "<output path=\"mb:msg(BLOB,assembly,BLOB,LocalEnvironment,Properties)\"/>" +
        // Move the message payload and properties across unchanged.
        "<move><input path=\"BLOB\"/><output path=\"BLOB\"/></move>" +
        "<move><input path=\"Properties\"/><output path=\"Properties\"/></move>";
		
		// This string defines the common end of the mapping file for all supported function selectors.
		String mappingSuffix = "</mappingDeclaration></mappingRoot>";
		 
		// Each function selector specifies the part of the mapping that sets the routing target label name
		// based on the input message.
		String fsName = mqExportRequest.getFunctionSelector();	
		if( fsName.equals(FS_SINGLE_OPERATION) ) {
			
			// Set the single operation name as the target label name. 
			// An alternative implementation for this case would be to bypass the label and wire
			// the MQInput node directly to the operation subflow. 

			// If the function selector is single operation and the interface has more than one operation,
			// an error is thrown.
			if( operations.size() > 1 )
				throw new IllegalArgumentException("For export "+nodeName+": Single Operation function " +
						"selector cannot handle portType with > 1 operation ("+operations.size()+")");

			// Get the name of the single operation.
			String operationName = ((Operation)operations.get(0)).getName();
			
			// Set the target label name in the local environment.
			mappingContent =  
			"<assign value=\""+operationName+"\">" +
			"<output path=\"LocalEnvironment/Destination/RouterList/DestinationData/labelName\"/>" +
			"</assign>";
			
		// The "handleMessage" function selector is very similar, except that there can be more than
		// one operation in the interface. The operation which gets called is the one which has a
		// method binding with a native method name of "handleMessage".
		} else if( fsName.equals(FS_HANDLE_MESSAGE) ) {
			
			// Get the name of the operation for the "handleMessage" native method name.
			MQExportMethodBinding mb = methodBindings.get("handleMessage");
			if( mb == null ) throw new IllegalArgumentException("For export "+nodeName+": no method binding for handleMessage");
			
			// Create the content of the mapping file.
			// Set the target label name in the local environment.
			mappingContent = 
					"<assign value=\""+mb.getMethod()+"\">" +
					"<output path=\"LocalEnvironment/Destination/RouterList/DestinationData/labelName\"/>" +
					"</assign>";
			
		// Other function selectors require manual conversion.
		} else {
			// If the function selector is an identity map (i.e. every native method name is identical to 
			// its corresponding operation name) then the value can be moved directly from the MQ message
			// header into the target label name.  
			//
            // For example for the "Target Function" function selector, the following would move the
			// native method name from the MQRFH2 usr folder into the target labelName.
			//
		    // <move>
	        // <input path="MQRFH2/usr/TargetFunctionName"/>
	        // <output path="LocalEnvironment/Destination/RouterList/DestinationData/labelName"/>
    	    // </move>
			//
			// This requires the "any" child of the MQRFH2/usr folder be cast to the following schema type:
            // 
			// <?xml version="1.0" encoding="UTF-8"?>
			// <xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">
			//   <xsd:element name="TargetFunctionName" type="xsd:string"/>
			// </xsd:schema>
			//
			// Otherwise the mapping could be created using if elements in the map equivalent to:
			// IF MQRFH2/usr/TargetFunctionName == nativemethod1 THEN labelName = operation1
			// IF MQRFH2/usr/TargetFunctionName == nativemethod2 THEN labelName = operation2

			createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
	 			   	   " function selector of type "+fsName+" needs to be manually converted");			
		}
		
		// If the function selector could be resolved to a mapping, create the mapping file and
		// set it on the Mapping node.
		if( mappingContent != null ) {
			mappingContent = mappingPrefix + mappingContent + mappingSuffix;
			
			// Create the mapping file as a resource in the converted project.
			IProject targetProject = converterContext.moduleConverter.getTargetProject();
			IFile mappingFile = targetProject.getFile(mapFileName+".map");
			if( mappingFile.exists() )
				throw new IllegalArgumentException("For export "+nodeName+": Mapping file "+mapFileName+" .map already exists");
			mappingFile.create(new ByteArrayInputStream(mappingContent.getBytes("UTF-8")),true,null);

			// Set mapping file on the Mapping node.
			MessageMSLMap fsMessageMap = new MessageMSLMap(mapFileName);
			fsMappingNode.setMappingExpression(fsMessageMap);
		}

		// Create a Route to Label node.  This forwards the message on to the request flow for the operation.
		RouteToLabelNode routeToLabelNode =
				(RouteToLabelNode)createNode(converterContext.targetFlow,nodeName+EXPORT_ROUTE,ROLE_MAIN,RouteToLabelNode.class,nodes);

		// Convert the body data handler.
		// This is the default for all operations, can be overridden in method bindings.
		// Note: This converter does not do anything with MQ header data handlers.
		Object dbRef = mqExportRequest.getBodyDataBindingReferenceName();
		String dataBindingName = dbRef == null ? "" : dbRef.toString();

		// Handle the built-in XML data handler.
		if( dataBindingName.equals(DH_XML) ) {
			
			// For the XML data handler, we use a ResetContentDescriptor node to set the message domain
			// to XMLNSC.
			ResetContentDescriptorNode dataHandlerNode =
					(ResetContentDescriptorNode)createNode(converterContext.targetFlow,nodeName+EXPORT_DATA_HANDLER,"DH",ResetContentDescriptorNode.class,nodes);			
			dataHandlerNode.setMessageDomain("XMLNSC");
			dataHandlerNode.setResetMessageDomain(true);
			
			// Connect the data handler node between the function selector mapping node and the route to label node.
			converterContext.targetFlow.connect(fsMappingNode.OUTPUT_TERMINAL_OUT,dataHandlerNode.INPUT_TERMINAL_IN);
			converterContext.targetFlow.connect(dataHandlerNode.OUTPUT_TERMINAL_OUT,routeToLabelNode.INPUT_TERMINAL_IN);		
		} else {
	
			// For other data handlers, we use a Passthrough node to represent the data handler, which will need
			// to be manually converted.
			PassthroughNode dataHandlerNode = 
					(PassthroughNode)createNode(converterContext.targetFlow,nodeName+EXPORT_DATA_HANDLER,"DH",PassthroughNode.class,nodes);
			createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
	 			   	   " data handler of type "+dataBindingName+" needs to be manually converted");
			
			// Connect the data handler node between the function selector mapping node and the route to label node.
			converterContext.targetFlow.connect(fsMappingNode.OUTPUT_TERMINAL_OUT,dataHandlerNode.INPUT_TERMINAL_IN);
			converterContext.targetFlow.connect(dataHandlerNode.OUTPUT_TERMINAL_OUT,routeToLabelNode.INPUT_TERMINAL_IN);		
		}
		
		// It is possible that the response message uses a different data handler, which is not supported
		// by this converter.
		Object responsedbRef = mqExportResponse.getBodyDataBindingReferenceName();
		String responseDataBindingName = responsedbRef == null ? "" : responsedbRef.toString();
		if( !responseDataBindingName.equals(dataBindingName) )
			createToDoTask(converterContext.flowFile,"MQ Export binding "+nodeName+
	 			   	   " response data handler is different to request and needs to be manually converted.");			

		// Conversion complete.
		
		return nodes;
	}

	public Terminal getInputTerminal(String sourceTerminalName, Nodes nodes) {
		// Retrieve the node and map to its input terminal. 
		return ((MQOutputNode)nodes.getNode(ROLE_EXIT)).INPUT_TERMINAL_IN;
	}

	public Terminal getOutputTerminal(String sourceTerminalName, Nodes nodes) {
		// Retrieve the node and map to its output terminal. 
		return ((MQInputNode)nodes.getNode(ROLE_ENTRY)).OUTPUT_TERMINAL_OUT;				
	}
}